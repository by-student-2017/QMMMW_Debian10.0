# Run lammps using the following 3 commands:
# (assuming "lmp_linux" is the name of your LAMMPS binary)

lmp_linux -i run.in.min
lmp_linux -i run.in.stage1
lmp_linux -i run.in.stage2

