void replace(char *, char *, int, char **);
char **extract(char *, char *, int, char **);
