//
// Copyright (C) 2011-2015 QMMMW group
// This file is distributed under the terms of the
// GNU General Public License version 3 (GNU-GPLv3).
//
///
/// Syncronization module for LAMMPS and QE
///
/// It uses two patches of shared memory to simplify the
/// initialization process (although they are sort of redundant)
///
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <signal.h>

#include <string.h>
#include <time.h>
#include <errno.h>
#include <assert.h>

#include <sys/mman.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>

#include <semaphore.h>

#include "../common/ms2_definitions.h"
#include "../common/ms2_errors.h"

FILE *logs;

// Allocated shared memory, size and pointer
size_t  memory_size;
void   *memory;
// Relative adresses of the relevant variables
double *shm_array  = NULL;
int    *shm_mask   = NULL;
int    *totatoms   = NULL, *QEatoms = NULL, *status = NULL;
sem_t  *sem_master = NULL, *sem_slave = NULL, *sem_qe = NULL;
pid_t  *lammps_pid = NULL, *qe_pid = NULL, *slave_pid = NULL;

//! Enable Force dump on all 3 processes
//#define DEBUG
//! Index of the force printed
#define ATOM_PRINTED 12

//#define TIMING
#ifdef TIMING
struct timeval current_time;
#define TIME_ME(name) {gettimeofday(&current_time, NULL);fprintf(stderr, "TIMING: "name" %ld %ld\n", (long) current_time.tv_sec, (long) current_time.tv_usec);}
#else
#define TIME_ME(name)
#endif

//! #### DEBUG DEFINES ####
// Don't mess with the forces
//#define DRY_RUN

#define LOGMSG(...) {fprintf(logs, __VA_ARGS__);fflush(logs);}

//! #### DUMP all forces ####
#define DUMP_FORCES

/// 
/// UTILITY FUNCTIONS. NOT EXPORTED.
///

//! Write a "perror-like" string to the right stream. Not performances critical
void _myperror(char *msg)
{
  int lasterr = errno;
  fprintf(logs, "%s: %s\n",msg, strerror(lasterr));
  fflush(logs);
}

int _check_processes(int check_master, int check_slave, int check_qe, int silent)
{
  if(!silent)
    LOGMSG("Checking %d (%d) %d (%d) %d (%d)\n", check_master, *lammps_pid, check_slave, *slave_pid, check_qe, *qe_pid);

  if(check_master && (kill(*lammps_pid, 0) != 0)) {
    _myperror("master process");
    return SHM_WAITING_A_DEAD_PROCESS;
  }
    
  if(check_slave  && (kill(*slave_pid, 0)  != 0)) {
    _myperror("slave process");
    return SHM_WAITING_A_DEAD_PROCESS;
  }

  if(check_qe     && (kill(*qe_pid, 0)     != 0)) {
    _myperror("qe process");
    return SHM_WAITING_A_DEAD_PROCESS;
  }
  return 0;
}


void debug_print_forces(double *dest, int atom)
{
  static int first = 1;
  FILE *g;

  switch(first) {
  case 1:
    g = fopen("out.txt","w");
    first = 0;
  case 0:    
    g = fopen("out.txt","a");
  }
    
  fprintf(g, "%8g  %8g  %8g\n", dest[3 * atom + 0], dest[3 * atom + 1], dest[3 * atom + 2]);
  fclose(g);
}

// Type: 0 master 1 slave 2 QE 3 master, result
void _dump_forces(int type, double *local)
{
  FILE *f;
  static int counter = 0;
  int i;

  if(type != 3)
    f = fopen("forces.txt", "a");
  else
    f = fopen("forces_res.txt", "a");
    
  // Print the index
  fprintf(f, "%.6d | ", counter);
  // Depending on the type of dump, write all
  switch(type) {
  case 0:
    for(i=0;i<*totatoms * 3;i++)
      fprintf(f, " %g", local[i]);
    fprintf(f, " |\n");
    break;
  case 1: // Slave
    for(i=0;i< *QEatoms * 3;i++)
      fprintf(f, " %g", local[i]);
    fprintf(f, " |\n");
    break;
  case 2: // QE
    for(i=0;i< *QEatoms * 3;i++)
      fprintf(f, " %g", local[i]);
    fprintf(f, " |\n");
    break;
  case 3: // Master, after the addition
    for(i=0;i<*totatoms * 3;i++)
      fprintf(f, " %g", shm_array[i]);
    fprintf(f, " |\n");
    break;
  default:
    assert(0);
  }

  fclose(f);
  counter++;
}


///
/// Posting/waiting functions
///
inline void post_master(void)
{
  assert(sem_post(sem_master) != -1);
}

inline void post_slave(void)
{
  assert(sem_post(sem_slave) != -1);
}

inline void post_qe(void)
{
  assert(sem_post(sem_qe) != -1);
}

inline int wait_master(void)
{
  int res;
  struct timespec timedwait_period;
  int silent = 0;

  while(1) {
    clock_gettime(CLOCK_REALTIME, &timedwait_period);
    timedwait_period.tv_sec += SHM_CHECK_PERIOD;
    res = sem_timedwait(sem_master, &timedwait_period);
    if(res == 0)
      break;
    switch(errno) {
    case ETIMEDOUT:
      if((res = _check_processes(0, 1, 1, silent)) != 0)
	return res;
      break;
    default:
      _myperror("wait_master");
      return SHM_SEM_WAIT_FAILED;
    }
    silent++;
  }
  return 0;
}

inline int wait_slave(void)
{
  int res;
  struct timespec timedwait_period;
  int silent = 0;

  while(1) {
    clock_gettime(CLOCK_REALTIME, &timedwait_period);
    timedwait_period.tv_sec += SHM_CHECK_PERIOD;
    res = sem_timedwait(sem_slave, &timedwait_period);
    if(res == 0)
      break;
    switch(errno) {
    case ETIMEDOUT:
      if((res = _check_processes(1, 0, 1, silent)) != 0)
	return res;
      break;
    default:
      _myperror("wait_slave");
      return SHM_SEM_WAIT_FAILED;
    }
    silent++;
  }
  return 0;
}

inline int wait_qe(void)
{
  int res;
  struct timespec timedwait_period;
  int silent = 0;

  while(1) {
    clock_gettime(CLOCK_REALTIME, &timedwait_period);
    timedwait_period.tv_sec += SHM_CHECK_PERIOD;
    res = sem_timedwait(sem_qe, &timedwait_period);
    if(res == 0)
      break;
    switch(errno) {
    case ETIMEDOUT:
      if((res = _check_processes(1, 1, 0, silent)) != 0)
	return res;
      break;
    default:
      _myperror("wait_qe");
      return SHM_SEM_WAIT_FAILED;
    }
    silent++;
  }
  return 0;
}

/** 
    Initialize the log file using the SHM_LOGS environment variable.

    If the variable is not defined, then stderr is used instead.
*/
int _init_logfile(void)
{
  char *env;
  time_t now;

  env = getenv(SHM_ENV_VAR_LOG);
  // Use stderr to print the logs
  if(env == NULL) {
    logs = stderr;
    LOGMSG("%s not provided: using stderr for the logs\n", SHM_ENV_VAR_LOG);
  } else {
    // Open a file for it
    logs = fopen(env, "a");
    if(logs == NULL) {
      logs = stderr;
      _myperror("File for the logs not opened");
      return SHM_LOG_ERROR;
    }
    // Write a nice header too
    now = time(NULL);
    fflush(logs);
  }
  return 0;
}

// Return the correct memory to ask to mmap in order to obtain all requested memory
size_t get_memory_size(size_t memory_requested)
{
  long int page = sysconf(_SC_PAGE_SIZE);
  int pages = memory_requested / page;
  return page * (pages + 1);
}

/**
   Read an environment variable in order to obtain the name to be used
   for the shared memory file

   Then 2 names are returned, appended respectively with _1 and _2 for
   int and semaphores and arrays (this because the size of the arrays
   isn't known in advance.
*/
int _getname(char *shname) {
  const char *env;
  int len;
  
  // Get the value of the environment variable
  env = getenv(SHM_ENV_VAR);
  if(env == NULL) {
    LOGMSG("The environment variable %s was not found.\n", SHM_ENV_VAR);
    return NO_ENV_VAR;
  }

  // Search for "/" characters
  if(strchr(env, '/') != NULL) {
    LOGMSG("The environment variable %s should not contain a '/' char.\n", SHM_ENV_VAR);
    return SHM_MALFORMED_ENV_CONTENT;
  }

  len = strlen(env) + 1;
  if(len > SHM_MAXSHNAME) {
    LOGMSG("The content of the environment variable is too long (max length: %d chars)!\n", SHM_MAXSHNAME - 1);
    return SHM_MALFORMED_ENV_CONTENT;
  }

  memcpy(shname, env, len);
  LOGMSG("The name for the shmem handler is: '%s'\n", shname);
  return 0;
}

//* If add == 0
//* Copy data from a vector with the QM subset to one
//* with all the coordinates and zero the empty cells
//* If add == 1 (QE)
//* Add data from a vector with the QM subset to one
//* with all the coordinates and zero the empty cells
//* If add == -1 (LAMMPS slave)
//* Subtract data from a vector with the QM subset to one
//* with all the coordinates and zero the empty cells
void copy_small2big(double *dest, double *source, int add)
{
  int i, pos = 0;

#ifdef DEBUG  
  debug_print_forces(source, ATOM_PRINTED);
#endif

  switch(add) {
  case 1:
    // Add the forces (QE case)
    for(i = 0; i < *totatoms; i++)
      switch(shm_mask[i]) {
      case -1:
	memset(dest + 3 * i, 0, sizeof(double) * 3);
	break;
      default:
	dest[3 * i + 0] += source[3 * pos + 0];
	dest[3 * i + 1] += source[3 * pos + 1];
	dest[3 * i + 2] += source[3 * pos + 2];
	pos++;
	break;
      }
    break;
  case -1:
    // Subtract  the forces (LAMMPS slave case)
    for(i = 0; i < *totatoms; i++)
      switch(shm_mask[i]) {
      case -1:
	memset(dest + 3 * i, 0, sizeof(double) * 3);
	break;
      default:
	dest[3 * i + 0] -= source[3 * pos + 0];
	dest[3 * i + 1] -= source[3 * pos + 1];
	dest[3 * i + 2] -= source[3 * pos + 2];
	pos++;
	break;
      }
    break;
  case 0:
    // Copy the forces (unused)
    for(i = 0; i < *totatoms; i++)
      switch(shm_mask[i]) {
      case -1:
	memset(dest + 3 * i, 0, sizeof(double) * 3);
	break;
      default:
	memcpy(dest + 3 * i, source + 3 * pos, sizeof(double) * 3);
	pos++;
	break;
      }
    break;
  }
  
}
//* Copy data from a vector with all the coordinates to one
//* with the QM subset
void copy_big2small(double *dest, double *source)
{
  int i, pos = 0;
// FIXME: performances suck: use memcpy
  for(i = 0; i < *totatoms; i++)
    switch(shm_mask[i]) {
    case -1:
      break;
    default:
      memcpy(dest + 3 * pos, source + 3 * i , sizeof(double) * 3);
      pos++;
      break;
    }
}

void _add_forces(double *local)
{
  int i;

#ifdef DEBUG  
  debug_print_forces(local, ATOM_PRINTED);
#endif

#ifndef DRY_RUN
  for(i = 0; i < *totatoms; i++) 
    if(shm_mask[i] != -1) {
      local[3 * i + 0] += shm_array[3 * i + 0];
      local[3 * i + 1] += shm_array[3 * i + 1];
      local[3 * i + 2] += shm_array[3 * i + 2];
    }
#endif

}

///
/// MASTER FUNCTIONS: USED BY THE PRIMARY LAMMPS
///

int shmem_master_init(int *mask, int atoms, int QE_atoms, char *name)
{
  char shname[SHM_MAXSHNAME]; //Semaphores and constants
  int fd, res;

  if((res = _init_logfile()) != 0)
    return res;
    

  if(name != NULL) {
    // Use the provided name
    strncpy(shname, name, SHM_MAXSHNAME);
    if(strchr(name, '/') != NULL) {
      LOGMSG("The shared memory handler should not contain '/' characters\n");
      return SHM_MALFORMED_ENV_CONTENT;
    }
  } else {
    // Get one from the environment
    res = _getname(shname);
    if(res)
      return res;
  }

  if(shm_unlink(shname) == 0) 
    LOGMSG("* Stale shmem link (%s) removed\n", shname);

  // Create the file descriptor
  fd = shm_open(shname, O_RDWR | O_CREAT, 0700);
  if (fd == -1) {
    _myperror("Shared memory handler not opened");
    return SHM_INIT_FAILED;
  }

  // Allocate the space for all the data
  memory_size = get_memory_size(3 * (sizeof(int) + sizeof(sem_t) + sizeof(pid_t)) 
				+ atoms * (3 * sizeof(double) + sizeof(int)));
  if(ftruncate(fd, memory_size)) {
    _myperror("Shared memory not allocated");
    return SHM_INIT_FAILED;
  }

  // Create a mapping of the shared memory
  if((memory = mmap(NULL, memory_size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0)) == MAP_FAILED) {
    _myperror("Memory not mapped");
    close(fd);
    if(shm_unlink(shname) == 0) 
      LOGMSG("* Stale shmem link (%s) removed\n", shname);
    return SHM_INIT_FAILED;
  }

  // The descriptor is not needed anymore
  close(fd);

  // Create shortcut for the areas of memory
  totatoms   = (int *)    memory; 
  QEatoms    = (int *)    (memory + 1 * sizeof(int));
  status     = (int *)    (memory + 2 * sizeof(int));
  lammps_pid = (pid_t *)  (memory + 3 * sizeof(int));
  slave_pid  = (pid_t *)  (memory + 3 * sizeof(int) + 1 * sizeof(pid_t));
  qe_pid     = (pid_t *)  (memory + 3 * sizeof(int) + 2 * sizeof(pid_t));
  sem_master = (sem_t *)  (memory + 3 * sizeof(int) + 3 * sizeof(pid_t));
  sem_slave  = (sem_t *)  (memory + 3 * sizeof(int) + 3 * sizeof(pid_t) + 1 * sizeof(sem_t));
  sem_qe  =    (sem_t *)  (memory + 3 * sizeof(int) + 3 * sizeof(pid_t) + 2 * sizeof(sem_t));
  // Those are available only on the master, for now
  shm_array =  (double *) (memory + 3 * sizeof(int) + 3 * sizeof(pid_t) + 3 * sizeof(sem_t));
  shm_mask  =  (int *)    (memory + 3 * sizeof(int) + 3 * sizeof(pid_t) + 3 * sizeof(sem_t) + 3 * sizeof(double) * atoms);

  // Initialize the semaphores
  LOGMSG("Initializing the semaphores\n");
  if(sem_init(sem_master, 1, 0)) {
    _myperror("Semaphore1 not initialized");
    munmap(memory, memory_size);
    return SHM_INIT_FAILED;
  }

  if(sem_init(sem_slave, 1, 0)) {
    _myperror("Semaphore2 not initialized");
    munmap(memory, memory_size);
    return SHM_INIT_FAILED;
  }

  if(sem_init(sem_qe, 1, 0)) {
    _myperror("Semaphore3 not initialized");
    munmap(memory, memory_size);
    return SHM_INIT_FAILED;
  }

  // FIXME: do some tests and remove this kludge
  //Set the status to 1: this will warn that the semaphores are ready 
  *status = 1;

  // Write the number of atoms in the array
  *totatoms = atoms;
  *QEatoms = QE_atoms;
  // Save my pid
  *lammps_pid = getpid();
  // Copy the content of the mask to make it available
  memcpy((void *) shm_mask, (void *) mask, sizeof(int) * *totatoms);

  // Allow the other processes to read the variables
  // FIXME (slave only, per ora)
  LOGMSG("Initialization terminated!\n");
  post_slave();
  post_qe();
  return 0;
}

int shmem_master_set_positions(double *positions)
{
  int res;
  TIME_ME("shmem_master_set_positions START");
  //! Copy the positions from the LAMMPS master to the slave, reducing them, 
  //! (and copy the number of atoms involved, for check and reference)
  MSG("Section1: atoms->x  =>  shm_array");
  copy_big2small(shm_array, positions);
  // Wait for the LAMMPS slave to finish
  // FIXME: qua ci dovrebbe essere un ciclo che controlli se il processo che aspetto e' ancora vivo...
  TIME_ME("shmem_master_set_positions END");
  post_slave();
  res = wait_master();
  return res;
}

void shmem_master_add_forces(double *forces)
{
  
  TIME_ME("shmem_master_add_forces START");

  MSG("Section2: adding forces");

#ifdef DUMP_FORCES
  _dump_forces(0, forces);
#endif

  _add_forces(forces);

#ifdef DUMP_FORCES
  _dump_forces(3, NULL);
#endif

  TIME_ME("shmem_master_add_forces END");
}

///
/// SLAVE FUNCTIONS. USED BY THE SECONDARY LAMMPS PROCESS
///

void shmem_clear_array(void)
{
  MSG("Section X: shm_array = 0");
  memset(shm_array, 0, sizeof(double) * 3 * *totatoms);
}
  
int shmem_slave_init(int QE_atoms, int index, char *name)
{
  char shname[SHM_MAXSHNAME]; //Semaphores and constants
  struct stat stat;
  int fd, i, tmp, res;
  
  if((res = _init_logfile()) != 0)
    return res;

  if(name != NULL) {
    // Use the provided name
    strncpy(shname, name, SHM_MAXSHNAME);
    if(strchr(name, '/') != NULL) {
      LOGMSG("The shared memory handler should not contain '/' characters.\n");
      return SHM_MALFORMED_ENV_CONTENT;
    }
  } else {
    // Get one from the environment
    res = _getname(shname);
    if(res)
      return res;
  }

  // Try to get the shared memory handler
  // FIXME: try for a specified amount of time, not forever
  for(i = 0;i < SHM_TIMEOUT * 2; i++) {
    fd = shm_open(shname, O_RDWR, 0700);
    if (fd != -1) {
      LOGMSG("Shared memory handler opened\n");
      break;
    }
    usleep(500000);
  }
  if(fd == -1) {
    LOGMSG("Timeout Expired: master process not found\n");
    return SHM_TIMEOUT_EXPIRED;
  }

  // Wait for the memory to be allocated 
  while(1) {
    fstat(fd, &stat);
    if(stat.st_size != 0) {
      LOGMSG("Shared Memory found (%ld, %ld)\n", (long) stat.st_size, (long) stat.st_blocks);
      break;
    }
    usleep(200000);
  }

  // Get the memory for the semaphores, atom numbers and pids
  memory_size = get_memory_size(3 * (sizeof(int) + sizeof(sem_t) + sizeof(pid_t)));
  // Use the same fd to map anoter region, suggest to use the same address
  // (where this is not possible, it is easy to correct the issue )
  if((memory = mmap(NULL, memory_size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0)) == MAP_FAILED) {
    _myperror("Memory not mapped (1)");
    close(fd);
    if(shm_unlink(shname) == 0) 
      LOGMSG("* Stale shmem link (%s) removed (1)\n", shname);
    return SHM_INIT_FAILED;
  }
  LOGMSG("* Memory mapped\n");

  // Set the appropriate variables
  totatoms   = (int *)   memory; 
  QEatoms    = (int *)   (memory + 1 * sizeof(int));
  status     = (int *)   (memory + 2 * sizeof(int));
  lammps_pid = (pid_t *) (memory + 3 * sizeof(int));
  slave_pid  = (pid_t *) (memory + 3 * sizeof(int) + 1 * sizeof(pid_t));
  qe_pid     = (pid_t *) (memory + 3 * sizeof(int) + 2 * sizeof(pid_t));
  sem_master = (sem_t *) (memory + 3 * sizeof(int) + 3 * sizeof(pid_t));
  sem_slave  = (sem_t *) (memory + 3 * sizeof(int) + 3 * sizeof(pid_t) + 1 * sizeof(sem_t));
  sem_qe  =    (sem_t *) (memory + 3 * sizeof(int) + 3 * sizeof(pid_t) + 2 * sizeof(sem_t));
  
  // FIXME: do some tests and remove this kludge
  // Wait until status is one
  // (This is because i don't know if a test for sem_wait != -1 is reliable
  // it's a sort of "voodoo programming", however it is an ADDED
  // security measure
  for(i = 0;i < SHM_TIMEOUT * 10; i++) {
    if(*status != 0)
      break;
    usleep(100000);
  }
  if(*status == 0) {
    LOGMSG("Timeout Expired: master stuck for some reason\n");
    return SHM_TIMEOUT_EXPIRED;
  }

  // Save the pid number
  switch(index) {
  case 1:
    res = wait_slave();
    if(res)
      return res;
    *slave_pid = getpid();
    break;
  case 2:
    res = wait_qe();
    if(res)
      return res;
    *qe_pid = getpid();
    break;
  }
    
  // Verify that the number of atoms exchanged is the same for master and slave!
  if(QE_atoms != *QEatoms) {
    char error[200];
    snprintf(error, 200, "the number of atoms exchanged differs!!!\nThe master LAMMPS reports %d where the slave %d reports %d:\ncheck your configurations files!", *QEatoms, index, QE_atoms);
    VERR(error);
    return SHM_ATOMS_NUM_DIFFERS;
  }

  // Save the value we need
  tmp = *totatoms;
  // Resize the memory
  munmap(memory, memory_size);
  LOGMSG("* Old mapping removed\n");
  // New total size
  memory_size = get_memory_size(3 * (sizeof(int) + sizeof(sem_t) + sizeof(pid_t)) 
				+ tmp * (3 * sizeof(double) + sizeof(int)));
  // Use the same fd to map anoter region
  if((memory = mmap(NULL, memory_size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0)) == MAP_FAILED) {
    _myperror("Memory not mapped (2)");
    close(fd);
    if(shm_unlink(shname) == 0) 
      LOGMSG("* Stale shmem link (%s) removed (2)\n", shname);
    return SHM_INIT_FAILED;
  }
  LOGMSG("* Memory re-sized\n");
  
  // Link everything. Again
  totatoms   = (int *)    memory; 
  QEatoms    = (int *)    (memory + 1 * sizeof(int));
  status     = (int *)    (memory + 2 * sizeof(int));
  lammps_pid = (pid_t *)  (memory + 3 * sizeof(int));
  slave_pid  = (pid_t *)  (memory + 3 * sizeof(int) + 1 * sizeof(pid_t));
  qe_pid     = (pid_t *)  (memory + 3 * sizeof(int) + 2 * sizeof(pid_t));
  sem_master = (sem_t *)  (memory + 3 * sizeof(int) + 3 * sizeof(pid_t));
  sem_slave  = (sem_t *)  (memory + 3 * sizeof(int) + 3 * sizeof(pid_t) + 1 * sizeof(sem_t));
  sem_qe  =    (sem_t *)  (memory + 3 * sizeof(int) + 3 * sizeof(pid_t) + 2 * sizeof(sem_t));
  shm_array =  (double *) (memory + 3 * sizeof(int) + 3 * sizeof(pid_t) + 3 * sizeof(sem_t));
  shm_mask  =  (int *)    (memory + 3 * sizeof(int) + 3 * sizeof(pid_t) + 3 * sizeof(sem_t) + 3 * sizeof(double) * *totatoms);

  // At this point, we don't need the fd anymore...
  close(fd);

  LOGMSG("Initialization terminated!\n");
  return 0;
}
  
// e' fermo
int shmem_slave_get_position(double *positions, int index)
{
  int res;
  if(index==1) {
    res = wait_slave(); 
    if(res)
      return res;
    MSG("Section 1: shm_array -> positions slave");
  } else {
    res = wait_qe();
    if(res) 
      return res;
    MSG("Section 1: shm_array -> positions QE");
  }
  
#ifdef DEBUG
  {
    int i;
    double *p,*q;
    printf("PRINTOUT OF THE POSITIONS\n");
    for(i=0;i<*QEatoms;i++) {
      p = positions + 3 * i;
      q = ((double *) shm_array) + 3 * i;
      printf("PRINTOUT  %6g %6g %6g     %6g %6g %6g\n", q[0], q[1], q[2], p[0], p[1], p[2]);
    }
  }
#endif

  memcpy((void *) positions, (void *) shm_array, *QEatoms * 3 * sizeof(double));

  if(index==1) {
    post_qe();
    res = wait_slave();
    if(res)
      return res;
  } else {
    post_slave();
    res = wait_qe();
    if(res)
      return res;
  }
  return 0;
}

void shmem_slave_return_forces(double *forces, int add)
{

  if(add == -1) {
    // Slave
#ifdef DUMP_FORCES
    _dump_forces(1, forces);
#endif
    shmem_clear_array();
    MSG("Section 2: shm_array -= forces slave");
  } else {
    // QE
#ifdef DUMP_FORCES
  _dump_forces(2, forces);
#endif
    MSG("Section 2: shm_array += forces QE");
  }

  //FIXME
  copy_small2big(shm_array, forces, add);

  if(add == -1) {
    // Slave
    post_qe();
  } else {
    // QE
    post_master();
  }
}



  
