//!
//! Copyright (C) 2011-2015 QMMMW group
//! This file is distributed under the terms of the
//! GNU General Public License version 3 (GNU-GPLv3).
//!
#ifndef SHMEM_EXCHANGE_H
#define SHMEM_EXCHANGE_H

#ifdef __cplusplus
extern "C" {
#endif


  int shmem_master_init(int *mask, int atoms, int QE_atoms, char *name);
  int shmem_master_set_positions(double *positions);
  void shmem_master_add_forces(double *forces);

  void shmem_clear_array(void);

  int shmem_slave_init(int QE_atoms, int index, char *name);
  int shmem_slave_get_position(double *positions, int index);
  void shmem_slave_return_forces(double *forces, int add);

  
#ifdef __cplusplus
}
#endif


#endif

