//
// Copyright (C) 2011-2015 QMMMW group
// This file is distributed under the terms of the
// GNU General Public License version 3 (GNU-GPLv3).
//
#include "ms2_shmem.h"
#include "shmem_exchange.h"
#include <stdlib.h>
#include <stdio.h>

int ms2_shmem_master_init(int argc, char *argv[], int *mask, int natoms, int QMatoms)
{  
  if(argc != 1) {
    fprintf(stderr, "Invalid number of arguments for the shmem transport (only 1 is required)!\n");
    return 1;
  }

  return shmem_master_init(mask, natoms, QMatoms, argv[0]);
}

int ms2_shmem_slave_init(int argc, char *argv[], int natoms)
{
  if(argc != 1) {
    fprintf(stderr, "Invalid number of arguments for the shmem transport (only 1 is required)!\n");
    return 1;
  }
  return shmem_slave_init(natoms, 1, argv[0]);
}

int ms2_shmem_qm_init(int argc, char *argv[], int natoms)
{
  if(argc != 1) {
    fprintf(stderr, "Invalid number of arguments for the shmem transport (only 1 is required)!\n");
    return 1;
  }
  return shmem_slave_init(natoms, 2, argv[0]);
}

int ms2_shmem_master_put_positions(double *pos)
{
  return shmem_master_set_positions(pos);
}

int ms2_shmem_slave_get_positions(double *pos)
{
  return shmem_slave_get_position(pos, 1);
}

int ms2_shmem_qm_get_positions(double *pos)
{
  return shmem_slave_get_position(pos, 2);
}

int ms2_shmem_master_get_forces(double *forces)
{
  shmem_master_add_forces(forces);
  return 0;
}

int ms2_shmem_slave_put_forces(double *forces)
{
  shmem_slave_return_forces(forces, -1);
  return 0;
}

int ms2_shmem_qm_put_forces(double *forces)
{
  shmem_slave_return_forces(forces, 1);
  return 0;
}

int ms2_shmem_master_finalize(void) {
  return 0;
}

int ms2_shmem_slave_finalize(void) {
  return 0;
}

int ms2_shmem_qm_finalize(void) {
  return 0;
}


  
