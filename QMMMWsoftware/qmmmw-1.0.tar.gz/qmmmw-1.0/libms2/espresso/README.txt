

     WARNING WARNING WARNING WARNING WARNING WARNING WARNING WARNING
     WARN This code is unused and kept here just as reference!!!! NG
     WARN see libms2ec/espresso for the current version           NG
     WARNING WARNING WARNING WARNING WARNING WARNING WARNING WARNING


Modules and various code for the inclusion of MS2 in Quantum Espresso

ms2.f90               : replaces the omonimous file in the PW
                        directory of the QE distribution

input.f90             : replaces the omonimous file in the Modules
                        sub-directory of the QE distribution

input_parameters.f90  : replaces the omonimous file in the Modules
                        sub-directory of the QE distribution

-- Manual installation: 

copy the ms2.f90, input.f90 and input_parameters.f90 into the
Modules directory and the  into the PW directory (overwriting the
original files, if present).

Add an ms2.o entry in the Modules list and, below, a line like: 

LDFLAGS+="-L/usr/local/ms2/lib/ms2 -Wl,-rpath,/usr/local/ms2/lib/ms2  -lexchange"

with the options required to link the ms2 libraries.

-- Automatic installation:

It is advised to use the automatic patch procedure in the makefile of
the main directory, just specify the ESPRESSO_DIR at configuration
time and then issue:

     make patch_espresso build_espresso

to patch the distribution and build pw.x (some tweaking at configure
time could be required anyway).
