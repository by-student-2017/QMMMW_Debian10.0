//
// Copyright (C) 2011-2015 QMMMW group
// This file is distributed under the terms of the
// GNU General Public License version 3 (GNU-GPLv3).
//

#include "fix_ms2debug.h"
#include "stdlib.h"
#include "error.h"
#include "atom.h"
#include <string.h>


using namespace LAMMPS_NS;
using namespace FixConst;

#define INDEX 1


#define MS2MSG(...) {fprintf(screen, "MS2DEBUG Module: " __VA_ARGS__);fflush(screen);}

#define ROUTINE_VOID(name, ...) void FixMS2DEBUG::name(__VA_ARGS__) {MS2MSG("%-17s\n", #name);print_data(#name);}
#define ROUTINE(returns, name, retval,  ...) returns FixMS2DEBUG::name(__VA_ARGS__) {MS2MSG("%-17s\n", #name);return retval;}

ROUTINE_VOID(init)                    // init  (no mask)
ROUTINE_VOID(setup, int) 	      // setup (no mask)
ROUTINE_VOID(initial_integrate, int)  // INITIAL_INTEGRATE
ROUTINE_VOID(post_integrate)	      // POST_INTEGRATE
ROUTINE_VOID(pre_exchange) 	      // PRE_EXCHANGE
ROUTINE_VOID(pre_neighbor) 	      // PRE_NEIGHBOR
ROUTINE_VOID(pre_force, int) 	      // PRE_FORCE
ROUTINE_VOID(post_force, int) 	      // POST_FORCE
ROUTINE_VOID(final_integrate) 	      // FINAL_INTEGRATE
ROUTINE_VOID(end_of_step) 	      // END_OF_STEP
//Respa: 5
ROUTINE_VOID(initial_integrate_respa, int,  int,  int)
ROUTINE_VOID(post_integrate_respa, int,  int)        
ROUTINE_VOID(pre_force_respa, int,  int,  int) 	        
ROUTINE_VOID(post_force_respa, int,  int,  int)
ROUTINE_VOID(final_integrate_respa, int)


void FixMS2DEBUG::print_data(const char *routinename) 
{
  if(ms2debug_print) {
    MS2MSG("%-17s positions for %2d: %8.4g %8.4g %8.4g\n", routinename, ms2debug_index, 
	   atom->x[ms2debug_index][0], 
	   atom->x[ms2debug_index][1], 
	   atom->x[ms2debug_index][2]);
    MS2MSG("%-17s forces    for %2d: %8.4g %8.4g %8.4g\n", routinename, ms2debug_index, 
	   atom->f[ms2debug_index][1], 
	   atom->f[ms2debug_index][1], 
	   atom->f[ms2debug_index][2]);
    MS2MSG("%-17s velocity  for %2d: %8.4g %8.4g %8.4g\n", routinename, ms2debug_index, 
	   atom->v[ms2debug_index][1], 
	   atom->v[ms2debug_index][1], 
	   atom->v[ms2debug_index][2]);
  }
}



int FixMS2DEBUG::setmask()
{
  int mask = 0;
  mask = INITIAL_INTEGRATE |    // Setup
    POST_INTEGRATE |  
    PRE_EXCHANGE |  
    PRE_NEIGHBOR  |  
    PRE_FORCE |  
    POST_FORCE |
    FINAL_INTEGRATE |
    END_OF_STEP |
  //    RESPA 5
    INITIAL_INTEGRATE_RESPA |
    POST_INTEGRATE_RESPA |
    PRE_FORCE_RESPA |
    POST_FORCE_RESPA |
    FINAL_INTEGRATE_RESPA;
  return mask;
}

FixMS2DEBUG::FixMS2DEBUG(class LAMMPS *lmp, int argc, char **argv):
  Fix(lmp,argc,argv)
{
  MS2MSG("%-17s\n", "FixMS2DEBUG");

  nevery = 1;

  ms2debug_print =  0;
  ms2debug_index = -1;

  
  switch(argc) {
  case 6:
    // This should be, if present, the index to print (C convention, from 0)
    ms2debug_index = atol(argv[5]);
    if((ms2debug_index >= atom->nlocal) || (ms2debug_index < 0))
      error->all(FLERR,"The print index in MS2DEBUG should be in the atom range");
  case 5:
    // If an extra parameter is written, check that is the word "print"
    if(strcasecmp(argv[4], "print"))
      error->all(FLERR,"Invalid parameter for the MS2DEBUG fix\n'print' expected");
    // If the index is not set, then we have a problem
    if (ms2debug_index == -1) 
      error->all(FLERR,"Invalid number of parameter for the MS2DEBUG fix\nthe index of an atom should follow 'print'");    
    ms2debug_print = 1;
  case 4:
    nevery = atoi(argv[3]);
    break;
  default:
    error->all(FLERR,"Incorrect number of parameters for the MS2DEBUG fix");
 }  
  print_data("FixMS2DEBUG");
}


FixMS2DEBUG::~FixMS2DEBUG()
{
  MS2MSG("%-17s\n", "~FixMS2DEBUG");
  print_data("~FixMS2DEBUG");
}


