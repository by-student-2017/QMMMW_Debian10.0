//!
//! Copyright (C) 2011-2015 QMMMW group
//! This file is distributed under the terms of the
//! GNU General Public License version 3 (GNU-GPLv3).
//!

#ifdef FIX_CLASS
FixStyle(ms2, FixMS2)
#else
#ifndef FIX_MS2_H
#define FIX_MS2_H

#include "fix.h"

namespace LAMMPS_NS {

  class FixMS2 : public Fix {
  public:
    FixMS2(class LAMMPS *, int, char **);
    ~FixMS2();
    void init();
    void pre_force(int);
    void post_force(int);
    int setmask();
    void setup(int);
    void initial_integrate(int);
  private:
    //! The role in the MS2 system
    int role;
    //! True only after a setup step
    int setup_done;
    // Shortcuts for the corresponding variables in universe.h
    int me;
    //! Used to pack the types on the master node. Used only once
    int *get_all_types();
    //! Used to pack the positions on the master node
    void mergepositions();
    //! Used to unpack the positions to all nodes (slave/fakeqm only)
    void scatterpositions();
    
    //! Temporary storages for the packing/unpacking operations
    double *tmpdouble;
    
    // not yet used
    void mergeforces();
    void scatterforces();

/*     // Debug */
/*     FILE *f; */
/*     void print_all(const char *); */

  };
}


#endif
#endif
