//
// Copyright (C) 2011-2015 QMMMW group
// This file is distributed under the terms of the
// GNU General Public License version 3 (GNU-GPLv3).
//
#include "fix_ms2.h"
#include "stdlib.h"
#include "error.h"
#include "atom.h"
#include "mpi.h"
#include "universe.h"
#include <string.h>
#include <ms2.h>

using namespace LAMMPS_NS;
using namespace FixConst;

#define MS2MSG(...) fprintf(screen, "MS2 Module: " __VA_ARGS__)

#define MS2MSG1(...) {if (!me) fprintf(screen, "MS2 Module: " __VA_ARGS__);}

#define ROLE_MASTER 0
#define ROLE_SLAVE  1
#define ROLE_QM     2

FixMS2::FixMS2(class LAMMPS *lmp, int argc, char **argv):
  Fix(lmp,argc,argv)
{
  int errcode;
  int *types;

  // Initialize the temporary storage locations
  tmpdouble = (double *) calloc(atom->natoms * 3, sizeof(double));
  if(tmpdouble == NULL)
    error->all(FLERR,"MS2: unable to allocate space for temporary variables (1)");

  // It isn't probably difficult to use them (i gave it already a
  // look), but we don't need this feature
  if (universe->existflag != 0)
    error->all(FLERR,"MS2 doesn't support partitioning");

  // Shortcuts for the same universe variable
  me = universe->me;

  // There's no reason to apply the MS2 fix to just a subsystem
  if(strncasecmp("all", argv[1] , 4) != 0)
    error->all(FLERR,"The MS2 fix should be applied to all atoms in the simulation");

  setup_done = 0;

  // beside the normal fixed "fix" arguments, we need at least:
  // the file where the expression for the selection can be found
  // a module name
  // if more parameters are found, they are passed to the module initialization routine
  if(argc < 6)
    error->all(FLERR,"Invalid number of parameters for the MS2 fix");

  // Find out the role of this process
  role = -1;
  if(!strcasecmp(argv[3], "master")) {
    MS2MSG1("master role\n");
    role = ROLE_MASTER;
  }
  if(!strcasecmp(argv[3], "slave")) {
    MS2MSG1("slave role\n");
    role = ROLE_SLAVE;
  }
  if(!strcasecmp(argv[3], "fakeqm")) {
    MS2MSG1("fake QE role\n");
    role = ROLE_QM;
  }    
  // The string doesn't match a role
  if(role == -1)
    error->all(FLERR,"Invalid MS2 role specified (can be either master|slave|fakeqm)");

  // Gather the atom types
  types = get_all_types();

  // Initialize the various processes
  if(!me) 
    switch(role) {
    case ROLE_MASTER: 
      errcode =  ms2_master_initialize(argc - 4, argv + 4, atom->natoms, types);
      break;
    case ROLE_SLAVE:
      errcode = ms2_slave_initialize(argc - 4, argv + 4, atom->natoms);
      break;
    case ROLE_QM:
      errcode = ms2_qm_initialize(argc - 4, argv + 4, atom->natoms);
      break;
    }
  MPI_Bcast(&errcode, 1, MPI_INT, 0, world);
  if(errcode)
    error->all(FLERR,"Unable to initialize the MS2 support");  

  delete [] types;
}


int FixMS2::setmask()
{
  int mask = 0;
  mask = PRE_FORCE | POST_FORCE | INITIAL_INTEGRATE;
  return mask;
}


void FixMS2::init()
{
  MS2MSG1("init\n");

  // Since the spatial sorting can be turned on and off between the
  // simulation, It is way better to keep the check in init, where it
  // is performed more often
  if(atom->sortfreq != 0)
    error->all(FLERR,"The MS2 fix and sorting are incompatible: turn spatial sorting off ('atom_modify sort 0 0.0')");

  pre_force(0);
}

// Barrier/MPI test not required
void FixMS2::setup(int vflag)
{
  MS2MSG1("setup\n");
  post_force(vflag);
}

// Barrier/MPI test not required
void FixMS2::initial_integrate(int vflag)
{
    switch(setup_done) {
    case 0:
      return;
    default:
      MS2MSG1("integration right after the setup\n");
      post_force(vflag);
      setup_done = 0;
      return;
    }
}

void FixMS2::pre_force(int vflag)
{
  int errcode;
  MS2MSG1("pre force\n");

  mergepositions();

  if(!me)
    switch(role) {
    case ROLE_MASTER:
      errcode = ms2_master_put_positions(tmpdouble);
      break;
    case ROLE_SLAVE:
      errcode = ms2_slave_get_positions(tmpdouble);
      break;
    case ROLE_QM:
      errcode = ms2_qm_get_positions(tmpdouble);
      break;
    }
  MPI_Bcast(&errcode, 1, MPI_INT, 0, world);
  if(errcode)
    error->all(FLERR,"MS2 was unable to perform the pre_force step!");

  if(role != ROLE_MASTER)
    scatterpositions();

}

// Errors TODO
void FixMS2::post_force(int vflag)
{
  int errcode;
  int i;
  MS2MSG1("post force\n");

  mergeforces();

  if(!me)
    switch(role) {
    case ROLE_MASTER:
      errcode = ms2_master_get_forces(tmpdouble);
      break;
    case ROLE_SLAVE:
      //! Send the forces to LAMMPS_master
      errcode = ms2_slave_put_forces(tmpdouble);
      break;
    case ROLE_QM:
      //! Send the forces to LAMMPS_master
      errcode = ms2_qm_put_forces(tmpdouble);
      break;
    }
  MPI_Bcast(&errcode, 1, MPI_INT, 0, world);
  if(errcode)
    error->all(FLERR,"MS2 was unable to perform the post_force step!");

  scatterforces();

}


void FixMS2::mergepositions()
{
  int i, index;
  int elements = 3 * atom->natoms;
  double *copy = new double[elements];
  
  // Clear the array
  memset(copy, 0, sizeof(double) * 3 * atom->natoms);
  // Write the data
  for(i=0; i<atom->nlocal; i++) {
    index = 3 * (atom->tag[i] - 1);
    copy[index + 0] = atom->x[i][0];
    copy[index + 1] = atom->x[i][1];
    copy[index + 2] = atom->x[i][2];
  }
  MPI_Reduce(copy, tmpdouble, 3 * atom->natoms, MPI_DOUBLE, MPI_SUM, 0, world);
  delete [] copy;
}

void FixMS2::mergeforces()
{
  int i, index;
  int elements = 3 * atom->natoms;
  double *copy = new double[elements];
  
  // Clear the array
  memset(copy, 0, sizeof(double) * 3 * atom->natoms);
  // Write the data
  for(i=0; i<atom->nlocal; i++) {
    index = 3 * (atom->tag[i] - 1);
    copy[index + 0] = atom->f[i][0];
    copy[index + 1] = atom->f[i][1];
    copy[index + 2] = atom->f[i][2];
  }
  MPI_Reduce(copy, tmpdouble, 3 * atom->natoms, MPI_DOUBLE, MPI_SUM, 0, world);
  delete [] copy;
}


int *FixMS2::get_all_types()
{
  int i, index;
  int natoms = atom->natoms;
  int *copy = new int[natoms];
  int *tmpint = new int[natoms]; 
  
  // Clear the array
  memset(copy, 0, sizeof(int) * atom->natoms);
  // Write the data
  for(i=0; i<atom->nlocal; i++) {
    index = atom->tag[i] - 1;
    copy[index] = atom->type[i];
  }
  MPI_Reduce(copy, tmpint, atom->natoms, MPI_INT, MPI_SUM, 0, world);
  delete [] copy;
  return tmpint;
}

void FixMS2::scatterpositions()
{
  int i, index;
  // Distribute to each processor
  MPI_Bcast(tmpdouble, 3 * atom->natoms, MPI_DOUBLE, 0, world);
  // Copy the local values to the positions vector
  for(i=0; i<atom->nlocal; i++) {
    index = 3 * (atom->tag[i] - 1);
    atom->x[i][0] = tmpdouble[index + 0];
    atom->x[i][1] = tmpdouble[index + 1];
    atom->x[i][2] = tmpdouble[index + 2];
  }
}

void FixMS2::scatterforces()
{
  int i, index;
  // Distribute to each processor
  MPI_Bcast(tmpdouble, 3 * atom->natoms, MPI_DOUBLE, 0, world);
  // Copy the local values to the positions vector
  for(i=0; i<atom->nlocal; i++) {
    index = 3 * (atom->tag[i] - 1);
    atom->f[i][0] = tmpdouble[index + 0];
    atom->f[i][1] = tmpdouble[index + 1];
    atom->f[i][2] = tmpdouble[index + 2];
  }
}

FixMS2::~FixMS2()
{
  int errcode;
  // Free the temporary storage
  free(tmpdouble);
  // Final cleanup, if required by the module
  if(!me)
    switch(role) {
    case ROLE_MASTER: 
      errcode = ms2_master_finalize();
      break;
    case ROLE_SLAVE:
      errcode = ms2_slave_finalize();
      break;
    case ROLE_QM:
      errcode = ms2_qm_finalize();
      break;
    }
  MPI_Bcast(&errcode, 1, MPI_INT, 0, world);
  if(errcode)
    error->all(FLERR,"MS2 was unable to finalize the plugin!");

}

// void FixMS2::print_all(const char *name)
// {
//   int i;
//   fprintf(f, "====== %s ======\n", name);

//   fprintf(f, "* atom->tag  ");
//   for(i=0;i<atom->nlocal;i++)
//     fprintf(f, "%6d ", atom->tag[i]);
//   fprintf(f, "\n");

//   fprintf(f, "* atom->x    ");
//   for(i=0;i<3*atom->nlocal;i++)
//     fprintf(f, "%6.3g ", atom->x[0][i]);
//   fprintf(f, "\n");

//   fprintf(f, "* atom->f    ");
//   for(i=0;i<3*atom->natoms;i++)
//     fprintf(f, "%6.3g ", atom->f[0][i]);
//   fprintf(f, "\n");

//   fprintf(f, "* tmpdouble  ");
//   for(i=0;i<3*atom->natoms;i++)
//     fprintf(f, "%6.3g ", tmpdouble[i]);
//   fprintf(f, "\n");

//   fprintf(f, "* type       ");
//   for(i=0;i<atom->nlocal;i++)
//     fprintf(f, "%6d ",atom->type[i]);
//   fprintf(f, "\n");

// }
