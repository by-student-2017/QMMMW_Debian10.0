//!
//! Copyright (C) 2011-2015 QMMMW group
//! This file is distributed under the terms of the
//! GNU General Public License version 3 (GNU-GPLv3).
//! 
#ifdef FIX_CLASS
FixStyle(ms2debug, FixMS2DEBUG)
#else
#ifndef FIX_MS2DEBUG_H
#define FIX_MS2DEBUG_H

#include "fix.h"

namespace LAMMPS_NS {

  class FixMS2DEBUG : public Fix {
  public:
    FixMS2DEBUG(class LAMMPS *, int, char **);
    ~FixMS2DEBUG();

    int setmask();
    void init();
    void setup(int); 

    void initial_integrate(int); 
    void post_integrate();
    void pre_exchange();
    void pre_neighbor();
    void pre_force(int); 
    void post_force(int); 
    void final_integrate();
    void end_of_step();
    
    void initial_integrate_respa(int,  int,  int); 
    void post_integrate_respa(int,  int); 
    void pre_force_respa(int,  int,  int); 
    void post_force_respa(int,  int,  int); 
    void final_integrate_respa(int); 
  private:
    void print_data(const char *);
    int ms2debug_print;
    int ms2debug_index;
  };
}

#endif
#endif
