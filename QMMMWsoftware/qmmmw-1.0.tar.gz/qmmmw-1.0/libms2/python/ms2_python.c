//
// Copyright (C) 2011-2015 QMMMW group
// This file is distributed under the terms of the
// GNU General Public License version 3 (GNU-GPLv3).
//
#include "ms2_python.h"
#include <Python.h>
#include <stdio.h>

#define ERROR(message) fprintf(stderr, __FILE__":%d %s\n", __LINE__, message)

// Reference to the python instance
PyObject *ms2object = NULL;
// A Reference to the array module
PyObject *arraymodule = NULL;

// Inputarray
PyObject *inputarray = NULL;
PyObject *outputarray = NULL;


// Relevant for all simulations
int natoms = -1;
// Relevant for the master only
int QMatoms = -1;

#define FINALIZE_POBJ(name) if(name) {Py_DECREF(name);name = NULL;}

void finalize_python(void)
{
  FINALIZE_POBJ(inputarray);
  FINALIZE_POBJ(outputarray);
  FINALIZE_POBJ(ms2object);
  FINALIZE_POBJ(arraymodule);
  Py_Finalize();
}

int init_python(int argc, char *argv[], int *mask, int role)
{
  PyObject *pyModuleName;
  PyObject *pyModule;
  PyObject *pyArgs;
  PyObject *pyValue, *pyValue2;
  PyObject *pyMS2class;
  double *tmparray;
  PyObject *tmpstring;
  int args, index, i;

  // Start the interpreter
  Py_Initialize();

  // Get the module
  if(argv[0] == NULL) {
    ERROR("Invalid argument");
    Py_Finalize();
    return 1;
  }

  // Convert the name of the module from C string to Python
  pyModuleName = PyString_FromString(argv[0]);
  if(!pyModuleName) {
    PyErr_Print();
    PyErr_Clear();
    finalize_python();
    return 1;
  }

  // Load the module
  pyModule = PyImport_Import(pyModuleName);
  Py_DECREF(pyModuleName);

  if(!pyModule) {
    PyErr_Print();
    PyErr_Clear();
    finalize_python();
    return 1;
  }

  arraymodule = PyImport_ImportModule("array");
  if(!arraymodule) {
    PyErr_Print();
    PyErr_Clear();
    finalize_python();
    return 1;
  }


  // Instantiate the class: get the name first
  switch(role) {
  case 0:
    pyMS2class = PyObject_GetAttrString(pyModule, "MS2master");
    break;
  case 1:
    pyMS2class = PyObject_GetAttrString(pyModule, "MS2slave");
    break;
  case 2:
    pyMS2class = PyObject_GetAttrString(pyModule, "MS2qm");
    break;
  }
  Py_DECREF(pyModule);


  if(!pyMS2class) {
    PyErr_Print();
    finalize_python();
    return 1;
  }

  // Find out if the object is callable and a class
  if(!PyClass_Check(pyMS2class) && !PyType_Check(pyMS2class)) {
    fprintf(stderr, "MS2(master|slave|qm) should be a class object\n");
    Py_DECREF(pyMS2class);
    return 1;
  }

  // Build the tuple with the arguments
  // Arguments passed are:
  // MASTER: atoms, QMatoms, mask (as string), other arguments
  // SLAVE:  atoms, other arguments
  // QM:     atoms, other arguments
  switch(role) {
  case 0:
    args = argc + 2; 
    break;
  case 1:
  case 2:
    args = argc;
    break;
  }

  // Create the tuple that will hold the arguments
  pyArgs = PyTuple_New((Py_ssize_t) args);
  if(!pyArgs) {
    PyErr_Print();
    PyErr_Clear();
    finalize_python();
    return 1;
  }
  index = 0;

  // I argument (common): natoms
  pyValue = PyInt_FromLong((long) natoms);
  if(!pyValue) {
    Py_DECREF(pyArgs);
    PyErr_Print();
    PyErr_Clear();
    finalize_python();
    return 1;
  }
  PyTuple_SetItem(pyArgs, index++, pyValue);

  // Master only arguments
  if(role == 0) {
    // QMatoms
    pyValue = PyInt_FromLong((long) QMatoms);
    if(!pyValue) {
      Py_DECREF(pyArgs);
      PyErr_Print();
      PyErr_Clear();
      finalize_python();
      return 1;
    }
    PyTuple_SetItem(pyArgs, index++, pyValue);
    // Mask
    pyValue = PyString_FromStringAndSize((const char *) mask, natoms * sizeof(int));
    if(!pyValue) {
      Py_DECREF(pyArgs);
      PyErr_Print();
      PyErr_Clear();
      finalize_python();
      return 1;
    }
    pyValue2 = PyObject_CallMethod(arraymodule,
				   "array",
				   "sO","i", pyValue);
    Py_DECREF(pyValue);
    if(!pyValue2) {
      Py_DECREF(pyArgs);
      PyErr_Print();
      PyErr_Clear();
      finalize_python();
      return 1;
    }

    PyTuple_SetItem(pyArgs, index++, pyValue2);
  }

  // All remaining common arguments
  for(i=1;i<argc;i++) {
    pyValue = PyString_FromString(argv[i]);
    if(!pyValue) {
      Py_DECREF(pyArgs);
      PyErr_Print();
      PyErr_Clear();
      finalize_python();
      return 1;
    }
    PyTuple_SetItem(pyArgs, index++, pyValue);
  }
  //  PyObject_Print(pyArgs, stdout, 0);

  // Get an instance (it will be stored in the ms2object module variable)
  ms2object = PyObject_CallObject(pyMS2class, pyArgs);
  Py_DECREF(pyMS2class);
  Py_DECREF(pyArgs);
  if(!ms2object) {
    PyErr_Print();
    PyErr_Clear();
    finalize_python();
    return 1;
  }

  // Allocate the input and output arrays
  tmparray = (double *) malloc(sizeof(double) * 3 * natoms);
  if(!tmparray) {
    perror("Unable to initialize the MS2 support: ");
    finalize_python();
    return 1;
  }
  tmpstring = PyString_FromStringAndSize((char *) tmparray, sizeof(double) * 3 * natoms);
  free(tmparray);
  if(!tmpstring) {
    PyErr_Print();
    PyErr_Clear();
    finalize_python();
    return 1;
  }
    
  inputarray = PyObject_CallMethod(arraymodule,
				   "array",
				   "sO","d", tmpstring);

  if(!inputarray) {
    Py_DECREF(tmpstring);
    PyErr_Print();
    PyErr_Clear();
    finalize_python();
    return 1;
  }
  
  outputarray = PyObject_CallMethod(arraymodule,
				    "array",
				    "sO","d", tmpstring);
  if(!outputarray) {
    Py_DECREF(tmpstring);
    Py_DECREF(inputarray);
    PyErr_Print();
    PyErr_Clear();
    finalize_python();
    return 1;
    }
  Py_DECREF(tmpstring);
  
  return 0;
}

/**
   This is the model used for the "output only" calls, like:

   get_positions
   get_forces
*/
int python_do_something(double *array, char *callname, PyObject *pyarray, int writeback)
{
  int res;
  PyObject *pyRetval;
  PyObject *argument;
  Py_ssize_t memory_size = (Py_ssize_t) natoms * 3 * sizeof(double);
  double *buf;
  Py_ssize_t size;
  
  if(PyObject_AsWriteBuffer(pyarray, (void **) &buf, &size)<0) {
    PyErr_Print();
    PyErr_Clear();
    finalize_python();
    return 1;      
  }
  if(size != memory_size) {
    fprintf(stderr, "MS2: the previous call to MS2 wrongly resized the array argument!\n");
    finalize_python();
    return 1;
  }
  memcpy(buf, array, memory_size);

  // Call the function using the array as an argument
  pyRetval = PyObject_CallMethod(ms2object, callname, "O", pyarray);  
  if(!pyRetval) {
    PyErr_Print();
    PyErr_Clear();
    finalize_python();
    return 1;
  }
  
  // Test if the result is True (which means error...)
  res = PyObject_IsTrue(pyRetval);
  Py_DECREF(pyRetval);

  switch(res) {
  case -1:
    // The true test failed: this is an exception and should be reported
    PyErr_Print();
    PyErr_Clear();
    // Fall through!
  case 1:
    // This means that the function is reporting failure: the interpreter is ok
    finalize_python();
    return 1;
  }

  if(writeback) {
    if(PyObject_AsReadBuffer(pyarray, (const void **) &buf, &size)<0) {
      PyErr_Print();
      PyErr_Clear();
      finalize_python();
      return 1;      
    }
    if(size != memory_size) {
      fprintf(stderr, "MS2: The array received by the python functions should never be resized!\n");
      finalize_python();
      return 1;
    }
    // If the array is ok, copy the data back
    memcpy(array, buf, memory_size);
  }
   
  return 0;
}

int ms2_python_master_init(int argc, char *argv[], int *mask, int n_atoms, int QM_atoms)
{
  PyObject *classname;
  if(argc < 1) {
    fprintf(stderr, "Invalid number of arguments for the python transport (only a module name is required)!\n");
    return 1;
  }

  natoms = n_atoms;
  QMatoms = QM_atoms;
  
  // Initialize 
  if(init_python(argc, argv, mask, 0))
    return 1;

  
  return 0;
}

int ms2_python_slave_init(int argc, char *argv[], int n_atoms)
{
  PyObject *classname;
  if(argc < 1) {
    fprintf(stderr, "Invalid number of arguments for the python transport (only a module name is required)!\n");
    return 1;
  }

  natoms = n_atoms;

  // Initialize 
  if(init_python(argc, argv, NULL, 1))
    return 1;

  // TODO arguments and init
  
  return 0;
}


int ms2_python_qm_init(int argc, char *argv[], int n_atoms)
{
  PyObject *classname;
  if(argc < 1) {
    fprintf(stderr, "Invalid number of arguments for the python transport (only a module name is required)!\n");
    return 1;
  }

  natoms = n_atoms;

  // Initialize 
  if(init_python(argc, argv, NULL, 2))
    return 1;

  // TODO arguments and init
  
  return 0;
}


int ms2_python_master_put_positions(double *pos)
{
  return python_do_something(pos, "put_positions", outputarray, 0);
}



int ms2_python_slave_get_positions(double *pos)
{
  return python_do_something(pos, "get_positions", inputarray, 1);
}



int ms2_python_qm_get_positions(double *pos)
{
  return python_do_something(pos, "get_positions", inputarray, 1);
}



int ms2_python_master_get_forces(double *forces)
{
  return python_do_something(forces, "get_forces", inputarray, 1);
}




int ms2_python_slave_put_forces(double *forces)
{
  return python_do_something(forces, "put_forces", outputarray, 0);
}



int ms2_python_qm_put_forces(double *forces)
{
  return python_do_something(forces, "put_forces", outputarray, 0);
}




int ms2_python_master_finalize(void)
{
  // No reasons to do del(MS2master): 
  // this should call the ms2object destructor anyway. 
  finalize_python();
  return 0;
}



int ms2_python_slave_finalize(void)
{
  // No reasons to do del(MS2master): 
  // this should call the ms2object destructor anyway. 
  finalize_python();
  return 0;
}



int ms2_python_qm_finalize(void)
{
  // No reasons to do del(MS2master): 
  // this should call the ms2object destructor anyway. 
  finalize_python();
  return 0;
}


