//!
//! Copyright (C) 2011-2015 QMMMW group
//! This file is distributed under the terms of the
//! GNU General Public License version 3 (GNU-GPLv3).
//!
#ifndef MS2_PYTHON_H
#define MS2_PYTHON_H

int ms2_python_master_init(int argc, char *argv[], int *mask, int natoms, int QMatoms);
int ms2_python_slave_init(int argc, char *argv[], int natoms);
int ms2_python_qm_init(int argc, char *argv[], int natoms);

int ms2_python_master_put_positions(double *pos);
int ms2_python_slave_get_positions(double *pos);
int ms2_python_qm_get_positions(double *pos);

int ms2_python_master_get_forces(double *forces);
int ms2_python_slave_put_forces(double *forces);
int ms2_python_qm_put_forces(double *forces);

int ms2_python_master_finalize(void);
int ms2_python_slave_finalize(void);
int ms2_python_qm_finalize(void);

#endif

