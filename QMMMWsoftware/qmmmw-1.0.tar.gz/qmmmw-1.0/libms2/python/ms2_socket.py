"""Copyright (C) 2011-2015 QMMMW group
   This file is distributed under the terms of the
   GNU General Public License version 3 (GNU-GPLv3)."""

"""This module is to be used with the ms2_python transport of the MS2 project.

The code is heavily commented, as it's also used as documentation for
the plugin itself"""

import socket, sys, re, array

MAXPASS = 10

def INFO(msg):
    sys.stderr.write(msg + "\n")

def ERROR(msg):
    sys.stderr.write("ERROR: %s \n" % msg)

# This is the class that will spawn the instance used by the master
# process
class MS2master:
    # The instantiation of the class will be called at the
    # initialization of the module
    #
    # The number of arguments depends from how many are specified in
    # the input file: the first 3 arguments are always present, the
    # remaining one are the extra arguments in the input file
    #
    # atoms = the total number of atoms in the full system
    # qmatoms = the number of atoms in the QM subsystem
    # mask = a array of integer with the mask showing which atoms are
    # in the QM system
    #
    # In this specific case, the remaining arguments here are a port
    # and a password
    def __init__(self, atoms, qmatoms, mask, port, password):
        self.atoms = atoms
        self.qmatoms = qmatoms
        self.mask = mask

        # The soon-to-be connections to the slave and QM
        self.qm = None
        self.slave = None

        try:
            self._port = int(port)
        except ValueError,error:
            raise ValueError, "The port argument should be an integer!\n"

        if len(password) > MAXPASS:
            sys.stderr.write("Password length truncated to %s characters" % MAXPASS)
            
        self._password = password[:MAXPASS] + " " * (MAXPASS - len(password[:MAXPASS]))

        # Temporary array
        self.tmparray = array.array("d", [0.0] * self.qmatoms * 3)
        

        self._init_server()

    # This call will be executed within the ms2_master_put_positions call
    # positions is an array of double with the positions of all atoms in the
    # full simulation (natoms * 3 elements) which should be reduced using the
    # mask and passed to the other processes.
    #
    # Since, for performance reasons, the array passed is a reference
    # to the same very object, it is important that it's shape is not
    # changed during the execution of this method. Any change to the
    # content of the array (which is atoms long) is discarded
    #
    # The function should return False on success and True on failure
    def put_positions(self, positions):
        # Copy the positions into a smaller array
        pos = 0
        for i in range(self.atoms):
            if self.mask[i] != -1:
                self.tmparray[3 * pos]     = positions[3 * i]
                self.tmparray[3 * pos + 1] = positions[3 * i + 1]
                self.tmparray[3 * pos + 2] = positions[3 * i + 2]
                pos += 1

        try:
            INFO("About to send the position to the QM")
            self.__send_data(self.qm, self.tmparray.tostring())
            INFO("About to send the position to the slave")
            self.__send_data(self.slave, self.tmparray.tostring())
        except socket.error, error:
            ERROR(error)
            return 1
        return 0
    
    # This call will be executed within the ms2_master_put_positions
    # call positions is an array of double with the forces computed in
    # the master process.
    #
    # Since, for performance reasons, the array passed is a reference
    # to the same very object, it is important that it's shape is not
    # changed during the execution of this method.
    #
    # The function should return False on success and True on failure
    # and, when it returns, the array forces is expected to contain
    # the correct combination of the master forces with the slave and
    # qe ones.
    def get_forces(self, forces):
        try:
            INFO("About to receive the forces from the slave")
            slaveforces = array.array("d",
                                      self.__recv_data(self.slave,
                                                       self.tmparray.itemsize * len(self.tmparray)))
            INFO("About to receive the forces from the QM")
            qmforces = array.array("d",
                                   self.__recv_data(self.qm,
                                                    self.tmparray.itemsize * len(self.tmparray)))
        except socket.error, error:
            ERROR(error)
            return 1

        pos = 0
        for i in range(self.atoms):
            if self.mask[i] != -1:
                forces[3 * i + 0] += qmforces[3 * pos + 0] - slaveforces[3 * pos + 0]
                forces[3 * i + 1] += qmforces[3 * pos + 1] - slaveforces[3 * pos + 1]
                forces[3 * i + 2] += qmforces[3 * pos + 2] - slaveforces[3 * pos + 2]
                pos += 1
                        
        return 0

    # Since this step will be executed when the class is finalized, it
    # will be executed either when the ms2_python module is finalized,
    # or when the interpreter is. This is slightly different from what
    # happens with other transports (when the finalization doesn't
    # necessarly happens on failure).
    def __del__(self):
        if self.slave:
            self.slave.close()
        if self.qm:
            self.qm.close()
    
    def __recv_data(self, s, size):
        data = ""
        received = 0
        while received < size:
            tmp = s.recv(size - received)
            if tmp == "":
                raise socket.error,(69,"Connection prematurely closed")
            data += tmp
            received = len(data)
        return data

    def __send_data(self, s, data):
        tosend = len(data)
        sent = 0
        while sent < tosend:
            tmp = s.send(data[sent:])
            sent += tmp
        return sent

    def _wait_connections(self, server):
        """Wait until a slave and a quantum are correctly authenticated
    
        If two clients of the same type (slave or quantum) try to
        connect with a valid password, exit with an exception
        (probably the simulation is not configured correctly)"""
        while True:
            print "Waiting for a connection"
            (s, (source, port)) = server.accept()
            try:
                output = self.__recv_data(s, MAXPASS + 1)
            except socket.error:
                INFO("Client discarded ('%s' prematurely closed the connection)" % source)
                continue
                
            role = output[0]
            password = output[1:]
            if password != self._password:
                INFO("Client discarded from %s (wrong password)" % source)
                s.close()
                continue

            if role == "S":
                if self.slave != None:
                    raise RuntimeError, "Received 2 connections from 2 authenticated slaves"
                self.slave = s
                INFO("Received valid connection from %s as slave role" % source)
                if self.qm != None:
                    break
            elif role == "Q":
                if self.qm != None:
                    raise RuntimeError, "Received 2 connections from 2 authenticated qm"
                self.qm = s
                INFO("Received valid connection from %s as quantum role" % source)
                if self.slave != None:
                    break
            else:
                INFO("Client discarded from %s (wrong role '%s')" % (source, role))
                s.close()
                continue
        INFO("Ready to start the simulation")
        
        

    def _init_server(self):
        """Initialize the server, wait until 2 connections are
        established and authenticated"""
        ssocket = socket.socket()

        # Set a bunch of useful options for a server
        ssocket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR,True)
        ssocket.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE,True)
        ssocket.setsockopt(socket.SOL_TCP, socket.TCP_KEEPCNT,30)
        ssocket.setsockopt(socket.SOL_TCP, socket.TCP_KEEPIDLE,60)
        ssocket.setsockopt(socket.SOL_TCP, socket.TCP_KEEPINTVL,60)
        
        ssocket.bind(("0.0.0.0", self._port))
        ssocket.listen(10)

        # Get te connection to the clients
        try:
            self._wait_connections(ssocket)
        finally:
            ssocket.close()


# This is the class that will spawn the instance used by the slave
# process. Many of the considerations about the master apply here too,
# and will not be repeated
class MS2slave:
    # This is a little trick to make the creation of the MS2qm class
    # straightforward: see below for details ;-)
    ROLE = "S"
    
    # The instantiation of the class will be called at the
    # initialization of the module
    #
    # The number of arguments depends from how many are specified in
    # the input file: the first argument is always present, the
    # remaining one are the extra arguments in the input file
    #
    # atoms = the total number of atoms in the QM system
    #
    # In this specific case, the remaining arguments here are a host,
    # a port and a password
    def __init__(self, atoms, host, port, password):
        self.atoms = atoms

        self._host = host

        try:
            self._port = int(port)
        except ValueError,error:
            raise ValueError, "The port argument should be an integer!\n"

        if len(password) > MAXPASS:
            sys.stderr.write("Password length truncated to %s characters" % MAXPASS)
            
        self._password = password[:MAXPASS] + " " * (MAXPASS - len(password[:MAXPASS]))

        self._init_connection()

    # In this case, it is the positions array that's used to transmit
    # information from python to C. The content of positions array will be
    # copied into the slave position vector. Resizing the array is not advisable...
    def get_positions(self, positions):
        try:
            INFO("About to receive the positions from the master")
            tmp = array.array("d",
                              self.__recv_data(positions.itemsize * 3 *self.atoms))
        except socket.error,error:
            ERROR(error)
            return 1

        # Copy the values inside the array from tmp to positions
        # We can't just replace the reference, otherwise the C code
        # will not notice any change in its vector!
        positions[:] = tmp[:]
        return 0

    # In this case, the forces array is used only to read the forces:
    # writing into it will not produce any effect on LAMMPS
    def put_forces(self, forces):
        try:
            INFO("About to send the forces to the master")
            self.__send_data(forces.tostring())
        except socket.error, error:
            ERROR(error)
            return 1
        return 0

    # Since this step will be executed when the class is finalized, it
    # will be executed either when the ms2_python module is finalized,
    # or when the interpreter is. This is slightly different from what
    # happens with other transports (when the finalization doesn't
    # necessarly happens on failure).
    def __del__(self):
        try:
            self.socket.close()
        except:
            pass
    
    def __recv_data(self, size):
        data = ""
        received = 0
        while received < size:
            tmp = self.socket.recv(size - received)
            if tmp == "":
                raise socket.error,(69,"Connection prematurely closed")
            data += tmp
            received = len(data)
        return data

    def __send_data(self, data):
        tosend = len(data)
        sent = 0
        while sent < tosend:
            tmp = self.socket.send(data[sent:])
            sent += tmp
        return sent

    def _init_connection(self):
        """Initialize the server, wait until 2 connections are
        established and authenticated"""
        self.socket = socket.socket()
        try:
            self.socket.connect((self._host, self._port))
        except socket.error:
            ERROR("Unable to connect to the server (%s:%d)" % (self._host, self._port))
            raise socket.error
        INFO("Connected")

        # Try to send the role and password
        self.__send_data(self.ROLE + self._password)
        INFO("Password and role sent")


# Behold! Since the only difference between the slave and QM, from the
# transport perpective, is the string sent during the authentication,
# we can re-use the MS2slave class overriding the static variable ROLE
class MS2qm(MS2slave):
    ROLE = "Q"

