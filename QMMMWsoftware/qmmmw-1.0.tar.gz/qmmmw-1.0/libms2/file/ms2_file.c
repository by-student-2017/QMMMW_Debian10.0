/**
Copyright (C) 2011-2015 QMMMW group
This file is distributed under the terms of the
GNU General Public License version 3 (GNU-GPLv3).
*/

/** 
    A very basic example of plugin for the libms2.

    Files are used to exchange the data: keep in mind that this code
    is meant to be informative, not an example of elegant coding.

    Riccardo Di Meo
*/

#include "ms2_file.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

// Number of atoms in the simulation. Set on all processes
int natoms = -1;
// Number of atoms in the QM subsystem. Set on master only
int QMatoms = -1;
// This is borrowed from the libms2. Deallocating this would be bad(Tm)
int *mask = NULL;

// Vectors used on the master only to perform some operation
double *slaveforces = NULL;
double *qmforces = NULL;

// Exchange files. Not elegant but it's an example...
char *master_tmp = NULL;
char *master_out = NULL;
char *master_in = NULL;
char *slave_tmp = NULL;
char *slave_out = NULL;
char *qm_tmp = NULL;
char *qm_out = NULL;
char *qm_in = NULL;
// Exit file
char *exit_sim = NULL;

// Finalization: free memory
void free_all(void)
{
  // Relevant only for the master
  free(slaveforces);
  free(qmforces);
  slaveforces = NULL;
  qmforces = NULL;

  // Space for the names of the files
  free(master_tmp);
  free(master_out);
  free(master_in);
  free(slave_tmp);
  free(slave_out);
  free(qm_tmp);
  free(qm_out);
  free(qm_in);

  master_tmp = NULL;
  master_out = NULL;
  master_in = NULL;
  slave_tmp = NULL;
  slave_out = NULL;
  qm_tmp = NULL;
  qm_out = NULL;
  qm_in = NULL;

  free(exit_sim);
  exit_sim = NULL;
}

void remove_junk(void)
{
  unlink(master_tmp);
  unlink(master_out);
  unlink(master_in);
  unlink(slave_tmp);
  unlink(slave_out);
  unlink(qm_tmp);
  unlink(qm_out);
  unlink(qm_in);
}

char *get_full_path(char *basename, char *filename)
{
  char *output;
  static int elements;

  // + 5 Melius abundare quam deficere
  elements = strlen(filename) + strlen(basename) + 2 + 5;
  output = (char *) calloc(elements, sizeof(char));
  if(!output)
    return output;
  
  snprintf(output, elements, "%s/%s", basename, filename);
  return output;
}

int set_filenames(char *basename)
{

  // Files used
  exit_sim = get_full_path(basename, "EXIT");
  if(!exit_sim) {
    fprintf(stderr, "Allocation error at "__FILE__":%d\n", __LINE__);
    free_all();
    return 1;
  }

  // Files used
  master_tmp = get_full_path(basename, "master_tmp");
  if(!master_tmp) {
    fprintf(stderr, "Allocation error at "__FILE__":%d\n", __LINE__);
    free_all();
    return 1;
  }
  master_out = get_full_path(basename, "master_out");
  if(!master_out) {
    fprintf(stderr, "Allocation error at "__FILE__":%d\n", __LINE__);
    free_all();
    return 1;
  }
  master_in = get_full_path(basename, "master_in");
  if(!master_in) {
    fprintf(stderr, "Allocation error at "__FILE__":%d\n", __LINE__);
    free_all();
    return 1;
  }
  slave_tmp = get_full_path(basename, "slave_tmp");
  if(!slave_tmp) {
    fprintf(stderr, "Allocation error at "__FILE__":%d\n", __LINE__);
    free_all();
    return 1;
  }
  slave_out = get_full_path(basename, "slave_out");
  if(!slave_out) {
    fprintf(stderr, "Allocation error at "__FILE__":%d\n", __LINE__);
    free_all();
    return 1;
  }
  qm_tmp = get_full_path(basename, "qm_tmp");
  if(!qm_tmp) {
    fprintf(stderr, "Allocation error at "__FILE__":%d\n", __LINE__);
    free_all();
    return 1;
  }
  qm_out = get_full_path(basename, "qm_out");
  if(!qm_out) {
    fprintf(stderr, "Allocation error at "__FILE__":%d\n", __LINE__);
    free_all();
    return 1;
  }
  qm_in = get_full_path(basename, "qm_in");
  if(!qm_in) {
    fprintf(stderr, "Allocation error at "__FILE__":%d\n", __LINE__);
    free_all();
    return 1;
  }
  return 0;
}

FILE *wait_file(char *name)
{
  FILE *f;
  fprintf(stderr, __FILE__":%d waiting for %s\n", __LINE__, name);
  while(1) {
    f = fopen(name, "r");
    if(f)
      return f;
    usleep(100000);
  }
}

int ms2_file_master_init(int argc, char *argv[], int *QMmask, int n_atoms, int QM_atoms)
{
  if(argc != 1) {
    fprintf(stderr, "Invalid number of arguments for the file transport (only 1 is required)!\n");
    return 1;
  }

  natoms = n_atoms;
  QMatoms = QM_atoms;

  // Allocate a couple of vectors to do some math
  slaveforces = (double *) calloc(3 * QMatoms, sizeof(double));
  if(!slaveforces) {
    fprintf(stderr, "Allocation error in "__FILE__":%d\n", __LINE__);
    return 1;
  }
  qmforces = (double *) calloc(3 * QMatoms, sizeof(double));
  if(!qmforces) {
    fprintf(stderr, "Allocation error in "__FILE__":%d\n", __LINE__);
    free(qmforces);
    return 1;
  }
  
  mask = QMmask;

  if(set_filenames(argv[0]))
    return 1;

  return 0;
}

int ms2_file_slave_init(int argc, char *argv[], int n_atoms)
{
  if(argc != 1) {
    fprintf(stderr, "Invalid number of arguments for the file transport (only 1 is required)!\n");
    return 1;
  }
  natoms = n_atoms;

  // Files used
  if(set_filenames(argv[0]))
    return 1;

  // Remove any file that could be there
  unlink(slave_tmp);
  unlink(slave_out);
  return 0;
}

int ms2_file_qm_init(int argc, char *argv[], int n_atoms)
{
  if(argc != 1) {
    fprintf(stderr, "Invalid number of arguments for the file transport (only 1 is required)!\n");
    return 1;
  }
  natoms = n_atoms;

  // Files used
  if(set_filenames(argv[0]))
    return 1;

  // Remove any file that could be there
  unlink(qm_tmp);
  unlink(qm_out);
  unlink(qm_in);

  return 0;
}

// Positions
int ms2_file_master_put_positions(double *pos)
{
  int i;
  FILE *f;

  // Remove any file that could be there
  remove_junk();

  f = fopen(master_tmp,"w");
  if(!f) 
    return 1;

  for(i=0;i<natoms;i++)
    if(mask[i] != -1)
      fwrite(pos + 3* i, sizeof(double), 3, f);
  fclose(f);

  if(rename(master_tmp, master_out)) {
    perror("Error renaming the file: ");
    return 1;
  }


  return 0;
}

int ms2_file_slave_get_positions(double *pos)
{
  FILE *f;
  int read;

  f = wait_file(qm_in);
  read = fread(pos, sizeof(double), 3 * natoms, f);
  fclose(f);
  if(read != 3 * natoms)
    return 1;

  unlink(qm_in);

  return 0;
}

int ms2_file_qm_get_positions(double *pos)
{
  FILE *f;
  int read;

  f = wait_file(master_out);
  read = fread(pos, sizeof(double), 3 * natoms, f);
  fclose(f);

  if(read != 3 * natoms)
    return 1;

  // To simplify things we signal the slave to read the file by
  // renaming it with a name of our own.
  //
  // In this way we avoid a world of troubles in case the master_out
  // should remain floating around after either slave or qm have
  // finished computing the forces
  rename(master_out, qm_in);

  return 0;
}

// Forces
int ms2_file_master_get_forces(double *forces)
{
  FILE *f;
  int i, read, pos;
  
  // Read the forces from the slave
  f = wait_file(slave_out);
  read = fread(slaveforces, sizeof(double), 3 * QMatoms, f);
  fclose(f);
  if(read != 3 * QMatoms) {
    fprintf(stderr, "slave forces not correctly read at "__FILE__":%d\n", __LINE__);
    return 1;
  }
  unlink(slave_out);

  // Read the forces from the QM
  f = wait_file(qm_out);
  read = fread(qmforces, sizeof(double), 3 * QMatoms, f);
  fclose(f);
  if(read != 3 * QMatoms) {
    fprintf(stderr, "QM forces not correctly read at "__FILE__":%d\n", __LINE__);
    return 1;
  }
  unlink(qm_out);

  pos = 0;
  for(i=0;i<natoms;i++)
    if(mask[i] != -1) {
      forces[3 * i + 0] += qmforces[3 * pos + 0] - slaveforces[3 * pos + 0];
      forces[3 * i + 1] += qmforces[3 * pos + 1] - slaveforces[3 * pos + 1];
      forces[3 * i + 2] += qmforces[3 * pos + 2] - slaveforces[3 * pos + 2];
      pos++;
    }
    
  return 0;
}

int ms2_file_slave_put_forces(double *forces)
{
  FILE *f; 
  int written;

  f = fopen(slave_tmp,"w");
  if(!f) 
    return 1;

  written = fwrite(forces, sizeof(double), 3 * natoms, f);
  fclose(f);
  if(written != 3 * natoms) 
    return 1;

  rename(slave_tmp, slave_out);
  
  return 0;
}

int ms2_file_qm_put_forces(double *forces)
{
  FILE *f; 
  int written;

  f = fopen(qm_tmp,"w");
  if(!f) 
    return 1;

  written = fwrite(forces, sizeof(double), 3 * natoms, f);
  fclose(f);
  if(written != 3 * natoms) 
    return 1;
  
  rename(qm_tmp, qm_out);

  return 0;
}

int ms2_file_master_finalize(void)
{
  remove_junk();
  free_all();
  return 0;
}

int ms2_file_slave_finalize(void)
{
  remove_junk();
  free_all();
  return 0;
}

int ms2_file_qm_finalize(void)
{
  remove_junk();
  free_all();
  return 0;
}

