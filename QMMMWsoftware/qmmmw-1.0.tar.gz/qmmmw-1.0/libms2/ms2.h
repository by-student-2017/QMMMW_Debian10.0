//!
//! Copyright (C) 2011-2015 QMMMW group
//! This file is distributed under the terms of the
//! GNU General Public License version 3 (GNU-GPLv3).
//!
#ifndef MS2_CALLS_H
#define MS2_CALLS_H

#ifdef __cplusplus
extern "C" {
#endif 

  /** initialize the master LAMMPS
      argc is the number of arguments following the "master" label
      argv is an array of arguments (the ones following "master")
           it is *NOT* guaranteed that the memory will remain accessible after 
	   the initialize call is terminated, therefore a module should make a 
	   local copy of the arguments, if needed
      natoms is the total number of atoms
      selected_atoms is a natoms long array selecting the atoms in the QE subsystem
  */
  int ms2_master_initialize(int argc, char *argv[], 
			    int natoms, int *types);

  /** initialize the slave LAMMPS
      argc is the number of arguments following the "master" label
      argv is an array of arguments (the ones following "master")
           it is *NOT* guaranteed that the memory will remain accessible after 
	   the initialize call is terminated, therefore a module should make a 
	   local copy of the arguments, if needed
      natoms is the total number of atoms
  */
  int ms2_slave_initialize(int argc, char *argv[], 
			   int natoms);
 
  /** initialize the "fake-qe" LAMMPS (for testing only)
      argc is the number of arguments following the "master" label
      argv is an array of arguments (the ones following "master")
           it is *NOT* guaranteed that the memory will remain accessible after 
	   the initialize call is terminated, therefore a module should make a 
	   local copy of the arguments, if needed
      natoms is the total number of atoms

      This call is actually fully functional and could be integrated
      with QM code, the next one is however used to avoid the pain of
      building an array of strings in Fortran, from Quantum Espresso
  */
  int ms2_qm_initialize(int argc, char *argv[], 
			    int natoms);

  /** Same as above, but performing the argument splitting manually.

      It works exactly as the ms2_qm_initialize call above, with the
      only exception it passes a single string with all arguments.

      The strings are splitted in a very straightforward way, with the
      C strtok function. As for the 'common' initialization routines,
      args is not guaranteed to be persistent.
  */
  int ms2_qm_initialize_simplified(char *args, int natoms);

  /** Send the positions to the slave and qe processes */
  int ms2_master_put_positions(double *pos);
  
  /** Receive the positions from the master process */
  int ms2_slave_get_positions(double *pos);
  
  /** Receive the positions from the master process */
  int ms2_qm_get_positions(double *pos);
  
  /** Save the forces */
  int ms2_slave_put_forces(double *forces);
  
  /** Save the forces */
  int ms2_qm_put_forces(double *forces);
  
  /** Retrieve the forces  */
  int ms2_master_get_forces(double *forces);


  int ms2_master_finalize(void);
  int ms2_slave_finalize(void);
  int ms2_qm_finalize(void);
  
#ifdef __cplusplus
}
#endif 

#endif
