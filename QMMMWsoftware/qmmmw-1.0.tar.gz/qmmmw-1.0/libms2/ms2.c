//!
//! Copyright (C) 2011-2015 QMMMW group
//! This file is distributed under the terms of the
//! GNU General Public License version 3 (GNU-GPLv3).
//!
#include "ms2.h"
#include <stdlib.h>
#include <stdio.h>
#include "../libpickatoms/pickatoms.h"
#include <string.h>
#include <assert.h>
#include <dlfcn.h>


  typedef struct {
    void *libhandle;

    int (*master_init)(int, char **, int*,  int, int);
    int (*slave_init)(int, char **, int);
    int (*qm_init)(int, char **, int);
    
    int (*master_put_positions)(double *);
    int (*slave_get_positions)(double *);
    int (*qm_get_positions)(double *);    

    int (*slave_put_forces)(double *);
    int (*qm_put_forces)(double *);
    int (*master_get_forces)(double *);

    int (*master_finalize)(void);
    int (*slave_finalize)(void);
    int (*qm_finalize)(void);    
  } ms2_transport;


//! MASK with the atoms in the QM subset
int *QE_mask = NULL;
//! The number of atoms in the QM subset
int QE_atoms = -1;
//! The total number of atoms in the simulation
int natoms = -1;
//! The last error encountered
const char *ms2_error = NULL;

// The current module employed
ms2_transport *current_module = NULL;


#define DEBUG(...) {fprintf(stderr, __VA_ARGS__);};
#define ERROR(argument) {fprintf(stderr, "%s\n", argument);};
#define ERROR2(...) {fprintf(stderr, __VA_ARGS__);};



int __parse_expression(int *types, char *atoms_filename)
{
  char *tmp;
  int *tmp_array;
  int errcode;
  
  if(QE_mask != NULL) {
    ms2_error = "The module was not correctly finalized: unable to setup the MS2 support";
    return 1;
  }
    
  // Allocate a temporary array to hold a rescaled copy of the types array
  tmp_array = (int *) malloc(sizeof(int) * (natoms + 1));
  if(tmp_array == NULL) {
    ms2_error = "Not enough memory for the temporary types array in fix_ms2.cpp";
    return 1;
  }

  // Copy the types into the temporary array (shifted by 1)
  tmp_array[0] = -1;
  memcpy((void *) (tmp_array + 1), types, sizeof(int) * natoms);
  // Feed the array to libpickatoms 
  tmp = atoms_filename == NULL? NULL:(strlen(atoms_filename) == 0? NULL: atoms_filename);
  QE_mask = parse_file(natoms + 1, tmp_array, &QE_atoms, tmp);

  // Free the temporary_array
  free(tmp_array);

  // Check that the list was parsed correctly
  if(QE_mask == NULL) {
    ms2_error = "Unable to parse the expression for the selelction of the QM subset";
    return 1;
  }

  // If this doesn't happen we are in big troubles (and the value in
  // QE_atoms is also off by one...). I think is an unnecessary
  // measure though.
  assert(QE_mask[0] == -1);

  // Rescale the output: copy QE_mask[1:] into tmp_array[] and then
  // switch them
  tmp_array = (int *) malloc(sizeof(int) * natoms);
  if(tmp_array == NULL) {
    ms2_error = "Not enough memory for the temporary types array in fix_ms2.cpp";
    free(QE_mask);
    return 1;
  }

  memcpy((void *) tmp_array, (void *) (QE_mask + 1), sizeof(int) * natoms);
  free(QE_mask);
  QE_mask = tmp_array;

  return 0;
}

// Clean the content of the ms2_transport structure without deallocating it
void clean_module(void)
{
  dlclose(current_module->libhandle);
  current_module->libhandle = NULL;

  current_module->master_init = NULL;
  current_module->slave_init = NULL;
  current_module->qm_init = NULL;
    
  current_module->master_put_positions = NULL;
  current_module->slave_get_positions = NULL;
  current_module->qm_get_positions = NULL;

  current_module->slave_put_forces = NULL;
  current_module->qm_put_forces = NULL;
  current_module->master_get_forces = NULL;

  current_module->master_finalize = NULL;
  current_module->slave_finalize = NULL;
  current_module->qm_finalize = NULL;
}

/** 
    Search for a module with a name libms2_<something>.so
    
    The size of "something" is limited to 20 chars

    The library is then searched for calls in the form:

    ms2_<something>_call_names

    type is 0 for the master, 1 for the slave and 2 for qm
*/
int __search_module(char *modulename)
{
  char library_name[31];
  char call_name[60];
  void *lib;

  if(strlen(modulename) > 20) {
    fprintf(stderr, "Module name '%s' is too long (max 20 chars. allowed)\n", modulename);
    return 1;
  }

  snprintf(library_name, 31, "libms2_%s.so", modulename);  
  lib = dlopen(library_name, RTLD_NOW | RTLD_GLOBAL);
  if(!lib) {
    char *error = dlerror();
    fprintf(stderr, "Error initializing the module: '%s'\n", error);
    return 1;
  }

  // Get the structure where pointers will be saved
  if(current_module) 
    clean_module();
  else {
    current_module = (ms2_transport *) calloc(1, sizeof(ms2_transport));
    if(!current_module) {
      fprintf(stderr, "Error initializing the module: allocation error\n");    
      return 1;
    }
  }
  // Save the handle
  current_module->libhandle = lib;
  
  // Get all handles: initialization
  snprintf(call_name, 60, "ms2_%s_master_init", modulename);
  current_module->master_init = dlsym(lib, call_name);
  if(!current_module->master_init) {
    char *error = dlerror();
    fprintf(stderr, "Unable to get the symbol for 'master_init': %s\n", error);
    return 1;
  }

  snprintf(call_name, 60, "ms2_%s_slave_init", modulename);
  current_module->slave_init = dlsym(lib, call_name);
  if(!current_module->slave_init) {
    char *error = dlerror();
    fprintf(stderr, "Unable to get the symbol for 'slave_init': %s\n", error);
    return 1;
  }

  snprintf(call_name, 60, "ms2_%s_qm_init", modulename);
  current_module->qm_init = dlsym(lib, call_name);
  if(!current_module->qm_init) {
    char *error = dlerror();
    fprintf(stderr, "Unable to get the symbol for 'qm_init': %s\n", error);
    return 1;
  }

  // Positions
  snprintf(call_name, 60, "ms2_%s_master_put_positions", modulename);
  current_module->master_put_positions = dlsym(lib, call_name);
  if(!current_module->master_put_positions) {
    char *error = dlerror();
    fprintf(stderr, "Unable to get the symbol for 'master_put_positions': %s\n", error);
    return 1;
  }

  snprintf(call_name, 60, "ms2_%s_slave_get_positions", modulename);
  current_module->slave_get_positions = dlsym(lib, call_name);
  if(!current_module->slave_get_positions) {
    char *error = dlerror();
    fprintf(stderr, "Unable to get the symbol for 'slave_get_positions': %s\n", error);
    return 1;
  }

  snprintf(call_name, 60, "ms2_%s_qm_get_positions", modulename);
  current_module->qm_get_positions = dlsym(lib, call_name);
  if(!current_module->qm_get_positions) {
    char *error = dlerror();
    fprintf(stderr, "Unable to get the symbol for 'qm_get_positions': %s\n", error);
    return 1;
  }

  // Forces
  snprintf(call_name, 60, "ms2_%s_master_get_forces", modulename);
  current_module->master_get_forces = dlsym(lib, call_name);
  if(!current_module->master_get_forces) {
    char *error = dlerror();
    fprintf(stderr, "Unable to get the symbol for 'master_get_forces': %s\n", error);
    return 1;
  }

  snprintf(call_name, 60, "ms2_%s_slave_put_forces", modulename);
  current_module->slave_put_forces = dlsym(lib, call_name);
  if(!current_module->slave_put_forces) {
    char *error = dlerror();
    fprintf(stderr, "Unable to get the symbol for 'slave_put_forces': %s\n", error);
    return 1;
  }

  snprintf(call_name, 60, "ms2_%s_qm_put_forces", modulename);
  current_module->qm_put_forces = dlsym(lib, call_name);
  if(!current_module->qm_put_forces) {
    char *error = dlerror();
    fprintf(stderr, "Unable to get the symbol for 'qm_put_forces': %s\n", error);
    return 1;
  }

  // Finalization
  snprintf(call_name, 60, "ms2_%s_master_finalize", modulename);
  current_module->master_finalize = dlsym(lib, call_name);
  if(!current_module->master_finalize) {
    char *error = dlerror();
    fprintf(stderr, "Unable to get the symbol for 'master_finalize': %s\n", error);
    return 1;
  }

  snprintf(call_name, 60, "ms2_%s_slave_finalize", modulename);
  current_module->slave_finalize = dlsym(lib, call_name);
  if(!current_module->slave_finalize) {
    char *error = dlerror();
    fprintf(stderr, "Unable to get the symbol for 'slave_finalize': %s\n", error);
    return 1;
  }

  snprintf(call_name, 60, "ms2_%s_qm_finalize", modulename);
  current_module->qm_finalize = dlsym(lib, call_name);
  if(!current_module->qm_finalize) {
    char *error = dlerror();
    fprintf(stderr, "Unable to get the symbol for 'qm_finalize': %s\n", error);
    return 1;
  }

  return 0;
}

int ms2_master_initialize(int argc, char *argv[], int atom_num, int *types)
{
  int errcode;
  
  natoms = atom_num;

  // Uses the libpickatoms to select the atoms that will be copied around
  errcode = __parse_expression(types, argv[0]);
  if(errcode) {
    ERROR(ms2_error);
    return 1;
  }

  if(__search_module(argv[1])) {
    ERROR(ms2_error);
    return 1;
  }

  // The mask is guaranteed to last until the finalization of the module
  // (will not be deallocated in advance)
  return (current_module->master_init)(argc - 2, argv + 2, QE_mask, atom_num, QE_atoms);
}

int ms2_slave_initialize(int argc, char *argv[], 
			 int atom_num)
{
  natoms = atom_num;

  if(__search_module(argv[0])) {
    ERROR(ms2_error);
    return 1;
  }
  
  return (current_module->slave_init)(argc - 1, argv + 1, natoms);
}

int ms2_qm_initialize(int argc, char *argv[], 
			  int atom_num)
{
  natoms = atom_num;

  if(__search_module(argv[0])) {
    ERROR(ms2_error);
    return 1;
  }

  return (current_module->qm_init)(argc - 1, argv + 1, natoms);
}

// I think that 1024 arguments in a single string are probably enough...
#define MAX_ARGV 1024

char **convert_string_to_args(char *args, int *argc)
{
  char *ptr;      // State pointer for strtok_r
  char **argv;    // the new array of arguments
  char *res;

  fprintf(stderr, "ARGUMENTS: %s\n", args);

  assert(MAX_ARGV > 0);
  

  argv = (char **) calloc(MAX_ARGV + 1, sizeof(char *));
  if(!argv)
    return NULL;

  *argc = 0;

  // First pass
  res = strtok_r(args, "\t ", &ptr);
  if(!res) {
    ERROR2("Transport name missing ("__FILE__":%d!\n", __LINE__);
    free(argv);
    return NULL;
  }

  argv[*argc] = strdup(res);
  if(!argv[*argc]) {
    ERROR("Unable to allocate enough memory for the transport arguments");
    free(argv);
    return NULL;
  }
  *argc += 1;

  // Following arguments
  while((res = strtok_r(NULL, "\t ", &ptr)) != NULL) {
    // If you specify a string of more than 1024 tokens, a program
    // crash is what you deserve
    fprintf(stderr, "%d vs %d\n", *argc, MAX_ARGV);
    assert(*argc < MAX_ARGV);
    argv[*argc] = strdup(res);
    if(!argv[*argc]) {
      int i;
      ERROR("Unable to allocate enough memory for the transport arguments");
      for(i=*argc - 1; i>=0;i++)
	free(argv[i]);
      free(argv);
      return NULL;
    }
    *argc += 1;
  }

  argv[*argc] = NULL;

  return argv;
}
#undef MAX_ARGV

int ms2_qm_initialize_simplified(char *args, int natoms)
{
  char **argv;
  int argc, retval, i;

  // 
  argv = convert_string_to_args(args, &argc);
  if(!argv) {
    ERROR2("Unable to convert a single string to arguments in "__FILE__":%d\n", __LINE__);
    return 1;
  }

  retval = ms2_qm_initialize(argc, argv, natoms);

  // Free the memory for the arguments
  for(i=0;i<argc;i++)
    free(argv[i]);
  free(argv);
  return retval;
}

void __ms2_print_vector(double *v3ctor, int el, const char *fmt, int inc)
{
  int i;
  static int counter = 0;
  for(i=0;i<el;i++) 
    fprintf(stderr, fmt, counter, i, v3ctor[3 * i + 0], v3ctor[3 * i + 1], v3ctor[3 * i + 2]); 
  counter += inc;
}

int ms2_master_put_positions(double *pos)
{
#ifdef DEBUGINFO
  __ms2_print_vector(pos, natoms, "%d:  POS0[%d] = %12.6g %12.6g %12.6g\n", 0);
#endif
  return (current_module->master_put_positions)(pos);
}

int ms2_slave_get_positions(double *pos)
{
  return (current_module->slave_get_positions)(pos);
}

int ms2_qm_get_positions(double *pos)
{
  return (current_module->qm_get_positions)(pos);
}

int ms2_master_get_forces(double *forces)
{
#ifdef DEBUGINFO
  int res;
  __ms2_print_vector(forces, natoms, "%d:  FORCE1[%d] = %12.6g %12.6g %12.6g\n", 0);
  res = (current_module->master_get_forces)(forces);
  __ms2_print_vector(forces, natoms, "%d:  FORCE2[%d] = %12.6g %12.6g %12.6g\n", 1);
  return res;
#else
  return (current_module->master_get_forces)(forces);
#endif
}

int ms2_slave_put_forces(double *forces)
{
  return (current_module->slave_put_forces)(forces);
}

int ms2_qm_put_forces(double *forces)
{
  int i;
  return (current_module->qm_put_forces)(forces);
}

int ms2_master_finalize(void)
{
  if(QE_mask != NULL)
    free(QE_mask);
  return (current_module->master_finalize)();
}

int ms2_slave_finalize(void)
{
  return (current_module->slave_finalize)();
}

int ms2_qm_finalize(void)
{
  return (current_module->qm_finalize)();
}

  


