Documentation and various notes about the project.


portale.txt: document with a lose specification of how the portal
for QMMMW shoule behave (italian)

sintassi_selezione_atomi.txt: document with a specification of the syntax
supported by libpickatoms (italian)

atom_selection_syntax.txt: same as above, in english

configurazione_MS2daemon.txt: guide to the configuration of the
MS2daemon, mostly useful only when trying to configure the MS2
webportal (italian)

installazione_backend.txt: guide for the installation of the
scientific software (the MS2 libraries and the patched versions of
LAMMPS and QE). Italian.

quick_start_guide.txt: guide for the installation of the scientific
software (the MS2 libraries and the patched versions of LAMMPS and QE)

running_a_simulation.txt: how to create a simulation with the
Mechanical Coupling algorithm from scratch.
