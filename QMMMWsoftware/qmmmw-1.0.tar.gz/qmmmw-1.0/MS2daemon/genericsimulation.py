"""Copyright (C) 2011-2015 QMMMW group
   This file is distributed under the terms of the
   GNU General Public License version 3 (GNU-GPLv3)."""

import pickle
import os
import shutil
import logging
import time

import queue
import mylock

class GenericSimulation:

    def __init__(self, name, goptions):
        self.name = name
        self.jobid = None
        self.execdir = None
        self.dumpfile = os.path.normpath(goptions.directories.config + "/" + name)
        # Data under this line shoudn't be saved
        self._logs = logging.getLogger("MS2daemon.Simulation(%s)" % name)
        self.goptions = goptions
        self.lock     = mylock.MyLock()

    def __mangle_path(self, path):
        if self.execdir == None:
            raise IOError, "Execution directory not created"
        if not os.path.isdir(self.execdir):
            raise IOError, "The execution directory is not valid"
        newpath = os.path.normpath(self.execdir + "/" + path)
        prefix = os.path.commonprefix((self.execdir, newpath),)
        if self.execdir != prefix:
            raise IOError, "The path to list is external from the execution dir"            
        return newpath


    def __convert_size(self, size):
        """Return the size in a human readable form"""
        GIGA = 1073741824
        MEGA = 1048576
        KILO = 1024
        if size > GIGA:
            return "%.1f G" % (float(size) / GIGA)
        elif size > MEGA:
            return "%.1f M" % (float(size) /MEGA)
        elif size > KILO:
            return "%.1f K" % (float(size) / KILO)
        else:
            return "%d B" % size

    def __convert_time(self, mtime):
        now = time.localtime()
        mtime = time.localtime(mtime)
        if now.tm_yday != mtime.tm_yday:
            return "%.2d-%.2d-%d" % (mtime.tm_mday, mtime.tm_mon, mtime.tm_year)
        else:
            return "%.2d:%.2d:%.2d" % (mtime.tm_hour, mtime.tm_min, mtime.tm_sec)        

    def list_files(self, path, complete_path = False):
        """Return the files and directories in a path internal to the exec. dir

        returns IOError if the path is not valid"""
        oldpath = path
        path = self.__mangle_path(path)
        if not os.path.isdir(path):
            raise IOError, "The path to list is not a directory"        
        objs = os.listdir(path)
        lista = []
        for obj in objs:
            fullpath = os.path.normpath(path + "/" + obj)
            name = obj
            if complete_path:
                name = os.path.normpath(path + "/" + name)
            stat = stat = os.stat(fullpath)
            mtime = self.__convert_time(stat.st_mtime)
            if os.path.isdir(fullpath):
                name += "/"
                size = ""
            else:
                size = self.__convert_size(stat.st_size)
            lista.append((name, size, mtime))

        lista.append((".", 0, os.stat(path).st_mtime))
            
        if path != self.execdir:
            lista.append(("..", 0, os.stat(path + "/..").st_mtime))
            
        return (os.path.normpath(oldpath), lista)

    def list_files_recursive(self, path = None):
        """Return the files and directories in a path internal to the exec. dir

        returns IOError if the path is not valid"""
        if path == None:
            origpath = ""
            path = "/"
        else:
            origpath = path
        path = self.__mangle_path(path)
        objs = os.listdir(path)
        lista = [origpath]
        for obj in objs:
            fullpath = os.path.normpath(path + "/" + obj)
            name = obj
            stat = stat = os.stat(fullpath)
            if os.path.isdir(fullpath):
                lista.append(self.list_files_recursive(origpath + "/" + obj))
            else:
                mtime = stat.st_mtime
                size = stat.st_size
                lista.append((name, size, mtime)) 
            
        return lista
    
    def get_file(self, path, maxsize, strict = True):
        """Get a file from the execution directory

        If the file is bigger than maxsize, or if anything else
        happens, return IOError, return content of the file on success"""
        path = self.__mangle_path(path)
        if not os.path.isfile(path):
            raise IOError, "The path provided doesn't point to a file"
        f = file(path)
        data = f.read(maxsize)
        f.close()
        # In a tradeoff safety vs optimization, i decided to make the
        # check for the file after the data is downloaded to avoid
        # inconsistencies betwe
        size = os.stat(path).st_size
        if strict and size > maxsize:
            raise IOError, "The file is bigger than the maximum download limit"
        return data
    
    def is_configured(self):
        """ This function should be overridden"""
        raise NotImplemented, "This function should be overridden"

    def __is_private(self, path):
        """Returns True if the path is in a subdirectory of execdir, False otherwise

        If the base directory doesn't exist return False anyway"""
        normpath = os.path.normpath(path)
        if self.execdir == None:
            return False
        if not os.path.isdir(self.execdir):
            return False
        if self.execdir.find(normpath) != 0:
            return False
        return True

    def job_status(self, extended_info = False):
        self._logs.debug("Getting the status of the simulation")
        if self.jobid == None:
           raise RuntimeError, "No job running"
        try:
            if extended_info:
                status = queue.Queue.qstat_extended(self.jobid,
                                                self.goptions.submission.qstat)
            else:
                status = queue.Queue.qstat(self.jobid,
                                           self.goptions.submission.qstat)
            return status
        except RuntimeError, error:
            self._logs.error("Unable to perform '%s' on '%s': %s" % (self.goptions.submission.qstat,
                                                                     self.jobid,
                                                                     error))
            self.jobid = None
            return "X"

    def is_running(self):
        # No jobid == no execution
        if self.jobid == None:
            return False
        # Check if the code is running, otherwise
        try:
            status = self.job_status()
            if status == "R":
                return True
            return False
        except RuntimeError:
            return False

    def save(self):
        # Remove the data that shouldn't/can't be pickled
        g   = self.goptions
        # This is a _problem_ that requires a solution in the acquire and islocked functions
        l   = self.lock
        log = self._logs
        self.goptions = None
        self.lock     = None
        self._logs    = None
        
        # Save
        f = file(self.dumpfile, "w")
        pickle.dump(self, f)
        f.close()
        
        # Restore the removed data
        self.goptions = g
        self.lock     = l
        self._logs    = log

    def acquire(self):
        while self.lock == None:
            time.sleep(0.2)
        self.lock.acquire()
    
    def release(self):
        # This while should actually never be executed...
        while self.lock == None:
            time.sleep(0.2)
        self.lock.release()
    
    def locked(self):
        if self.lock == None:
            return True
        return self.lock.locked()

    @staticmethod
    def restore(name, goptions):
        f = file(os.path.normpath(goptions.directories.config + "/" + name), "r")
        obj = pickle.load(f)
        f.close()
        # Create the missing fields
        obj.lock     = mylock.MyLock()
        obj.goptions = goptions
        obj._logs    = logging.getLogger("MS2daemon.Simulation(%s)" % name)
        return obj

    # Requires a similar function in the inheritor
    def _configure_simulation(self):
        """Create a directory and upload the data to start a new simulation"""
        
        dirname = os.path.normpath(self.goptions.directories.execution \
                                   + "/"                               \
                                   + self.name)
        try:
            os.makedirs(dirname)
        except OSError, err:
            if err[0] != 17:
                self._logs.error("Directory '%s' not created: %s" % (dirname, err))
                raise RuntimeError, "Unable to create the execution directory '%s'" % dirname
            self._logs.info("Directory '%s' already exists" % dirname)
        self.execdir = dirname
        self.save()
        # This function MUST be overridden for submit to work!
        return None

    # MOVE TO QMMMSimulation!
    def submit(self, nodes, processors, time):
        """Submit a simulation."""

        # This shouldn't happen anyway
        if not self.is_configured():
            self._logs.debug("Unable to start simulation: not configured properly")
            return 1

        if self.is_running():
            self._logs.debug("Starting of '%s' failed: the simulation appears to be already running" % self.name)
            return 1

        try:
            script = self._configure_simulation()
        except:
            return 1
        if script == None:
            self._logs.error("Unable to start the simulation: configure simulation not correctly overridden")
            return 1

        try:
            handler = queue.Queue.qsub(script,
                                       nodes,
                                       processors,
                                       time,
                                       qsub = self.goptions.submission.qsub)
        except RuntimeError, error:
            self._logs.error("Submission failed: %s" % error)
            return 1

        self._logs.info("Submission succeded, handler obtained: '%s'\n" % handler)
        self.jobid = handler
        return 0

    def cancel(self):
        """Stop the simulation using the queue manager

        Not advisable when an alternative is available"""
        if self.jobid == None:
            self._logs.info("No jobid available")
            return 1
        try:
            queue.Queue.qdel(self.jobid,
                              self.goptions.submission.qdel)
        except RuntimeError, error:
            self._logs.error("Simulation cancel failed: %s" % error)
            return 1
        return 0

    def stop(self):
        """Stop cleanly the simulation"""
        raise NotImplemented, "Not implemented, dude!"
                          
    def destroy(self):
        """Remove every trace of a simulation on the FS/queues"""
        self._logs.debug("Trying to stop the simulation, if running...")
        try:
            self.cancel()
        except RuntimeError, error:
            pass
        self._logs.debug("Removing the files in the execution directory...")
        if self.execdir != None:
            try:
                shutil.rmtree(self.execdir)
            except:
                pass
        self._logs.debug("Removing any dump file")
        try:
            os.unlink(self.dumpfile)
        except:
            pass

        
