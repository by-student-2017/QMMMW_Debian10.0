# Copyright (C) 2011-2015 QMMMW group
# This file is distributed under the terms of the
# GNU General Public License version 3 (GNU-GPLv3).

import copy, os, shutil, re

import genericsimulation
import dumpfile

# Various constants. Some of them shoudn't be changed: when this
# applies, it will be noted
MASTER_DIR = "master"
SLAVE_DIR  = "slave"
QE_DIR     = "qe"
# Don't change this: it's referenced in the input file for QE
PSEUDO_DIR = "qe/pseudo"
# Input files
MASTER_INPUT = "master.in"
SLAVE_INPUT  = "slave.in"
QE_INPUT     = "qe.in"
# Output streams
MASTER_OUTPUT = "log.lammps"
SLAVE_OUTPUT  = "log.lammps"
QE_OUTPUT     = "qe.out"
# Error streams
MASTER_ERROR = "master.err"
SLAVE_ERROR  = "slave.err"
QE_ERROR     = "qe.err"
# This value matches the one on the portal templates and shouldn't be
# changed!
DATA_FILE = "data.ms2"
# This value should not be changed since the name of the simulation for QE will always be ms2
QE_EXIT_FILE = "ms2.EXIT"
# Do not change this value (is the same found in the master input template
ATOMS_FILE = "atoms.txt"
# Don't change this: the value is hard coded in the template
DUMP_FILE = "dump.xyz"
# Same as above for both RESTART_
RESTART_REGEXP = "restart_([0-9]+)\.bin"
RESTART_FILE= "restart_%d.bin"


class QMMMSimulation(genericsimulation.GenericSimulation):

    def __init__(self, name, goptions, pseudocache):
        genericsimulation.GenericSimulation.__init__(self, name, goptions)
        self.qmmminput = None

        self.dumpfile = os.path.normpath(goptions.directories.config + "/" + name + ".qmmm")
        # Do not save this
        self._cache = pseudocache

    def is_configured(self):
        if self.qmmminput == None:
            return False
        for data in self.qmmminput:
            if data == None:
                return False
        for pseudo in self.qmmminput.pseudo_list:
            if not self._cache.isavail(pseudo):
                return False
        return True

    def configure(self, qmmminput):
        # Get a copy of the data and save it
        self._logs.debug("Configuring the simulation")
        self.qmmminput = copy.deepcopy(qmmminput)
        missing = []
        for pseudo in self.qmmminput.pseudo_list:
            if not self._cache.isavail(pseudo):
                self._logs.error("While configuring the simulation: missing pseudo %s" % pseudo)
                missing.append(pseudo)
        if len(missing) != 0:
            return True
        return False

    def _genscript(self, desc):
        """Generate a script to execute the simulation.

        This function is actually executed in the directory where the
        script is supposed to be, so getcwd returns the private
        location for the simulation"""
        self._logs.debug("Generating the start script")
        desc.write("#!/bin/bash\n")
        # Append a preamble, if the case
        if self.goptions.submission.preamble != None:
            self._logs.debug("Appending the preamble '%s' to the script..." \
                             % self.goptions.submission.preamble)
            try:
                g = file(self.goptions.submission.preamble)
                preamble = g.read()
                g.close()
                desc.write(preamble)
            except IOError, error:
                self._logs.error("Unable to read the preamble (%s) for the submission: %s" % \
                                 (self.goptions.submission.preamble, error))
                raise RuntimeException, error
        desc.write("cd %s\n" % os.getcwd())
        desc.write("""echo 'Starting the master LAMMPS' >logs.txt
pushd %s
nohup  %s <%s >%s 2>%s &
popd
sleep 2
""" % (MASTER_DIR, self.goptions.executables.lammps,
       MASTER_INPUT, MASTER_OUTPUT, MASTER_ERROR))
        # Start the slave process
        desc.write("""echo 'Starting the slave LAMMPS' >>logs.txt
pushd %s
nohup %s <%s >%s 2>%s &
popd
""" % (SLAVE_DIR, self.goptions.executables.lammps,
       SLAVE_INPUT, SLAVE_OUTPUT, SLAVE_ERROR))
        # Start the QE process, with mpirun
        desc.write("""echo 'Starting QE' >>logs.txt
pushd %s
NPROCS=`wc -l < $PBS_NODEFILE`
nohup %s -machinefile $PBS_NODEFILE -np $NPROCS %s <%s >%s 2>%s
popd
""" % (QE_DIR, self.goptions.executables.mpirun, self.goptions.executables.pw,
       QE_INPUT, QE_OUTPUT, QE_ERROR))
        # That's it...

    def crash_happened(self):
        """Returns True if a CRASH file is present, False otherwise"""
        if self.execdir == None:
            return False
        return os.path.isfile(self.execdir + "/" + QE_DIR + "/CRASH")

    def _configure_simulation(self):
        """This function will be executed before the qsub command is completed"""
        # Create the main directory for the simulation
        # Any exception will be catch by the submit method in GenericSimulation
        genericsimulation.GenericSimulation._configure_simulation(self)

        startdir = os.getcwd()
        # In here we can do whatever we like
        os.chdir(self.execdir)
        try:
            scriptname = "%s_start.sh" % self.name
            f = file(scriptname, "w")
            self._genscript(f)
            f.close()
            os.chmod(scriptname, 0700)

            # Using this horror i'll create the whole directory/data tree for the execution
            # only pseudo files will be missing
            filestruct = ((MASTER_DIR, ((MASTER_INPUT, self.qmmminput.master_config),
                                        (DATA_FILE,    self.qmmminput.master_data),
                                        (ATOMS_FILE,   self.qmmminput.selected_atoms))),
                          (SLAVE_DIR, ((SLAVE_INPUT, self.qmmminput.slave_config),
                                       (DATA_FILE,    self.qmmminput.slave_data))),
                          (QE_DIR, ((QE_INPUT, self.qmmminput.qe_config), )),
                          (PSEUDO_DIR, ()))
            # For each directory there's a data structure
            for dirname, files in filestruct:
                self._logs.debug("Creating the directory '%s'" % dirname)
                try:
                    os.mkdir(dirname)
                except OSError, err:
                    if err[0] != 17:
                        raise RuntimeError, "Unable to create directory '%s'" % dirname
                    # If a directory already exists, ignore
                    pass
                olddir = os.getcwd()
                os.chdir(dirname)
                try:
                    # for each data structure, dump the relevant files
                    for filename, data in files:
                        self._logs.debug("    * writing '%s'" % filename)                
                        try:
                            f = file(filename, "w")
                            f.write(data)
                            f.close()
                        except IOError, error:
                            raise RuntimeError, "Unable to create '%s': %s" % (filename, error)
                finally:
                    os.chdir(olddir)
                            
            # copy the pseudo
            self._logs.debug("Filling the directory '%s'" % PSEUDO_DIR)
            olddir = os.getcwd()
            os.chdir(PSEUDO_DIR)
            try:
                for pseudo in self.qmmminput.pseudo_list:
                    pseudofile = self._cache.getlocation(pseudo)
                    self._logs.debug("    * writing '%s' (from '%s')" % (pseudo, pseudofile))
                    try:
                        shutil.copy(pseudofile, pseudo)
                    except IOError, error:
                        raise RuntimeError, "Unable to copy the pseudo '%s': %s" % (pseudo, error)
            finally:
                os.chdir(olddir)
            # Remove any restart file
            self._logs.debug("Removing the restarts in the master dir (if any...)")
            for filename in os.listdir(MASTER_DIR):
                if not re.match(RESTART_REGEXP, filename):
                    continue
                try:
                    os.unlink(os.path.normpath(MASTER_DIR + "/" + restart))
                except OSError, error:
                    self._logs.error("'%s' found but not removed (%s)!" % (restart, error))
            # Remove any old dump file
            self._logs.debug("Removing the dump file in the master dir (if any...)")
            try:
                os.unlink(os.path.normpath(MASTER_DIR + "/" + DUMP_FILE))
            except OSError, error:
                self._logs.debug("dump file not removed: %s" % error)                
            # Remove any CRASH file in QE
            self._logs.debug("Removing the QE CRASH file (if any...)")
            try:
                os.unlink(os.path.normpath(QE_DIR + "/CRASH"))
            except OSError, error:
                self._logs.debug("CRASH file not removed: %s" % error)
            # Remove the EXIT FILE!!!!!
            self._logs.debug("Removing the QE exit file (if any...)")
            try:
                os.unlink(os.path.normpath(QE_DIR + "/" + QE_EXIT_FILE))
            except OSError, error:
                self._logs.debug("exit files not removed: %s" % error)
        finally:
            os.chdir(startdir)
        # Return the script that will be executed
        return os.path.normpath(self.execdir + "/" + scriptname)

    def steps_done(self):
        """Return the number of steps done by crossing the number of restart and the number of frames in the xyz
        
        -1 returned on error"""
        try:
            if self.execdir == None:
                return 0
            master_dir = os.path.normpath(self.execdir + "/" + MASTER_DIR)
            # Get the full path of the dumpfile
            dumpf = os.path.normpath(master_dir + "/" + DUMP_FILE)
            # Get the biggest restart so far
            try:
                maxrestart = max([ int(re.match(RESTART_REGEXP, restart).group(1))
                                   for restart in os.listdir(master_dir)
                                   if re.match(RESTART_REGEXP, restart) ])
            except ValueError:
                return 0
            # Find out how many frames are in the dump file
            d = dumpfile.DumpFile(dumpf)
            frames = d.get_nframes()
            steps = min(frames - 1, maxrestart)
            self._logs.debug("returning %d steps done (%d restarts, %d frames)" % (steps, maxrestart, frames))
            return steps
        except (IOError, ValueError), error:
            self._logs.error("unable to compute the number of steps done: %s" % error)
            return -1

    def get_xyz(self, frames):
        if self.execdir == None:
            return None
        master_dir = os.path.normpath(self.execdir + "/" + MASTER_DIR)
        dumpf = os.path.normpath(master_dir + "/" + DUMP_FILE)
        try:
            d = dumpfile.DumpFile(dumpf)            
            return d.get_frames(frames)
        except (IOError, ValueError), error:
            self._logs.error("unable to get the data requested: %s" % error)
            return None
        except Exception, error:
            self._logs.error("UNHANDLED EXCEPTION: '%s'" % error)
            return None

    def get_last_restart(self):
        if self.execdir == None:
            return None
        master_dir = os.path.normpath(self.execdir + "/" + MASTER_DIR)
        try:
            maxrestart = max([ int(re.match(RESTART_REGEXP, restart).group(1))
                               for restart in os.listdir(master_dir)
                               if re.match(RESTART_REGEXP, restart) ])
        except ValueError:
            return None
        filepath = os.path.normpath(master_dir + "/" + RESTART_FILE % maxrestart)
        f = file(filepath)
        data = f.read()
        f.close()
        return data

    class __LogFile:
        _f = None

        def __init__(self, filename):
            self._f = file(filename)

        def _count_lines(self):
            try:
                return len(self._f.readlines())
            finally:
                self._f.seek(0)

        def getlines(self, lines):
            self._f.seek(0)
            if lines == 0:
                # Return the whole file
                return self._f.read()
            if lines > 0:
                # Return the data up to 'lines' lines
                data = ""
                for linenum in range(lines):
                    tmp = self._f.readline()
                    if tmp == "":
                        break
                    data += tmp
                return data
            if lines < 0:
                # Return the data from the end of the file
                numlines = self._count_lines()
                start = max(numlines + lines, 0)
                data = ""
                # Skip the first lines
                for linenum in range(start):
                    self._f.readline()
                # Read the rest, if any
                while True:
                    tmp = self._f.readline()
                    if tmp == "":
                        return data
                    data += tmp

        def __del__(self):
            if self._f != None:
                self._f.close()
            
    def getlogs(self, lines):
        """Returns some lines from all logs in the simulation"""
        if self.execdir == None:
            return None
        if not os.path.isdir(self.execdir):
            return None
        logs = []
        for dirname, filename in ((MASTER_DIR, MASTER_OUTPUT), 
                                  (MASTER_DIR, MASTER_ERROR), 
                                  (SLAVE_DIR, SLAVE_OUTPUT), 
                                  (SLAVE_DIR, SLAVE_ERROR), 
                                  (QE_DIR, QE_OUTPUT), 
                                  (QE_DIR, QE_ERROR)):
            try:
                l = self.__LogFile(os.path.normpath(self.execdir + "/" + dirname + "/" + filename))
                logs.append(l.getlines(lines))
                del(l)
            except IOError: 
                logs.append("")
                continue
        return logs

    def did_run(self):
        """Call added for moka, but also useful for the portal"""
        # Check if the simulation did run (examine the master output file)
        if self.execdir == None:
            return 0
        master_output = os.path.normpath(self.execdir + "/" + MASTER_DIR + "/" + MASTER_OUTPUT)
        if os.path.isfile(master_output):
            return 1
        return 0

    def stop(self):
        if not self.is_running():
            return 1
        stopfile = os.path.normpath(self.execdir + "/" + QE_DIR + "/" + QE_EXIT_FILE)
        f = file(stopfile + "_", "w")
        f.close()
        os.rename(stopfile + "_", stopfile)
        return 0
        
    def save(self):
        c = self._cache
        self._cache = None
        genericsimulation.GenericSimulation.save(self)
        self._cache = c

    @staticmethod
    def restore(name, goptions, cache):
        obj = genericsimulation.GenericSimulation.restore(name, goptions)
        obj._cache = cache
        return obj
        

if __name__ == "__main__":
    # Test the module
    import globaloptions, pseudocache, QMMMinput, queue
    import logging, logging.handlers
    # Set up a logger
    logs = logging.getLogger("MS2daemon")
    logs.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")    
    handler = logging.handlers.RotatingFileHandler("/dev/shm/logs.txt", maxBytes = 1024000, backupCount = 5)
    handler.setFormatter(formatter)
    logs.addHandler(handler)
    print "Setting up some structures"
    g = globaloptions.GlobalOptions()
    g.submission.preamble = "/usr/local/ms2/ms2.env"
    cache = pseudocache.PseudoCache(g)
    q = QMMMinput.QMMMInput()
    # Anonymous files aren't a good idea. Who cares in this circumstance...
    water_shm = "/home/dimeo/work/water_ms2"
    q.master_config  = file(water_shm + "/master/in.water").read()
    q.master_data    = file(water_shm + "/master/data.ms2").read()
    q.slave_config   = file(water_shm + "/slave/in.water_reduced").read()
    q.slave_data     = file(water_shm + "/slave/data.ms2").read()
    q.qe_config      = file(water_shm + "/qe/water.in").read()
    q.selected_atoms = "1,2,3"
    q.pseudo_list    = ["H.pbe-van_ak.UPF", "O.pbe-van_bm.UPF"]
    
    print "* Creating a new simulation..."
    name = raw_input("Simulation name: ")
    c = QMMMSimulation(name, g, cache)
    
    print "* Saving the simulation..."
    c.save()
    
    print "* Restoring the simulation..."
    d = QMMMSimulation.restore(name, g, cache)
    
    print "* Is the simulation configured? ", c.is_configured()
    
    print "* Configuring the simulation (pseudo might not be present)..."
    c.configure(q)
    
    print "* Is the simulation configured, now? ", c.is_configured()
    
    print "* Testing the cache first"
    for pseudo in q.pseudo_list:
        if not cache.isavail(pseudo):
            print "  + reading %s from water_ms2" % pseudo
            f = file("/home/dimeo/work/water_ms2/qe/pseudo/" + pseudo)
            pseudodata = f.read()
            f.close()
            print "  + uploading %s in the cache" % pseudo
            cache.upload(pseudo, pseudodata)
    print "* all pseudo are surely now available!"
    
    print "* Is the simulation configured, now? ", c.is_configured()
    
    print "* Try to dump the simulation again..."
    c.save()
    
    print "* ...and restore it too"
    d = QMMMSimulation.restore(name, g, c)
    
    print "* Is there any processor available?", queue.Queue.showbf(queue = g.submission.queue)

    print "* Submit...   result:",
    print c.submit(1, 2, 1000)


    while True:
        try:
            print "* Status:  ", c.job_status()
            print "* Is running? ", c.is_running()
        except RuntimeError, error:
            print "Error: ", error
        print c.jobid
        if len(raw_input("key + enter to stop")) != 0:
            break
        
    c.stop()
    while True:
        try:
            print "* Status:  ", c.job_status()
            print "* Is running? ", c.is_running()
        except RuntimeError, error:
            print "Error: ", error
        print c.jobid
        if len(raw_input("key + enter to stop")) != 0:
            break
    
    answer = raw_input("destroy the simulation? " ).upper()
    if answer == "Y" or answer == "1":
        c.destroy()
    

