#!/usr/bin/env python

#Copyright (C) 2011-2015 QMMMW group
#This file is distributed under the terms of the
#GNU General Public License version 3 (GNU-GPLv3).


# Standard components
import time
import thread
import os
import base64
import logging

# Custom modules
import queue
import QMMMinput
import QMMMsimulation
import QMinput
import QMsimulation
import MMinput
import MMsimulation
import pseudocache

# Twisted modules
from twisted.web import xmlrpc

import geometry

GEOMETRY_FILE = "clustergeometry.xml"            
        
class SupportedCalls(xmlrpc.XMLRPC):

    allowNone = True

    def init(self, goptions, restore = True):
        """Init the class.

        xmlrpc introspection apparently doesn't like __init__...

        options is a GeneralOptions instance"""
        self.simulations = {}
        self.master_lock = thread.allocate_lock()
        self.goptions = goptions
        # Initialize the logs
        self._logs = logging.getLogger("MS2daemon.SupportedCalls")
        # Repository with the pseudo
        self.cache = pseudocache.PseudoCache(self.goptions)
        self._logs.debug("SupportedCalls initialized")
        # Search for simulation files
        if restore:
            self.__recover_simulations()
        try:
            self.geometry = geometry.Geometry(GEOMETRY_FILE)
        except IOError, err:
            self.geometry = None
            self._log.warning("Unable to open the geometry file '%s': %s. Calls requiring it will not work" % (GEOMETRY_FILE, err[1]))
        except ValueError, err:
            self.geometry = None
            self._logs.warning("Unable to parse '%s': calls which use the cluster geometry will not work!" % GEOMETRY_FILE)

    ##########################
    # Upload a pseudopotential 
    def xmlrpc_upload_pseudo(self, pseudoname, data):
        """Upload a pseudopotential into the repository

        name: the destination filename where the data will be written
        (it will be stripped of any directory reference)
        data: the content of the pseudo file.

        The destination might be overwritten.

        0               : success
        positive integer: returns the errno of the fopen call, if it fails

        It is user's responsability not to submit multiple pseudo with
        the same name at once.
        """
        self._logs.debug("Uploading a new pseudopotential '%s'" % pseudoname)
        # Open the destination
        filename = os.path.basename(pseudoname)
        res = self.cache.upload(filename, data)
        return res

    ######################################
    # Return the list of configured pseudo
    def xmlrpc_list_pseudo(self):
        """Returns the list of pseudo present.

        Not completely thread safe (and it doesn't really matter)
        """
        # Open the destination
        self._logs.debug("Returning the full list of uploaded pseudopotentials")
        pseudolist = self.cache.listavail()
        return pseudolist
    
    def _lock_simulation(self, name):
        self._logs.debug("Locking '%s'" % name)
        self.master_lock.acquire()
        try:
            if not self.simulations.has_key(name):
                self._logs.debug("Lock of '%s' failed: no such simulation" % name)
                return 3
            if self.simulations[name].locked():
                self._logs.debug("Lock of '%s' failed: already locked" % name)
                return 2
            self.simulations[name].acquire()
            self._logs.debug("'%s' locked" % name)
            return 0
        finally:
            self.master_lock.release()
 
    def _unlock_simulation(self, name):
        self._logs.debug("Releasing '%s'" % name)
        self.master_lock.acquire()
        try:
            self.simulations[name].release()
        finally:
            self.master_lock.release()


    def __recover_simulations(self):
        """Recover any simulation in the simulation directory.

        This method doesn't require locking, since it is executed at
        the initialization, before the server starts"""
        self._logs.info("Restoring old simulations")
        simdir = self.goptions.directories.config
        simfiles = os.listdir(simdir)
        self._logs.info("Found '%s' simulation files" % len(simfiles))
        for filename in simfiles:
            try:
                name, extension = filename.split(".")
            except Exception, err:
                self._logs.error("Unable to restore file '%s'" % filename)
                continue
            if extension.lower() == "qmmm":
                try:
                    self.simulations[name] = \
                        QMMMsimulation.QMMMSimulation.restore(filename,
                                                              self.goptions,
                                                              self.cache)
                except Exception, err:
                    self._logs.error("Unable to restore QMMM simulation '%s': %s" % (name, err))
                    continue
            elif extension.lower() == "qm":
                try:
                    self.simulations[name] = \
                        QMsimulation.QMSimulation.restore(filename,
                                                          self.goptions,
                                                          self.cache)
                except Exception, err:
                    self._logs.error("Unable to restore QM simulation '%s': %s" % (name, err))
                    continue
            elif extension.lower() == "mm":
                try:
                    self.simulations[name] = \
                        MMsimulation.MMSimulation.restore(filename,
                                                          self.goptions)                                                          
                except Exception, err:
                    self._logs.error("Unable to restore MM simulation '%s': %s" % (name, err))
                    continue
            else:
                self._logs.error("Unable to restore simulation '%s': unknown extension (%s)" % (name, 
                                                                                                extension))
                continue

                

            self._logs.info("%s restored (running = %s, configured = %s)" % (name,
                                                                             self.simulations[name].is_running(),
                                                                             self.simulations[name].is_configured()))
    ###########################
    # Register a new simulation
    def xmlrpc_register_simulation(self, name, ignored):
        """This call just create the space for a new simulation.

        the 'ignored' parameter is there just for the sake of
        compatibility and is, as the name, ignored.

        1 is returned if the simulation could not be created (which
        means that it exists already), 0 is returned otherwise.
        """
        self._logs.debug("Creating a new simulation '%s'" % name)
        self.master_lock.acquire()
        try:
            if self.simulations.has_key(name):
                self._logs.debug("Failed to create simulation '%s': already present" % name)
                return 1
            self.simulations[name] = QMMMsimulation.QMMMSimulation(name, self.goptions, self.cache)
            self._logs.debug("Simulation '%s' created correctly" % name)
            return 0
        finally:
            self.master_lock.release()

    ###########################
    # Register a new simulation
    def xmlrpc_register_QM_simulation(self, name, ignored = None):
        """This call just create the space for a new simulation.

        the 'ignored' parameter is there just for the sake of
        compatibility and is, as the name, ignored.

        1 is returned if the simulation could not be created (which
        means that it exists already), 0 is returned otherwise.
        """
        self._logs.debug("Creating a new simulation QM '%s'" % name)
        self.master_lock.acquire()
        try:
            if self.simulations.has_key(name):
                self._logs.debug("Failed to create simulation '%s': already present" % name)
                return 1
            self.simulations[name] = QMsimulation.QMSimulation(name, self.goptions, self.cache)
            self._logs.debug("Simulation '%s' created correctly" % name)
            return 0
        finally:
            self.master_lock.release()

    ###########################
    # Register a new simulation
    def xmlrpc_register_MM_simulation(self, name, ignored = None):
        """This call just create the space for a new simulation.

        the 'ignored' parameter is there just for the sake of
        compatibility and is, as the name, ignored.

        1 is returned if the simulation could not be created (which
        means that it exists already), 0 is returned otherwise.
        """
        self._logs.debug("Creating a new simulation MM '%s'" % name)
        self.master_lock.acquire()
        try:
            if self.simulations.has_key(name):
                self._logs.debug("Failed to create simulation '%s': already present" % name)
                return 1
            self.simulations[name] = MMsimulation.MMSimulation(name, self.goptions)
            self._logs.debug("Simulation '%s' created correctly" % name)
            return 0
        finally:
            self.master_lock.release()

    ##############################
    # Return a list of simulations
    def xmlrpc_known_simulations(self):
        """Return a list of simulations known to the system

        For each simulation a tuple is returned, with:

        (name, [01])

        0: registered, not configured simulation
        1: configured simulation in some state
        """        
        self._logs.debug("Returning the list of simulations already present")
        self.master_lock.acquire()
        try:
            lista = []
            simlist = self.simulations.keys()
            for name in simlist:
                status = 0
                if self.simulations[name].is_configured():
                    status += 1
                if isinstance(self.simulations[name], QMsimulation.QMSimulation):
                    status += 128
                if isinstance(self.simulations[name], MMsimulation.MMSimulation):
                    status += 256
                lista.append((name, status))
            return lista
        finally:
            self.master_lock.release()
            
    ##########################################################
    # Returns a list of available processors, and for how long
    def xmlrpc_available_processors(self):
        """Returns a list of tuples in the form:

        (number of proc, time in seconds)

        If time is -1, then no timelimit is present.

        If no processor is available, an empty tuple is returned"""
        self._logs.debug("Returning the list of available processors")
        try:
            avail = queue.Queue.showbf(showbf = self.goptions.submission.showbf,
                                      queue  = self.goptions.submission.queue)
        except RuntimeError, error:
            self._logs.error("While querying the number of CPUs: %s" % error)
            avail = ((-1,0),)
        except Exception,error:
            self._logs.error("While querying the number of CPUs: %s" % error)
            avail = ((-1,0),)
            
        self._logs.error("The processors available are: %s" % avail)
        return avail

    ######################################################
    # Enqueue a simulation with x processors for y seconds
    def xmlrpc_start_simulation(self, name, nodes, processors, seconds):
        self._logs.debug("Starting simulation '%s' on %d nodes with %d processors for %d seconds" % (name, nodes, processors, seconds))
        res = self._lock_simulation(name)
        if res:
            return res
        try:
            return self.simulations[name].submit(nodes, processors, seconds)
        finally:
            self._unlock_simulation(name)
            
    ####################################
    # Stop the simulation in a clean way
    def xmlrpc_stop_simulation(self, name):
        """Stop the simulation in a natural way.

        After a little while, the simulation should be stopped"""
        self._logs.debug("Stopping simulation '%s'" % name)
        res = self._lock_simulation(name)
        if res:
            return res
        try:
            return self.simulations[name].stop()
        finally:
            self._unlock_simulation(name)

    ####################################
    # Stop the simulation the hard way
    def xmlrpc_kill_simulation(self, name):
        """To be used only if, after stopping the simulation, it doesn't halt after a while.

        This command kills the simulation using the queue system.

        Returns 0 on success, 1 on error (although  is
        returned even in not-so-uncommon situations, like if the
        status of a job is checked a while after it has been cancelled
        """
        self._logs.debug("Killing simulation '%s'" % name)
        res = self._lock_simulation(name)
        if res:
            return res
        try:
            return self.simulations[name].cancel()
        finally:
            self._unlock_simulation(name)
            
    #####################
    # Remove a simulation
    def xmlrpc_destroy_simulation(self, name):
        """Remove every trace of a simulation"""
        self._logs.debug("Destroying simulation '%s'" % name)
        res = self._lock_simulation(name)
        if res:
            return res
        # Required when the reference is removed
        self.master_lock.acquire()
        try:
            tmp = self.simulations[name]
            del(self.simulations[name])
        finally:
            # From now on, the simulation is detached and we don't
            # need the master lock anymore
            self.master_lock.release()
        # Release the lock. Not that it does matter
        tmp.release()
        # Destroy the simulation
        tmp.destroy()
        del(tmp)
        return 0
    
    ##################################################################################
    # Check the status of the simulation
    def xmlrpc_simulation_status(self, name, extended_info = False):
        self._logs.debug("Querying the status of '%s' (extended = %s)" % (name, extended_info))
        res = self._lock_simulation(name)
        if res:
            return (res, "")
        try:
            try:
                return tuple([0] + list(self.simulations[name].job_status(extended_info)))
            except RuntimeError, error:
                self._logs.error("Unable to query the status of the simulation: %s" % error)
                return (1,"")
        finally:
            self._unlock_simulation(name)

    ##################################################################################
    # Check the status of the simulation
    def xmlrpc_simulation_did_run(self, name):
        self._logs.debug("Was '%s' executed at some point?" % name)
        res = self._lock_simulation(name)
        if res:
            return (res, "")
        try:
            try:
                return (0, self.simulations[name].did_run())
            except RuntimeError, error:
                self._logs.error("Unable to check if the simulation did ran: %s" % error)
                return (1,"")
        finally:
            self._unlock_simulation(name)
            
    ###############################################################################################
    # Check the status of the simulation: fast workaround to provide moka with the simulation title
    def xmlrpc_simulation_status2(self, name, title):
        self._logs.debug("Querying the status of '%s' (and echoing the title '%s')" % (name, title))
        res = self._lock_simulation(name)
        if res:
            return (res, "", name, title)
        try:
            try:
                return (0, self.simulations[name].job_status(), title)
            except RuntimeError, error:
                self._logs.error("Unable to query the status of the simulation: %s" % error)
                return (1,"", title)
        finally:
            self._unlock_simulation(name)

    ##################################
    # Setup a simulation for execution
    def xmlrpc_configure_simulation(self, name,
                                    master_config, master_data,
                                    slave_config, slave_data,
                                    qe_config,
                                    pseudo_list, atom_subset):
        """Fully configures a simulation.

        master_config: the content of the config file of the main LAMMPS
        master_data  : the content of the data file of the main LAMMPS
        slave_config : the content of the config file of the secondary LAMMPS
        slave_data   : the content of the data file of the secondary LAMMPS
        qe_config    : the content of the config file of PWscf        
        pseudo_list  : a list of pseudopotentials to register (they
                       should be already uploaded)
        atom_subset  : a string with the espression used to select the QE subset

        This function returns 0 if the simulation was properly
        configured, or 1 otherwise."""    
        
        self._logs.debug("Configuring simulation '%s': passing the config files and selecting the subset '%s'" % (name, atom_subset))
        res = self._lock_simulation(name)
        if res:
            return res
        try:
            qmmm = QMMMinput.QMMMInput()
            qmmm.master_config  = master_config
            qmmm.master_data    = master_data
            qmmm.slave_config   = slave_config
            qmmm.slave_data     = slave_data
            qmmm.qe_config      = qe_config
            qmmm.selected_atoms = atom_subset
            qmmm.pseudo_list    = pseudo_list
            retval = self.simulations[name].configure(qmmm)
            if retval:
                self._logs.debug("Failed to configure '%s': some pseudopotentials are missing!" % name)
                return 1
            return 0
        finally:
            self._unlock_simulation(name)

    ##################################
    # Setup a simulation for execution
    def xmlrpc_configure_MM_simulation(self, name,
                                       master_config, master_data):
        """Fully configures a simulation.

        master_config: the content of the config file of the main LAMMPS
        master_data  : the content of the data file of the main LAMMPS

        This function returns 0 if the simulation was properly
        configured, or 1 otherwise."""    
        
        self._logs.debug("Configuring a MM simulation '%s': passing the config files" % name)
        res = self._lock_simulation(name)
        if res:
            return res
        try:
            # per validare l'input mi servirebbe almeno un mese di lavoro... ci sara' da ridere
            mm = MMinput.MMInput()
            mm.master_config  = master_config
            mm.master_data    = master_data
            retval = self.simulations[name].configure(mm)
            return 0
        finally:
            self._unlock_simulation(name)

    ##################################
    # Setup a simulation for execution
    def xmlrpc_configure_QM_simulation(self, name,
                                       qe_config,
                                       pseudo_list = None):
        """Fully configures a QM only simulation.

        qe_config    : the content of the config file of PWscf        
        pseudo_list  : a list of pseudopotentials to register (they
                       should be already uploaded)

        This function returns 0 if the simulation was properly
        configured, or 1 otherwise."""    
        
        self._logs.debug("Configuring a QM simulation '%s'" % name)
        res = self._lock_simulation(name)
        if res:
            return res
        try:
            if QMinput.QMInput.validate_input(qe_config):
                self._logs.info("Input file not validated: rejected")
                return 1
            if pseudo_list == None:
                pseudo_list = QMinput.QMInput.get_pseudolist(qe_config)
                if pseudo_list == None:
                    self._logs.info("Input file not validated: unable to get the pseudo list")
                    return 1
            qm = QMinput.QMInput()
            qm.qe_config      = qe_config
            qm.pseudo_list    = pseudo_list
            retval = self.simulations[name].configure(qm)
            if retval:
                self._logs.debug("Failed to configure '%s': some pseudopotentials are missing!" % name)
                return 1
            return 0
        finally:
            self._unlock_simulation(name)            
            
    ####################################################
    # return 1 if the simulation is configured, 0 if not
    def xmlrpc_is_configured(self, name):
        self._logs.debug("See if '%s' is configured" % name)
        res = self._lock_simulation(name)
        if res:
            return (res, 0)
        try:
            if self.simulations[name].is_configured():
                return 1
            return 0
        finally:
            self._unlock_simulation(name)

    ####################################
    # Returns the number of steps done by the simulation
    def xmlrpc_getsteps(self, name):
        """Return the number of steps done by the simulation."""
        self._logs.debug("Getting the number of steps performed by '%s'" % name)
        res = self._lock_simulation(name)
        if res:
            return (res, 0)
        try:
            data = self.simulations[name].steps_done()
            if data == -1:
                return (1, 0)
            return (0, data)
        finally:
            self._unlock_simulation(name)

    ####################################
    # Tell the caller if the simulation crashed
    def xmlrpc_crash_happened(self, name):
        """Return True if a CRASH file is present."""
        self._logs.debug("Finding out if '%s' crashed..." % name)
        res = self._lock_simulation(name)
        if res:
            return res
        try:
            if self.simulations[name].crash_happened():
                return 4 
            else:
                return 0
        finally:
            self._unlock_simulation(name)

    ####################################
    # Return some frames
    def xmlrpc_get_xyz(self, name, frames):
        """Return the number of steps done by the simulation."""
        self._logs.debug("Getting %s frames of XYZ for '%s'" % (frames,name))
        res = self._lock_simulation(name)
        if res:
            return (res, "")
        try:
            data = self.simulations[name].get_xyz(frames)
            if data == None:
                return (1, "")
            return (0, data)
        finally:
            self._unlock_simulation(name)

    #########################################
    # Return the last restart present, if any
    def xmlrpc_get_restart(self,name):
        """Return the last restart coded in base 64."""
        self._logs.debug("Getting the last restart from '%s'" % name)
        res = self._lock_simulation(name)
        if res:
            return (res, "")
        try:
            restart = self.simulations[name].get_last_restart()
            if restart == None:
                return (1, "")
            return (0, base64.b64encode(restart))
        finally:
            self._unlock_simulation(name)

    def xmlrpc_getlogs(self, name, lines):
        """Return an array with all logs"""
        self._logs.debug("Getting all logs from '%s'" % name)
        res = self._lock_simulation(name)
        if res:
            return (res, "")
        try:
            logs = self.simulations[name].getlogs(lines)
            if logs == None:
                return (1, "")
            return (0, logs)
        finally:
            self._unlock_simulation(name)

    ####################################
    # List a directory in the simulation
    def xmlrpc_list_directory(self, name, path):
        self._logs.debug("Listing '%s' for simulation '%s'" % (path, name))
        res = self._lock_simulation(name)
        if res:
            return (res, ())
        try:
            try:
                return self.simulations[name].list_files(path, True)
            except IOError, error:
                self._logs.error("While listing %s: '%s'" % (name, error))
                return (1, ())
        finally:
            self._unlock_simulation(name)

    ####################################
    # List a directory in the simulation
    def xmlrpc_list_recursive(self, name):
        self._logs.debug("Listing all dirs for simulation '%s'" %  name)
        res = self._lock_simulation(name)
        if res:
            return (res, ())
        try:
            try:
                return self.simulations[name].list_files_recursive()
            except IOError, error:
                self._logs.error("While listing recursively %s: '%s'" % (name, error))
                return (1, ())
        finally:
            self._unlock_simulation(name)
            
    ####################################
    # List a directory in the simulation
    def xmlrpc_get_binfile(self, name, filename, maxsize, strict):
        if strict == 0:
            strict = False
        else:
            strict = True
        self._logs.debug("Getting '%s' from simulation '%s' (strict = %s, maxsize = %d)" \
                         % (filename, name, strict, maxsize))
        res = self._lock_simulation(name)
        if res:
            return (res, "")
        try:
            try:
                return (0, base64.b64encode(self.simulations[name].get_file(filename, maxsize, strict)))
            except IOError, error:
                self._logs.error("While getting %s: '%s'" % (name, error))
                return (1, "")
        finally:
            self._unlock_simulation(name)


#### CALLS PROVIDED FOR MOKA #####################

    def xmlrpc_get_cluster_geometry(self):
        """Returns a string with a xml specification of the resources on the cluster

        The geometry specification should be something like:

	<QUEUE_LIST>
	  <QUEUE name="">
	    <PROC_X_NODE><integer>12</integer></PROC_X_NODE>
	    <MIN_NODES><integer>8</integer></MIN_NODES>
	    <MAX_NODES><integer>8</integer></MAX_NODES>
	    <MIN_PROC><integer>6</integer></MIN_PROC>   
	    <MAX_PROC><integer>12</integer></MAX_PROC>
	    <MEMORY><integer>48</integer></MEMORY>
	    <MAX_WALLTIME><integer>172800</integer></MAX_WALLTIME>
	    <DESCRIPTION><string>Default queue. Mirrors the queue "sun"</string></DESCRIPTION>
	    <NOTES><string>No additional constraints</string></NOTES>
	  </QUEUE>
	</QUEUE_LIST>
	

        Since at the moment there's no way to tap the specifications
        from the cluster (root priviledges are required, among the
        other things...), this call just loads an hand-made file from
        the local filesystem"""
        if self.geometry == None:
            return (1, "")
        return (0, self.geometry.data)

    def xmlrpc_submit_by_geometry(self, name, data):
        """Submit a job from XML

        FIXME: 'sta cosa non tiene in conto i requisiti di memoria o
        di altro genere. A fare una roba come questa, ma generale, ci
        sara' da ridere.

        The request should be of this type:
        
        <REQUEST>
           <QUEUE><string></string></QUEUE>
           <NODES><integer>8</integer></NODES>
           <PROCESSORS><integer>12</integer></PROCESSORS>
           <WALLTIME><integer>3600</integer></WALLTIME>
        </REQUEST>

        1 is returned is the submission failes, 2 and 3 are reserved
        for the default errors, 4 is returned if the request can't be
        satisfied and 5 is returned if no geometry file is present.

        0 is returned on success."""
        if self.geometry == None:
            return 5

        res = self.geometry.validate_request(data)
        if len(res) == 0:
            self._logs.debug("Request not validated")
            return 4
        self._logs.debug("Request validated, result: %s nodes %s procs %s seconds" % res)
        
        args = (name, res[0], res[1], res[2])
        # Submit the simulation
        return apply(self.xmlrpc_start_simulation, args)

#### HIC SUNT LEONES #############################
        

    ###### TEST  CALLS #########################
    def xmlrpc_test(self, number):
        print "number"
        return number * 2

    def xmlrpc_test2(self, number):
        print "too tired!"
        time.sleep(20)
        print "number"
        return number * 2
    
    def xmlrpc_test2(self, number, multiplier = 2):
        print "Test 2"
        return number * multiplier


#    xmlrpc_upload_pseudo.signature = [["pseudoname","data"]]
#    xmlrpc_list_pseudo.signature = [[]]
#    xmlrpc_register_simulation.signature = [["name","ignored"]]
#    xmlrpc_known_simulations.signature = [[]]
#    xmlrpc_available_processors.signature = [[]]
#    xmlrpc_start_simulation.signature = [["name","nodes","processors","seconds"]]
#    xmlrpc_stop_simulation.signature = [["name"]]
#    xmlrpc_kill_simulation.signature = [["name"]]
#    xmlrpc_destroy_simulation.signature = [["name"]]
#    xmlrpc_simulation_status.signature = [["name"]]
#    xmlrpc_configure_simulation.signature = [["name","master_config","master_data","slave_config","slave_data","qe_config","pseudo_list","atom_subset"]]
#    xmlrpc_configure_QM_simulation.signature = [["name","qe_config","pseudo_list"]]
#    xmlrpc_getsteps.signature = [["name"]]
#    xmlrpc_crash_happened.signature = [["name"]]
#    xmlrpc_get_xyz.signature = [["name","frames"]]
#    xmlrpc_get_restart.signature = [["name"]]
#    xmlrpc_getlogs.signature = [["name","lines"]]
#    xmlrpc_list_directory.signature = [["name","path"]]
#    xmlrpc_list_recursive.signature = [["name"]]
#    xmlrpc_get_binfile.signature = [["name","filename","maxsize","strict"]]
#    xmlrpc_get_cluster_geometry.signature = [[]]
#    xmlrpc_submit_by_geometry.signature = [["name","data"]]
#    xmlrpc_test.signature = [["number"]]
#    xmlrpc_test2.signature = [["number"]]
#    
    ###########################################

if __name__ == "__main__":
    import globaloptions
    import logging, logging.handlers
    # Set up a logger
    logs = logging.getLogger("MS2daemon")
    logs.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")    
    handler = logging.handlers.RotatingFileHandler("/dev/shm/logs.txt", maxBytes = 1024000, backupCount = 5)
    handler.setFormatter(formatter)
    logs.addHandler(handler)
    print "Setting up some structures"
    g = globaloptions.GlobalOptions()
    g.submission.preamble = "/usr/local/ms2/ms2.env"
    q = QMMMinput.QMMMInput()
    # Anonymous files aren't a good idea. Who cares in this circumstance...
    water_shm = "/home/dimeo/work/water_ms2"
    q.master_config  = file(water_shm + "/master/in.water").read()
    q.master_data    = file(water_shm + "/master/data.ms2").read()
    q.slave_config   = file(water_shm + "/slave/in.water_reduced").read()
    q.slave_data     = file(water_shm + "/slave/data.ms2").read()
    q.qe_config      = file(water_shm + "/qe/water.in").read()
    q.selected_atoms = "1,2,3"
    q.pseudo_list    = ["H.pbe-van_ak.UPF", "O.pbe-van_bm.UPF"]

    # Create the instance that emulates the xmlrpc calls
    recover = raw_input("Recover? [yes]").upper()
    if recover == "N" or recover == "0":
        print "Recovering the simulation"
        sc = SupportedCalls(g, False)
    else:
        print "Creating from scratch the simulation"
        sc = SupportedCalls(g, True)
        
    known = sc.xmlrpc_known_simulations()
    print "The list of known simulation is: ", known
    

    print "The available processors are: ", sc.xmlrpc_available_processors()

    pseudo_avail = sc.xmlrpc_list_pseudo()
    print "Pseudo potentials available: ", pseudo_avail

    print "Uploading missing pseudopotentials..."
    for pseudo in q.pseudo_list:
        try:
            pseudo_avail.index(pseudo)
            continue
        except ValueError:
            pass
        print "  + reading %s from water_ms2" % pseudo
        f = file("/home/dimeo/work/water_ms2/qe/pseudo/" + pseudo)
        pseudodata = f.read()
        f.close()
        print "  + uploading %s in the cache" % pseudo
        sc.xmlrpc_upload_pseudo(pseudo, pseudodata)

    name = raw_input("Simulation name: ")
    if dict(known).has_key(name):
        print "The simulation '%s' appears to be already registered!" % name
    else:
        if sc.xmlrpc_register_simulation(name, True):
            print "Unable to register the simulation %s" % name
            raise SystemExit,0

    print "Simulation status: ", sc.xmlrpc_simulation_status(name)

    print "Trying to start a simulation..."
    res = sc.xmlrpc_start_simulation(name, 1, 2, 1000)
    if res:
        print "Didn't worked... Let's configure it first", sc.xmlrpc_configure_simulation(name,
                                                                                          q.master_config, q.master_data,
                                                                                          q.slave_config, q.slave_data,
                                                                                          q.qe_config,
                                                                                          q.pseudo_list, q.selected_atoms)
        
        print "Trying to start a simulation..."
        res = sc.xmlrpc_start_simulation(name, 1, 2, 1000)
        if res:
            print "Why isn't it working again??!?!?!"
            raise SystemExit, 1

    while True:
        print "Simulation status: ", sc.xmlrpc_simulation_status(name)
        if len(raw_input("key + enter to stop")) != 0:
            break
                                  
    sc.xmlrpc_stop_simulation(name)
    # sc.xmlrpc_kill_simulation(name)

    while True:
        print "Simulation status: ", sc.xmlrpc_simulation_status(name)
        if len(raw_input("key + enter to stop")) != 0:
            break

    destroy = raw_input("Destroy? [no]").upper()
    if destroy == "Y" or destroy == "1":
        sc.xmlrpc_destroy_simulation(name)

    
        

             
