#!/usr/bin/env python

# Copyright (C) 2011-2015 QMMMW group
# This file is distributed under the terms of the
# GNU General Public License version 3 (GNU-GPLv3).

import os
import sys
try:
    from OpenSSL import SSL
    sslavail = True
except ImportError:
    sslavail = False
    
from twisted.internet import reactor, ssl
from twisted.web import server, xmlrpc

import logging
import logging.handlers
import optparse

import globaloptions
import supportedcalls

# Error codes
PARSING_ERROR      = 1  # Something nasty during config parsing
NO_CONFIG_FILE     = 2  # The config file is missing
CERTIFICATES_ERROR = 3  # The certificates are screwd up (probably...)

# Constants and default values
MS2_LOGFILE = "MS2daemon.log"
MS2_CONFIGFILE = os.path.normpath(os.getenv("HOME", ".") + "/" + ".MS2daemon")

# Used only for the certificates
def verifyCallback(connection, x509, errnum, errdepth, ok):
    if not ok:
        logs.warning('Invalid cert from subject:', x509.get_subject())
        return False
    else:
        logs.info("Cert from subject '%s' is fine" % x509.get_subject())
        return True

class MS2daemon:
        
    def __init__(self,
                 authenticated = False,
                 port = None,
                 restore = False,
                 config_file = None,
                 logfile = None,
                 verbose = False,
                 debug = False):
        """initialize the daemon.

        config_file a file, which can be even empty or non existent,
                    where the configuration should be found.

        logfile the place where the logs will be saved. None stands
                for 'no logfile' (highly discouraged).  If the logfile
                isn't an absolute path, it is taken as a path relative
                from $HOME (or the current directory, if HOME is not
                defined).
        """
        if debug:
            verbose = True

        # If none, use the one in the configuration, otherwise
        # override the value in the configuration
        self.port = port
            
        # Start the logging
        self._setup_logs(logfile, verbose, debug)
        # Read the options

        if config_file == None:
            # If no config file is specified, it's ok to use the one in home, if present
            if os.path.isfile(MS2_CONFIGFILE):
                config_file = MS2_CONFIGFILE
        else:
            # If the configuration file is set by the user, do not forgive an mistake
            if not os.path.isfile(config_file):
                self._logs.error("Configuration file '%s' is not present (and was explicitly requested)!" % config_file)
                raise SystemExit, NO_CONFIG_FILE
                        
        if config_file != None:
            try:
                self._logs.info("About to read the configuration from '%s'" % config_file)
                self.goptions = globaloptions.GlobalOptions.fromconfigfile(config_file)
            except ValueError, error:
                self._logs.error("Configuration not read (%s)!" % error)
                raise SystemExit, PARSING_ERROR
        else:
            # If no config file was present in home, we will write down the default configuration, forgive and forget
            self._logs.info("No config found: using the default values (and dumping them in %s)" % MS2_CONFIGFILE)
            self.goptions = globaloptions.GlobalOptions()
            # Overwrite the configuration
            self.goptions.toconfigfile(MS2_CONFIGFILE)

        # Create the instance with the xmlrpc calls
        self.supported_calls = supportedcalls.SupportedCalls()
        self.supported_calls.init(self.goptions, restore)
        
        # This is the list of simulations available
        self._logs.debug("MS2daemon instantiated")
        self._logs.debug("The server is authenticated: %s" % authenticated)
        self._logs.debug("The server resores the sims: %s" % restore)
        self._logs.debug("The server config is in:     %s" % config_file)
        self._logs.debug("The server is logging in:    %s" % logfile)
        self._logs.debug("The server verbose flag is:  %s" % verbose)
        self._logs.debug("The server debug flag is:    %s" % debug)

        self.authenticated = authenticated
        
    def setup_server(self):
        if self.port == None:
            self.port = self.goptions.server.port
            
        if not self.authenticated:
            #Plain
            self._logs.info("Setting up a plain server on port %d" % self.port)
            xmlrpc.addIntrospection(self.supported_calls)
            reactor.listenTCP(self.port,
                              server.Site(self.supported_calls))
        else:
            #SSL
            # Create a context factory
            ctxfactory = ssl.DefaultOpenSSLContextFactory(
                self.goptions.server.privkey,
                self.goptions.server.certificate)
            # Create a context
            ctx = ctxfactory.getContext()
            # add a callback for the verification of the certificates
            ctx.set_verify(
                SSL.VERIFY_PEER | SSL.VERIFY_FAIL_IF_NO_PEER_CERT,
                verifyCallback)
            # This is the list with the accepted certificates
            ctx.load_verify_locations(self.goptions.server.cafile)
            # Start the server
            self._logs.info("Setting up a TSL server on port %d" % self.goptions.server.port)
            reactor.listenSSL(self.port,
                              server.Site(self.supported_calls),
                              ctxfactory)
            
    def serve_forever(self):
        reactor.run()

    def _setup_logs(self, logfile, verbose, debug):
        # If export is not defined, let's the user deal with the consequences...
        home = os.getenv("HOME", ".")
        if not os.path.isabs(logfile):
            self._logfile = os.path.normpath(home + "/" + logfile)
        else:
            self._logfile = logfile
        self._logs = logging.getLogger("MS2daemon")
        if debug:
            self._logs.setLevel(logging.DEBUG)
        else:
            if verbose:
                self._logs.setLevel(logging.INFO)
            self._logs.setLevel(logging.WARNING)
        formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
        if self._logfile != None:
            handler = logging.handlers.RotatingFileHandler(self._logfile, maxBytes = 1024000, backupCount = 5)
            handler.setFormatter(formatter)
            self._logs.addHandler(handler)
        self._logs.info("############## MS2daemon starting ##############")


def daemonize():
    """This code is based on (ripped from...) an example by Chad Schroeder (kudos)

    The original can be found at:

    http://code.activestate.com/recipes/278731-creating-a-daemon-the-python-way/

    Only minor changes applied"""

    import os
    import sys
    import stat

    # Although not canonical, I don't want other processes mess with the daemon files
    UMASK = 0066
    WORKDIR = "/"

    MAXFD = 1024

    if (hasattr(os, "devnull")):
        REDIRECT_TO = os.devnull
    else:
        REDIRECT_TO = "/dev/null"

    try:
        pid = os.fork()
    except OSError, err:
        raise Exception, "%s [%s]" % (e.strerror, e.errno)

    if pid != 0:
        # Exit the parent. _exit doesn't call any finalizing function
        os._exit(0)

    # Become the leader of the process group
    os.setsid()

    # Fork again to prevent the child to ever get a controlling terminal
    try:
        pid = os.fork()
    except OSError, err:
        raise Exception, "%s [%s]" % (e.strerror, e.errno)
        
    if pid != 0:
        # Exit the parent again
        os._exit(0)

    # Change the working directory and mask
    os.chdir(WORKDIR)
    os.umask(UMASK)

    # Resource usage information.
    # If the default value is infinity, then use the default value
    import resource    
    maxfd = resource.getrlimit(resource.RLIMIT_NOFILE)[1]
    if (maxfd == resource.RLIM_INFINITY):
        maxfd = MAXFD  

    for fd in range(0, maxfd):
        try:
            os.close(fd)
        except OSError: # ERROR, fd wasn't open to begin with (ignored)
            pass

    # Redirect the standard I/O file descriptors to the specified file.  Since
    # the daemon has no controlling terminal, most daemons redirect stdin,
    # stdout, and stderr to /dev/null.  This is done to prevent side-effects
    # from reads and writes to the standard I/O file descriptors.
    
    # This call to open is guaranteed to return the lowest file descriptor,
    # which will be 0 (stdin), since it was closed above.
    os.open(REDIRECT_TO, os.O_RDWR)

    # Duplicate standard input to standard output and standard error.
    os.dup2(0, 2) # standard output (1)
    os.dup2(0, 1) # standard error (2)

    return 0


def parse_command_line():
    """Parse the command line and start the daemon"""
    parser = optparse.OptionParser()

    parser.add_option("-p",
                      "--port",
                      default = None,
                      help="listening port for the server (default: use the option in the config file)",
                      dest = "port",
                      metavar = "PORT",
                      type = "int")

    
    parser.add_option("-l",
                      "--logfile",
                      default = MS2_LOGFILE,
                      help="place where logs will be stored (default %s)" % MS2_LOGFILE,
                      dest = "logfile",
                      metavar = "FILE")
    
    parser.add_option("-d",
                       "--debug",                       
                       action = "store_true",
                       help="turn on the debugging output in the logs (implies -v)",
                       default = False)
    
    
    parser.add_option("-v",
                       "--verbose",
                       default = False,
                       action = "store_true",
                       help="turn on the verbose output in the logs")
    
    parser.add_option("-c",
                       "--configfile",
                       default = None,
                       help= "location of the config file (rel. paths are resolved from $HOME. Default: %s)" % MS2_CONFIGFILE,
                       dest = "configfile",
                       metavar = "FILE")

    parser.add_option("-f",
                      "--foreground",
                      default = False,
                      action = "store_true",
                      help= "Don't fork the daemon",
                      dest = "foreground")

    parser.add_option("-r",
                      "--restore",
                      default = False,
                      action = "store_true",
                      help = "Restore existing simulations",
                      dest = "restore")

    parser.add_option("-n",
                      "--noauth",
                      default = True,
                      action = "store_false",
                      help= "Don't use the SSL layer (useful for debugging only)",
                      dest = "authenticated")    
    
    (options, args) = parser.parse_args()

    if options.authenticated and not sslavail:
        sys.stderr.write("Unable to find the OpenSSL package for python and authentication was requested")
        raise SystemExit, 1

    return options

if __name__ == "__main__":
    import sys
    options = parse_command_line()
    
    if not options.foreground:
        print "Daemonizing the server..."
        daemonize()

    daemon = MS2daemon(authenticated = options.authenticated,
                       port        = options.port,
                       restore     = options.restore,
                       logfile     = options.logfile,
                       config_file = options.configfile,
                       verbose     = options.verbose,
                       debug       = options.debug)
    
    logs = logging.getLogger("MS2daemon.certificates")
    try:
        daemon.setup_server()
    except SSL.Error, error:
        logs.error("Unable to initialize the authenticated server (check the certificates)!")
        raise SystemExit, CERTIFICATES_ERROR
    daemon.serve_forever()
    



