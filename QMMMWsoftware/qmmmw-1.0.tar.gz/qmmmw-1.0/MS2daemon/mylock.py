"""Copyright (C) 2011-2015 QMMMW group
   This file is distributed under the terms of the
   GNU General Public License version 3 (GNU-GPLv3)."""

import thread

class MyLock:
    def __init__(self):
        self.__lock = thread.allocate_lock()
    
    def __getattr__(self, attr):
        if attr[:2] != "__":
            return getattr(self.__lock, attr)
        raise AttributeError, attr
