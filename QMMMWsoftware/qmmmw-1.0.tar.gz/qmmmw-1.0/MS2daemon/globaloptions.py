"""Copyright (C) 2011-2015 QMMMW group
   This file is distributed under the terms of the
   GNU General Public License version 3 (GNU-GPLv3)."""

import pickle
from ConfigParser import *

# Server
DEFAULT_PORT = 23000
DEFAULT_ADDRESS = "0.0.0.0"
# Security
DEFAULT_CERTIFICATE = "keys/server.crt"
DEFAULT_CAFILE = "keys/ca.pem"
DEFAULT_PRIVKEY = "keys/server.key"
# Directories
DEFAULT_EXECUTION = "/dev/shm/ms2"
DEFAULT_CONFIG = "/dev/shm/config"
DEFAULT_PSEUDO = "/dev/shm/pseudo"
# Executables
DEFAULT_PW = "/usr/local/ms2/bin/pw_ms2.x"
DEFAULT_LAMMPS = "/usr/local/ms2/bin/lmp_ms2"
DEFAULT_MPIRUN = "/usr/bin/mpirun.mpich-shmem"
DEFAULT_QSUB = "qsub"
DEFAULT_QSTAT = "qstat"
DEFAULT_QDEL = "qdel"
DEFAULT_QUEUE = "test"
DEFAULT_SHOWBF = "showbf"
DEFAULT_PREAMBLE = "/usr/local/ms2/ms2.env"
DEFAULT_MAXWINDOW = 172800

def _get_string_fromcfg(instance, section, option):
    try:
        d = instance.get(section, option)
    except (NoOptionError, NoSectionError):
        return None
    if d == "":
        return None
    return d

def _get_int_fromcfg(instance, section, option):
    try:
        d = instance.get(section, option)
    except (NoOptionError, NoSectionError):
        return None
    if d == "":
        return None
    try:
        return int(d)
    except ValueError, error:
        raise ValueError, "Reading the config. file: unable to coerce '%s' to an int" % d
        
        

class Server:
    """Subclass with the server options"""
    port = DEFAULT_PORT
    address = DEFAULT_ADDRESS
    certificate = DEFAULT_CERTIFICATE
    cafile = DEFAULT_CAFILE
    privkey = DEFAULT_PRIVKEY

    def __str__(self):
        output = "***** Server\n"
        output += "port        = %s\n" % self.port
        output += "address     = %s\n" % self.address
        output += "certificate = %s\n" % self.certificate
        output += "cafile      = %s\n" % self.cafile
        output += "privkey     = %s\n" % self.privkey
        return output

    @staticmethod
    def fromcfg(cfg):
        server = Server()
        
        port =  _get_int_fromcfg(cfg, "Server", "port")
        if port:
            server.port = port

        address =  _get_string_fromcfg(cfg, "Server", "address")
        if address:
            server.address = address

        certificate =  _get_string_fromcfg(cfg, "Server", "certificate")
        if certificate:
            server.certificate = certificate

        cafile =  _get_string_fromcfg(cfg, "Server", "cafile")
        if cafile:
            server.cafile = cafile

        privkey =  _get_string_fromcfg(cfg, "Server", "privkey")
        if privkey:
            server.privkey = privkey
        return server

    def tocfg(self, cfg):
        cfg.add_section("Server")
        if self.port != None:
            cfg.set("Server", "port", str(self.port))
        if self.address != None:
            cfg.set("Server", "address", self.address)
        if self.certificate != None:
            cfg.set("Server", "certificate", self.certificate)
        if self.cafile != None:
            cfg.set("Server", "cafile", self.cafile)
        if self.privkey != None:
            cfg.set("Server", "privkey", self.privkey)
            
class Directories:
    """Subclass with the directories names"""
    execution = DEFAULT_EXECUTION
    config = DEFAULT_CONFIG
    pseudo = DEFAULT_PSEUDO

    def __str__(self):
        output = "***** Directories\n"
        output += "execution = %s\n" % self.execution
        output += "config    = %s\n" % self.config
        output += "pseudo    = %s\n" % self.pseudo
        return output

    def tocfg(self, cfg):
        cfg.add_section("Directories")
        if self.execution != None:
            cfg.set("Directories", "execution", self.execution)
        if self.config != None:
            cfg.set("Directories", "config", self.config)
        if self.pseudo != None:
            cfg.set("Directories", "pseudo", self.pseudo)

    @staticmethod
    def fromcfg(cfg):
        directories = Directories()
        
        execution =  _get_string_fromcfg(cfg, "Directories", "execution")
        if execution:
            directories.execution = execution
            
        config =  _get_string_fromcfg(cfg, "Directories", "config")
        if config:
            directories.config = config
            
        pseudo =  _get_string_fromcfg(cfg, "Directories", "pseudo")
        if pseudo:
            directories.pseudo = pseudo
            
        return directories            

class Executables:
    """Subclass with the executables names"""
    pw    = DEFAULT_PW
    lammps = DEFAULT_LAMMPS
    mpirun = DEFAULT_MPIRUN

    def __str__(self):
        output = "***** Executables\n"
        output += "pw     = %s\n" % self.pw
        output += "lammps = %s\n" % self.lammps
        output += "mpirun = %s\n" % self.mpirun
        return output

    @staticmethod
    def fromcfg(cfg):
        executables = Executables()
        
        pw =  _get_string_fromcfg(cfg, "Executables", "pw")
        if pw:
            executables.pw = pw
            
        lammps =  _get_string_fromcfg(cfg, "Executables", "lammps")
        if lammps:
            executables.lammps = lammps
            
        mpirun =  _get_string_fromcfg(cfg, "Executables", "mpirun")
        if mpirun:
            executables.mpirun = mpirun
            
        return executables
    
    def tocfg(self, cfg):
        cfg.add_section("Executables")
        if self.pw != None:
            cfg.set("Executables", "pw", self.pw)
        if self.lammps != None:
            cfg.set("Executables", "lammps", self.lammps)
        if self.mpirun != None:
            cfg.set("Executables", "mpirun", self.mpirun)
            
class Submission:
    """Subclass with the details about the submission"""
    qsub  = DEFAULT_QSUB
    qstat = DEFAULT_QSTAT
    qdel  = DEFAULT_QDEL
    queue = DEFAULT_QUEUE
    showbf = DEFAULT_SHOWBF
    preamble = DEFAULT_PREAMBLE
    maxwindow = DEFAULT_MAXWINDOW

    def __str__(self):
        output = "***** Submission\n"
        output += "qsub      = %s\n" % self.qsub
        output += "qstat     = %s\n" % self.qstat
        output += "qdel      = %s\n" % self.qdel
        output += "queue     = %s\n" % self.queue
        output += "showbf    = %s\n" % self.showbf
        output += "preamble  = %s\n" % self.preamble
        output += "maxwindow = %s\n" % self.maxwindow
        return output

    @staticmethod
    def fromcfg(cfg):
        submission = Submission()
        
        qsub =  _get_string_fromcfg(cfg, "Submission", "qsub")
        if qsub:
            submission.qsub = qsub

        qstat =  _get_string_fromcfg(cfg, "Submission", "qstat")
        if qstat:
            submission.qstat = qstat

        qdel =  _get_string_fromcfg(cfg, "Submission", "qdel")
        if qdel:
            submission.qdel = qdel

        queue =  _get_string_fromcfg(cfg, "Submission", "queue")
        if queue:
            submission.queue = queue

        showbf =  _get_string_fromcfg(cfg, "Submission", "showbf")
        if showbf:
            submission.showbf = showbf

        preamble =  _get_string_fromcfg(cfg, "Submission", "preamble")
        if preamble:
            submission.preamble = preamble
            
        maxwindow =  _get_int_fromcfg(cfg, "Submission", "maxwindow")
        if maxwindow:
            submission.maxwindow = maxwindow
        return submission

    def tocfg(self, cfg):
        cfg.add_section("Submission")
        if self.qsub != None:
            cfg.set("Submission", "qsub", self.qsub)
            
        if self.qstat != None:
            cfg.set("Submission", "qstat", self.qstat)
            
        if self.qdel != None:
            cfg.set("Submission", "qdel", self.qdel)
            
        if self.queue != None:
            cfg.set("Submission", "queue", self.queue)
            
        if self.showbf != None:
            cfg.set("Submission", "showbf", self.showbf)
            
        if self.preamble != None:
            cfg.set("Submission", "preamble", self.preamble)
            
        if self.maxwindow != None:
            cfg.set("Submission", "maxwindow", str(self.maxwindow))
            
    

class GlobalOptions:
    def __init__(self):
        self.server      = Server()
        self.directories = Directories()
        self.executables = Executables()
        self.submission  = Submission()

    def __str__(self):
        output = "Content of the options:\n"
        output += str(self.server)
        output += str(self.directories)
        output += str(self.executables)
        output += str(self.submission)
        return output

    def tostring(self):
        return pickle.dumps(self)
    
    @staticmethod
    def fromstring(data):
        return pickle.loads(data)

    def tofile(self, filename):
        f = file(filename, "w")
        pickle.dump(self, f)
        f.close()

    @staticmethod
    def fromfile(filename):
        f = file(filename)
        obj = pickle.load(f)
        f.close()
        return obj

    @staticmethod
    def fromconfigfile(filename):
        cfg = SafeConfigParser()
        try:
            cfg.read(filename)
        except Exception,error:
            raise ValueError,error
        g = GlobalOptions()
        g.server = Server.fromcfg(cfg)
        g.directories = Directories.fromcfg(cfg)
        g.submission = Submission.fromcfg(cfg)
        g.executables = Executables.fromcfg(cfg)
        return g

#cfgfile.set(config.MS2_SECTION_LOCATIONS, "pseudodir", self.pseudodir)   

    def toconfigfile(self, filename):
        cfg = SafeConfigParser()
        self.server.tocfg(cfg)
        self.directories.tocfg(cfg)
        self.submission.tocfg(cfg)
        self.executables.tocfg(cfg)
        # Write the configuration
        f = file(filename, "w")
        cfg.write(f)
        f.close()
    
if __name__ == "__main__":
    d = GlobalOptions()
    s = d.tostring()
    h = GlobalOptions.fromstring(s)
    print d,h
