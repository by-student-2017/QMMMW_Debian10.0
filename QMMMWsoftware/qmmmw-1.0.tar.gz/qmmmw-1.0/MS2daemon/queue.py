"""Copyright (C) 2011-2015 QMMMW group
   This file is distributed under the terms of the
   GNU General Public License version 3 (GNU-GPLv3)."""

import re
import subprocess

class Queue:
    @staticmethod
    def parse_time(string):
        """Transforms a string in the form (dd:)hh:mm:ss in seconds"""
        MUL = (1, 60, 3600, 3600 * 24)
        values = [int(num) for num in string.split(":")]
        values.reverse()
        total = 0
        for index, val in enumerate(values):
            total += MUL[index] * val
        return total

    @staticmethod
    def qdel(jobid, qdel = "qdel"):
        command = qdel + " " + jobid
        proc = subprocess.Popen(command,
                                shell = True,
                                bufsize = 0,
                                stderr = subprocess.PIPE,
                                close_fds = True)

        errors = proc.stderr.readlines()
        if proc.wait() != 0:
            if len(errors) == 1:
                raise RuntimeError, "'%s' terminated with non 0 status (%s)" % (qdel, errors[0][:-1])
            else:
                raise RuntimeError, "'%s' terminated with non 0 status" % qdel
   
    @staticmethod
    def qsub(script, nodes, processors, time, qsub = "qsub"):
        command = "%s -l nodes=%d:ppn=%d -l walltime=%d %s" % (qsub, nodes, processors, time, script)
        proc = subprocess.Popen(command,
                                shell = True,
                                bufsize = 0,
                                stdout = subprocess.PIPE,
                                stderr = subprocess.PIPE,
                                close_fds = True)

        output = proc.stdout.readlines()
        errors = proc.stderr.readlines()
        
        if proc.wait() != 0:
            if len(errors) == 1:
                raise RuntimeError, "'%s' terminated with non 0 status (%s)" % (qsub, errors[0][:-1])
            else:
                raise RuntimeError, "'%s' terminated with non 0 status" % qsub

        if len(output) != 1:
            raise RuntimeError, "1 line from '%s' expected, %d obtained" % (qsub, len(output))
        
        return output[0]

    @staticmethod
    def qstat(jobid, qstat = "qstat"):
        command = qstat + " " + jobid
        proc = subprocess.Popen(command,
                                shell = True,
                                bufsize = 0,
                                stdout = subprocess.PIPE,
                                stderr = subprocess.PIPE,
                                close_fds = True)
        pipe = proc.stdout
        data = pipe.readlines()
        errors = proc.stderr.readlines()
        if proc.wait() != 0:
            if len(errors) == 1:
                raise RuntimeError, "'%s' terminated with non 0 status (%s)" % (qstat, errors[0][:-1])
            else:
                raise RuntimeError, "'%s' terminated with non 0 status" % qstat

        if len(data) != 3:
            raise RuntimeError, "Expected 3 lines from '%s': %d obtained" % (qstat, len(data))
            
        status = data[2].split()[-2]
        return status

    @staticmethod
    def qstat_extended(jobid, qstat = "qstat"):
        """Same as above, but with some extra information, and the ability to accomodate even more"""
        command = qstat + " -f " + jobid
        proc = subprocess.Popen(command,
                                shell = True,
                                bufsize = 0,
                                stdout = subprocess.PIPE,
                                stderr = subprocess.PIPE,
                                close_fds = True)
        pipe = proc.stdout
        data = pipe.readlines()
        errors = proc.stderr.readlines()
        if proc.wait() != 0:
            if len(errors) == 1:
                raise RuntimeError, "'%s' terminated with non 0 status (%s)" % (qstat, errors[0][:-1])
            else:
                raise RuntimeError, "'%s' terminated with non 0 status" % qstat

        # Get all the data we want
        walltime = ""
        status = ""
        memory = ""
        cputime = ""
        for line in data:
            fields = line.split()
            if len(fields) < 3:
                continue
            if fields[0] == "resources_used.walltime":
                walltime = fields[2]
                continue
            if fields[0] == "job_state": 
                status = fields[2]
                continue
            if fields[0]  == "resources_used.vmem":
                memory = fields[2]
                continue
            if fields[0]  == "resources_used.cput":
                cputime = fields[2]
        return (status, walltime, cputime, memory)

    @staticmethod
    def showbf(showbf = "showbf", queue = None):
        """Returns a tuple:

        (proc available, timelimit in seconds).

        if the timelimit is -1, then no timelimit is present"""
        # Found an obscure bug which is messing completely my simulation.
        # Until i found out what's happening, let's try this

        if queue == None:
            command = showbf
        else:
            command = showbf + " -f %s" % queue
        
        IMFUCKINGTIREDOFALLTHIS = False
        if IMFUCKINGTIREDOFALLTHIS:
            f = file("showbf", "w")
            f.write("""#!/bin/bash

%s >showbf_output 2>showbf_error
echo $? > showbf_status
""" % command)
            f.close()
            import os
            os.chmod("showbf", 0700)
            os.system("nohup ./showbf")
            f = file("showbf_output")
            data = [ re.search("(no|[0-9]+) procs available( with no timelimit| for[ ]+ ([0-9:]+))?", line)
                     for line in f.readlines()
                     if re.search("(no|[0-9]+) procs available( with no timelimit| for[ ]+ ([0-9:]+))?", line)]
            f.close()
        else:
                process = subprocess.Popen(command,
                                           shell=True,
                                           bufsize=0,
                                           close_fds = True,
                                           stdout=subprocess.PIPE,
                                           stderr=subprocess.PIPE)
                pipe = process.stdout
                data = [ re.search("(no|[0-9]+) procs available( with no timelimit| for[ ]+ ([0-9:]+))?", line)
                         for line in pipe.readlines()
                         if re.search("(no|[0-9]+) procs available( with no timelimit| for[ ]+ ([0-9:]+))?", line)]
        if len(data) == 0:
            raise RuntimeError, \
        """'%s' is not returing lines matching the \"procs available\" string (at least one was expected)""" \
                % command

        retval = []
        for line in data:
            try:
                nproc = int(line.group(1))
            except ValueError:
                retval.append((0,0))
                continue

            if line.group(3) == None:
                retval.append((nproc, -1))
                continue
            
            retval.append((nproc, Queue.parse_time(line.group(3))))
        return retval
        
if __name__ == "__main__":
    nodes = int(raw_input("nodes      = "))
    processors = int(raw_input("processors = "))
    walltime = int(raw_input("walltime   = "))
    jobid = Queue.qsub("t.sh",
                       nodes,
                       processors,
                       walltime)
    print "JOBID = ", jobid                 
    print Queue.qstat(jobid)
    
