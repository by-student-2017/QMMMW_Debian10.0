#Copyright (C) 2011-2015 QMMMW group
#This file is distributed under the terms of the
#GNU General Public License version 3 (GNU-GPLv3).

import copy, os, shutil, re

import genericsimulation
import dumpfile

# Various constants. Some of them shoudn't be changed: when this
# applies, it will be noted
QE_DIR     = "qe"
# Don't change this: it's referenced in the input file for QE
PSEUDO_DIR = "qe/pseudo"
# Input files
QE_INPUT     = "qe.in"
# Output streams
QE_OUTPUT     = "qe.out"
# Error streams
QE_ERROR     = "qe.err"
# This value matches the one on the portal templates and shouldn't be
# changed!
DATA_FILE = "data.ms2"
# This value should not be changed since the name of the simulation for QE will always be ms2
QE_EXIT_FILE = "ms2.EXIT"

class QMSimulation(genericsimulation.GenericSimulation):

    def __init__(self, name, goptions, pseudocache):
        genericsimulation.GenericSimulation.__init__(self, name, goptions)
        self.qminput = None
        self.dumpfile = os.path.normpath(goptions.directories.config + "/" + name + ".qmmm")
        # Do not save this
        self._cache = pseudocache

    def is_configured(self):
        if self.qminput == None:
            return False
        for data in self.qminput:
            if data == None:
                return False
        for pseudo in self.qminput.pseudo_list:
            if not self._cache.isavail(pseudo):
                return False
        return True

    def configure(self, qminput):
        # Get a copy of the data and save it
        self._logs.debug("Configuring the simulation")
        self.qminput = copy.deepcopy(qminput)
        missing = []
        for pseudo in self.qminput.pseudo_list:
            if not self._cache.isavail(pseudo):
                self._logs.error("While configuring the simulation: missing pseudo %s" % pseudo)
                missing.append(pseudo)
        if len(missing) != 0:
            return True
        return False

    def _genscript(self, desc):
        """Generate a script to execute the simulation.

        This function is actually executed in the directory where the
        script is supposed to be, so getcwd returns the private
        location for the simulation"""
        self._logs.debug("Generating the start script")
        desc.write("#!/bin/bash\n")
        # Append a preamble, if the case
        if self.goptions.submission.preamble != None:
            self._logs.debug("Appending the preamble '%s' to the script..." \
                             % self.goptions.submission.preamble)
            try:
                g = file(self.goptions.submission.preamble)
                preamble = g.read()
                g.close()
                desc.write(preamble)
            except IOError, error:
                self._logs.error("Unable to read the preamble (%s) for the submission: %s" % \
                                 (self.goptions.submission.preamble, error))
                raise RuntimeException, error
        desc.write("cd %s\n" % os.getcwd())
        # Start the QE process, with mpirun
        desc.write("""echo 'Starting QE' >>logs.txt
pushd %s
NPROCS=`wc -l < $PBS_NODEFILE`
nohup %s -machinefile $PBS_NODEFILE -np $NPROCS %s <%s >%s 2>%s
popd
""" % (QE_DIR, self.goptions.executables.mpirun, self.goptions.executables.pw,
       QE_INPUT, QE_OUTPUT, QE_ERROR))
        # That's it...

    def crash_happened(self):
        """Returns True if a CRASH file is present, False otherwise"""
        if self.execdir  != None:
            return os.path.isfile(self.execdir + "/" + QE_DIR + "/CRASH")
        return False

    def _configure_simulation(self):
        """This function will be executed before the qsub command is completed"""
        # Create the main directory for the simulation
        # Any exception will be catch by the submit method in GenericSimulation
        genericsimulation.GenericSimulation._configure_simulation(self)

        startdir = os.getcwd()
        # In here we can do whatever we like
        os.chdir(self.execdir)
        try:
            scriptname = "%s_start.sh" % self.name
            f = file(scriptname, "w")
            self._genscript(f)
            f.close()
            os.chmod(scriptname, 0700)

            # Using this horror i'll create the whole directory/data tree for the execution
            # only pseudo files will be missing
            filestruct = ((QE_DIR, ((QE_INPUT, self.qminput.qe_config),)),
                          (PSEUDO_DIR, ()))
            # For each directory there's a data structure
            for dirname, files in filestruct:
                self._logs.debug("Creating the directory '%s'" % dirname)
                try:
                    os.mkdir(dirname)
                except OSError, err:
                    if err[0] != 17:
                        raise RuntimeError, "Unable to create directory '%s'" % dirname
                    # If a directory already exists, ignore
                    pass
                olddir = os.getcwd()
                os.chdir(dirname)
                try:
                    # for each data structure, dump the relevant files
                    for filename, data in files:
                        self._logs.debug("    * writing '%s'" % filename)                
                        try:
                            f = file(filename, "w")
                            f.write(data)
                            f.close()
                        except IOError, error:
                            raise RuntimeError, "Unable to create '%s': %s" % (filename, error)
                finally:
                    os.chdir(olddir)
                            
            # copy the pseudo
            self._logs.debug("Filling the directory '%s'" % PSEUDO_DIR)
            olddir = os.getcwd()
            os.chdir(PSEUDO_DIR)
            try:
                for pseudo in self.qminput.pseudo_list:
                    pseudofile = self._cache.getlocation(pseudo)
                    self._logs.debug("    * writing '%s' (from '%s')" % (pseudo, pseudofile))
                    try:
                        shutil.copy(pseudofile, pseudo)
                    except IOError, error:
                        raise RuntimeError, "Unable to copy the pseudo '%s': %s" % (pseudo, error)
            finally:
                os.chdir(olddir)
            # Remove any CRASH file in QE
            self._logs.debug("Removing the QE CRASH file (if any...)")
            try:
                os.unlink(os.path.normpath(QE_DIR + "/CRASH"))
            except OSError, error:
                self._logs.debug("CRASH file not removed: %s" % error)
            # Remove the EXIT FILE!!!!!
            self._logs.debug("Removing the QE exit file (if any...)")
            try:
                os.unlink(os.path.normpath(QE_DIR + "/" + QE_EXIT_FILE))
            except OSError, error:
                self._logs.debug("exit files not removed: %s" % error)
        finally:
            os.chdir(startdir)
        # Return the script that will be executed
        return os.path.normpath(self.execdir + "/" + scriptname)

    def steps_done(self):
        """Return the number of steps done by crossing the number of restart and the number of frames in the xyz
        
        -1 returned on error"""
        
        try:
            if self.execdir == None:
                return 0
            qe_dir = os.path.normpath(self.execdir + "/" + QE_DIR)
            # Get the full path of the standard output
            outfilepath = os.path.normpath(qe_dir + "/" + QE_OUTPUT)
            outfile = file(outfilepath)
            # Find out how many lines match the ATOMIC_POSITIONS line
            steps = len([ line for line in outfile.readlines() if line.find("ATOMIC_POSITIONS") != -1 ])
            outfile.close()
            self._logs.debug("returning %d steps done" % steps)
            return steps
        except (IOError, ValueError), error:
            self._logs.error("unable to compute the number of steps done: %s" % error)
            return -1

    def get_xyz(self, frames):
        self._logs.error("A XYZ file out of a QE simulation? I don't think so....")
        return None

    def get_last_restart(self):
        self._logs.error("A restart file out of a QE simulation? I don't think so....")
        return None
    
    class __LogFile:
        _f = None

        def __init__(self, filename):
            self._f = file(filename)

        def _count_lines(self):
            try:
                return len(self._f.readlines())
            finally:
                self._f.seek(0)

        def getlines(self, lines):
            self._f.seek(0)
            if lines == 0:
                # Return the whole file
                return self._f.read()
            if lines > 0:
                # Return the data up to 'lines' lines
                data = ""
                for linenum in range(lines):
                    tmp = self._f.readline()
                    if tmp == "":
                        break
                    data += tmp
                return data
            if lines < 0:
                # Return the data from the end of the file
                numlines = self._count_lines()
                start = max(numlines + lines, 0)
                data = ""
                # Skip the first lines
                for linenum in range(start):
                    self._f.readline()
                # Read the rest, if any
                while True:
                    tmp = self._f.readline()
                    if tmp == "":
                        return data
                    data += tmp

        def __del__(self):
            if self._f != None:
                self._f.close()
            
    def getlogs(self, lines):
        """Returns some lines from all logs in the simulation"""
        if self.execdir == None:
            return None
        if not os.path.isdir(self.execdir):
            return None
        logs = []
        for dirname, filename in ((None, None), 
                                  (None, None), 
                                  (None, None), 
                                  (None, None), 
                                  (QE_DIR, QE_OUTPUT), 
                                  (QE_DIR, QE_ERROR)):
            # FIXME: is this the better solution (keep some compatibility with the QMMM simulation)?
            # Add an empty file as a placeholder in the master/slave 
            if dirname == None:
                logs.append("")
                continue
            try:
                l = self.__LogFile(os.path.normpath(self.execdir + "/" + dirname + "/" + filename))
                logs.append(l.getlines(lines))
                del(l)
            except IOError: 
                logs.append("")
                continue
        return logs

    def did_run(self):
        """Call added for moka, but also useful for the portal"""
        if self.execdir == None:
            return 0        
        master_output = os.path.normpath(self.execdir + "/" + QE_DIR + "/" + QE_OUTPUT)
        if os.path.isfile(master_output):
            return 1
        return 0

    def stop(self):
        if not self.is_running():
            return 1
        if self.execdir == None:
            self._logs.error("Unable to stop the job: the directory with QE was removed!")
            return 0        
        stopfile = os.path.normpath(self.execdir + "/" + QE_DIR + "/" + QE_EXIT_FILE)
        f = file(stopfile + "_", "w")
        f.close()
        os.rename(stopfile + "_", stopfile)
        return 0
        
    def save(self):
        c = self._cache
        self._cache = None
        genericsimulation.GenericSimulation.save(self)
        self._cache = c

    @staticmethod
    def restore(name, goptions, cache):
        obj = genericsimulation.GenericSimulation.restore(name, goptions)
        obj._cache = cache
        return obj
        

if __name__ == "__main__":
    # Test the module
    import globaloptions, pseudocache, QMinput, queue
    import logging, logging.handlers
    # Set up a logger
    logs = logging.getLogger("MS2daemon")
    logs.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")    
    handler = logging.handlers.RotatingFileHandler("/dev/shm/logs.txt", maxBytes = 1024000, backupCount = 5)
    handler.setFormatter(formatter)
    logs.addHandler(handler)
    print "Setting up some structures"
    g = globaloptions.GlobalOptions()
    g.submission.preamble = "/usr/local/ms2/ms2.env"
    cache = pseudocache.PseudoCache(g)
    q = QMinput.QMInput()
    # Anonymous files aren't a good idea. Who cares in this circumstance...
    water_shm = "/home/dimeo/work/water_ms2"
    q.qe_config      = file(water_shm + "/qe/water.in_solo").read()
    q.pseudo_list    = ["H.pbe-van_ak.UPF", "O.pbe-van_bm.UPF"]
    
    print "* Creating a new simulation..."
    name = raw_input("Simulation name: ")
    c = QMSimulation(name, g, cache)
    
    print "* Saving the simulation..."
    c.save()
    
    print "* Restoring the simulation..."
    d = QMSimulation.restore(name, g, cache)
    
    print "* Is the simulation configured? ", c.is_configured()
    
    print "* Configuring the simulation (pseudo might not be present)..."
    c.configure(q)
    
    print "* Is the simulation configured, now? ", c.is_configured()
    
    print "* Testing the cache first"
    for pseudo in q.pseudo_list:
        if not cache.isavail(pseudo):
            print "  + reading %s from water_ms2" % pseudo
            f = file("/home/dimeo/work/water_ms2/qe/pseudo/" + pseudo)
            pseudodata = f.read()
            f.close()
            print "  + uploading %s in the cache" % pseudo
            cache.upload(pseudo, pseudodata)
    print "* all pseudo are surely now available!"
    
    print "* Is the simulation configured, now? ", c.is_configured()
    
    print "* Try to dump the simulation again..."
    c.save()
    
    print "* ...and restore it too"
    d = QMSimulation.restore(name, g, c)
    
    print "* Is there any processor available?", queue.Queue.showbf(queue = g.submission.queue)

    print "* Submit...   result:",
    print c.submit(1, 2, 1000)


    while True:
        try:
            print "* Status:  ", c.job_status()
            print "* Is running? ", c.is_running()
        except RuntimeError, error:
            print "Error: ", error
        print c.jobid
        if len(raw_input("key + enter to stop")) != 0:
            break
        
    c.stop()
    while True:
        try:
            print "* Status:  ", c.job_status()
            print "* Is running? ", c.is_running()
        except RuntimeError, error:
            print "Error: ", error
        print c.jobid
        if len(raw_input("key + enter to stop")) != 0:
            break
    
    answer = raw_input("destroy the simulation? " ).upper()
    if answer == "Y" or answer == "1":
        c.destroy()
    

