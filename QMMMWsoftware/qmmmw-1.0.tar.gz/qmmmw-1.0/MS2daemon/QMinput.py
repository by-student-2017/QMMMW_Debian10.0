"""Copyright (C) 2011-2015 QMMMW group
   This file is distributed under the terms of the
   GNU General Public License version 3 (GNU-GPLv3)."""

import re

DEBUG = False

class QMInput:
    qe_config      = None
    pseudo_list    = None

    def __iter__(self):
        yield self.qe_config
        yield self.pseudo_list
        raise StopIteration

    EXPECTED_TEXTFIELDS = {"calculation"  : "md",
                           "restart_mode" : "from_scratch",
                           "prefix"       : "ms2",
                           "pseudo_dir"   : "pseudo"}

    @staticmethod
    def get_card(cardname, lines):
        selected = []
        incard = False
        for line in lines:
            if re.search(re.escape("&" + cardname), line, flags = re.IGNORECASE):
                incard = True
            if re.match("[\t ]*/[\t ]*$", line):
                incard = False
            if incard:
                selected.append(line)
        if DEBUG:
            print "********** SELECTED LINES *************"
            for j in selected:
                print j
            print "********** END SELECTED LINES *********"
        return selected

    @staticmethod
    def get_text_field(name, lines):
        for line in lines:
            tmp = re.search("%s[ \t]*=[ \t]*('(.*)'|\"(.*)\")[ \t]*,?[ \t]*$" % re.escape(name),
                            line,
                            flags = re.IGNORECASE)
            if tmp:
                if tmp.group(2) == None:
                    return tmp.group(3)
                return tmp.group(2)
        return None

    @staticmethod
    def get_int_field(name, lines):
        for line in lines:
            tmp = re.search("%s[ \t]*=[ \t]*([0-9]+)[ \t]*,?[ \t]*$" % re.escape(name),
                            line,
                            flags = re.IGNORECASE)
            if tmp:
                try:
                    return int(tmp.group(1))
                except ValueError, err:
                    return None
        return None
    
    @staticmethod
    def validate_input(data):
        """Check if the input file follows the requirements for a MS2 simulation.

        Checks if the file has the correct prefix, pseudo directory and so on.

        Returns True on error, False on success"""
        controlcard = QMInput.get_card("control", data.splitlines())
        # For each field, check if it is present (it should be) and if
        # the value is the one expected
        for field, value in QMInput.EXPECTED_TEXTFIELDS.iteritems():
            if DEBUG:
                print "SEARCHING: %s -> %s... " % (field, value),
            fieldvalue = QMInput.get_text_field(field, controlcard)
            # Output not validated
            if DEBUG:
                print "%s obtained" % fieldvalue
            if fieldvalue != value:
                return True
        return False

    @staticmethod
    def get_pseudonames(ntyp, lines):
        """Return the lines with the pseudo names

        None on error"""
        pseudo = []
        num = -1
        for i, line in enumerate(lines):
            if re.search("ATOMIC_SPECIES", line):
                num = i + 1
                if DEBUG:
                    print "Found the ATOMIC_SPECIES at line %d" % i
                break
            
        for i in range(num, num + ntyp):
            if DEBUG:
                print "Examining line '%s'"% lines[i]
            try:
                sym, mass, pseudoname = lines[i].split()
                pseudo.append(pseudoname)
            except ValueError:
                return None
        if len(pseudo) != ntyp:
            return None
        return pseudo

    @staticmethod
    def get_pseudolist(data):
        """Get the list of pseudopotentials named in the config file."""

        systemcard = QMInput.get_card("system", data.splitlines())
        
        ntyp = QMInput.get_int_field("ntyp", systemcard)
        if DEBUG:
            print "Found %s types" % ntyp

        if ntyp == 0:
            return None
            
        ionscard = QMInput.get_card("ions", data.splitlines())
        pseudolist = QMInput.get_pseudonames(ntyp, data.splitlines())
        if DEBUG:
            print "Found a list of pseudo: %s" % pseudolist
            
        return pseudolist


            
            
    

        


if __name__ == "__main__":
    # Tiny winy example
    data = """&CONTROL
title=\"alanina\",
   calculation='md'      
restart_mode = \"from_scratch\",
tprnfor=.t.,
prefix='ms2',
pseudo_dir='pseudo'
nstep = 10000000,
MS2_enabled=.true.,
MS2_handler='foobar',
/
 &SYSTEM
                       ibrav = 0,
                   celldm(1) = 20.0,
                         nat = 13,
                        ntyp = 4,
                     ecutwfc = 30.0 ,
                        nosym=.true.,
                     assume_isolated='martyna-tuckerman'
 /
 &ELECTRONS
  conv_thr  = 1.D-5,
  mixing_beta = 0.4D0,
  electron_maxstep = 10000,
 /
 &IONS
                      ion_dynamics = 'verlet'
                      ion_positions = 'default'
                      ion_temperature = 'rescaling'
                      tempw = 300.0 
/

CELL_PARAMETERS cubic
1.000    0.0     0.0
0.0     1.000     0.0
0.0    0.0     1.000
ATOMIC_SPECIES
C 12.0110 C.pbe-van_bm.UPF 
H 1.0080  H.pbe-van_ak.UPF
O 15.9990 O.pbe-van_bm.UPF
N 14.007  N.pbe-van_bm.UPF
ATOMIC_POSITIONS angstrom
N 6.1148606000000001 6.2804953000000001 6.1581799000000004
H 6.4366772000000001 5.7008849000000001 6.9202114000000003
C 6.7444635000000002 7.6067840999999996 6.2507697999999996
H 6.4180076000000001 8.2062041000000008 5.4010634
C 6.3172854999999997 8.3133338000000006 7.5340239999999996
H 6.6004958 7.7067553999999996 8.3943133999999997
H 6.8104909999999999 9.2833822000000001 7.5952767999999997
H 5.2363967000000002 8.4544657999999995 7.5281142000000001
C 8.2607178000000001 7.4834915000000004 6.1988224000000001
O 8.7497523000000008 6.3680509000000001 6.4806756999999999
O 8.9001677000000008 8.4974594000000003 5.8442685000000001
H 5.1112172999999999 6.3801427000000004 6.2115273000000002
H 6.3635187999999996 5.8497620000000001 5.2792968
"""
    DEBUG = True
    print QMInput.validate_input(data)
    print QMInput.get_pseudolist(data)
