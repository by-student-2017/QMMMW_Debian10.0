"""Copyright (C) 2011-2015 QMMMW group
   This file is distributed under the terms of the
   GNU General Public License version 3 (GNU-GPLv3)."""

import os
import logging
import thread

import mylock

class PseudoCache(mylock.MyLock):
    
    def __init__(self, goptions):
        mylock.MyLock.__init__(self)
        #self._logs = logging.getLogger("MS2daemon.PseudoCache")
        #self._logs.info("Initializing the cache")
        self.repo = goptions.directories.pseudo
        # See if a repository is already present and, if not, create a
        # new one
        if not os.path.isdir(self.repo):
            #self._logs.info("Directory '%s' not present: creating one from scratch" % self.repo)
            os.makedirs(self.repo)

    def upload(self, name, data):
        self.acquire()
        try:
            if self.__isavail(name):
                #self._logs.info("Overwriting '%s'" % name)
                pass
            else:
                pass
                #self._logs.info("Adding '%s' to the list of pseudo" % name)
            filename = os.path.normpath(self.repo + "/" + name)
            try:
                f = file(filename, "w")
                f.write(data)
                f.close()
            except IOError, err:
                self._logs.debug("Upload of '%s' failed: %s" % (name, err))
                # Just in case...
                try:
                    os.unlink(filename)
                except:
                    pass
                return err[0]
            return 0
        finally:
            self.release()

    def __isavail(self,name):
        s = set(os.listdir(self.repo))
        return name in s

    def isavail(self, name):
        self.acquire()
        try:
            return self.__isavail(name)
        finally:
            self.release()
            
    def listavail(self):
        self.acquire()
        try:
            return os.listdir(self.repo)
        finally:
            self.release()

    def __getlocation(self, name):
        if not self.__isavail(name):
            #self._logs.info("The pseudo '%s' is not available" % name)
            return None
        return os.path.normpath(self.repo + "/" + name)

    def getlocation(self, name):
        self.acquire()
        try:
            return self.__getlocation(name)
        finally:
            self.release()

    def download(self, name):
        self.acquire()
        try:
            loc = self.__getpseudolocation(self, name)
            if loc == None:
                return loc
            f = file(loc, "r")        
            content = f.read()
            f.close()
            return content
        finally:
            self.release()
        
        
if __name__ == "__main__":
    class C:
        pass
    c = C()
    c.directories = c
    c.directories.pseudo = "/dev/shm/foobar"
    d = PseudoCache(c)
    print "object = ", d
    print "avail: ",d.listavail()
    print "foo is available? ", d.isavail("foo")
