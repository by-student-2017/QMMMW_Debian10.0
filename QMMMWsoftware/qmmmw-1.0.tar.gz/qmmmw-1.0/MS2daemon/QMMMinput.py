"""Copyright (C) 2011-2015 QMMMW group
   This file is distributed under the terms of the
   GNU General Public License version 3 (GNU-GPLv3)."""

class QMMMInput:
    master_config  = None
    master_data    = None
    slave_config   = None
    slave_data     = None
    qe_config      = None
    selected_atoms = None
    pseudo_list    = None

    def __iter__(self):
        yield self.master_config
        yield self.master_data
        yield self.slave_config
        yield self.slave_data
        yield self.qe_config
        yield self.selected_atoms
        yield self.pseudo_list
        raise StopIteration

