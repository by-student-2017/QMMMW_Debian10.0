"""Copyright (C) 2011-2015 QMMMW group
   This file is distributed under the terms of the
   GNU General Public License version 3 (GNU-GPLv3)."""

class MMInput:
    master_config  = None
    master_data    = None

    def __iter__(self):
        yield self.master_config
        yield self.master_data
        raise StopIteration

