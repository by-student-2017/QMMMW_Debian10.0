"""Copyright (C) 2011-2015 QMMMW group
   This file is distributed under the terms of the
   GNU General Public License version 3 (GNU-GPLv3)."""

import xml.dom.minidom
import logging


class XMLParserClass:
    def _get_child_value(self, node, name):
        try:
            el = node.getElementsByTagName(name)[0]
        except IndexError:
            error = "Element '%s' not found!" % name
            self._logs.warning(error)
            raise IndexError, error
        value = el.firstChild
        if value.nodeName.lower() == "integer":
            if len(value.childNodes) == 1:
                return int(value.childNodes[0].data)
            else:
                raise ValueError, "Malformed XML (empty integer)"
        elif value.nodeName.lower() == "string":
            if len(value.childNodes) == 1:
                return value.childNodes[0].data
            elif len(value.childNodes) == 0:
                return ""
            else:
                raise ValueError, "Malformed XML (too many variable fields)"
        else:
            raise NotImplementedError, "The value type '%s' is not (yet?) supported" % value.nodeName    

class QueueStruct(XMLParserClass):
    """Structure which will hold the data for each single queue
    
    Only one is supported by now"""

    def __init__(self, queuenode):
        """Initialize the structure"""

        self._logs = logging.getLogger("MS2daemon.Geometry.QueueStruct")
        if queuenode.hasAttribute("name"):
            self.name = queuenode.getAttribute("name")
        else:
            error = "missing 'name' attribute in a QUEUE node"
            self._logs.error(error)
            raise ValueError, error
        self.proc_x_node  = self._get_child_value(queuenode, "PROC_X_NODE")
        self.min_nodes    = self._get_child_value(queuenode, "MIN_NODES")
        self.max_nodes    = self._get_child_value(queuenode, "MAX_NODES")
        self.min_proc     = self._get_child_value(queuenode, "MIN_PROC")
        self.max_proc     = self._get_child_value(queuenode, "MAX_PROC")
        self.memory       = self._get_child_value(queuenode, "MEMORY")
        self.max_walltime = self._get_child_value(queuenode, "MAX_WALLTIME")
        self.description  = self._get_child_value(queuenode, "DESCRIPTION")
        self.notes        = self._get_child_value(queuenode, "NOTES")

    def satisfies_request(self, request):
        if request.walltime <= 0 or request.walltime > self.max_walltime:
            return False
        if request.processors < 1 or request.processors < self.min_proc or request.processors > self.max_proc:
            return False
        if request.nodes < 1 or request.nodes < self.min_nodes or request.nodes > self.max_nodes:
            return False
        return True

class Request(XMLParserClass):
    
    def __init__(self, requestnode):
        """Structure which will hold the data for each Request
    
        Only one type supported by now"""
        self.queue      = self._get_child_value(requestnode, "QUEUE")
        self.nodes      = self._get_child_value(requestnode, "NODES")
        self.processors = self._get_child_value(requestnode, "PROCESSORS")
        self.walltime   = self._get_child_value(requestnode, "WALLTIME")

        
class Geometry:
    """Simple class used to store the content of the geometry file, if present"""

    def __init__(self, filename):
        """Read and parse the geometry file"""

        # Initialize the logs
        self._logs = logging.getLogger("MS2daemon.Geometry")
        self.filename = filename
        f = file(filename)
        self.data = f.read()
        f.close()

        # The list of the queues available. Only one is supported by
        # now
        self.queues = {}

        self.__parse_data()

    def __parse_data(self):
        """Parse the raw file data.

        Raises a ValueException on error"""
        # Able to open the document?
        try:
            self.document = xml.dom.minidom.parseString(self.data)
        except xml.parsers.expat.ExpatError:
            error = "'%s': malformed xml" % self.filename
            self._logs.error(error)
            raise ValueError, error
        # is there a QUEUE_LIST element?
        try:
            queue_list = self.document.getElementsByTagName("QUEUE_LIST")[0]
        except Exception, err:
            error = "Unable to get the QUEUE_LIST element"
            self._logs.error(error)
            raise ValueError, error

        try:
            # If so, read each queue in it and save it into a separate structure
            for child in queue_list.getElementsByTagName("QUEUE"):
                # Fill a structure 
                queue = QueueStruct(child)
                self.queues[queue.name] = queue
        except (xml.parsers.expat.ExpatError, IndexError):
            error = "error while parsing node '%s'" % child.nodeName
            self._logs.error(error)
            raise ValueError, error

        self._logs.info("Found %d queue(s) %s" % (len(self.queues.keys()), self.queues.keys()))

        if len(self.queues.keys()) == 0:
            error = "No queue specified in the XML!"
            self._logs.error(error)
            raise ValueError, error

        # Brutally exit (killing the server) if more than one queue is present
        # since this revision doesn't support it
        if len(self.queues.keys()) > 1:
            error1 = "Only a single queue is supported in the cluster specification in this revision"
            error2 = "Only a single queue should be present in the cluster specification, for now"
            self._logs.error(error1)
            raise NotImplementedError, error2
                
    def validate_request(self, request):
        """See if the request can be satisfied by a queue.

        if the request is ok returns a tuple with the specifics needed
        to submit the data, else returns an empty tuple."""
                
        try:
            self.document = xml.dom.minidom.parseString(request)
            requestnode = self.document.getElementsByTagName("REQUEST")[0]
            request = Request(requestnode)
        finally:
            pass
#        except (IndexError, xml.parsers.expat.ExpatError):
#            error = "The request is not well formed"
#            self._logs.info(error)
#            return ()

        if not self.queues.has_key(request.queue):
            return ()

        if not self.queues[request.queue].satisfies_request(request):
            return ()

        return (request.nodes, request.processors, request.walltime)

    

if __name__ == "__main__":
    g = Geometry("fakeclustergeometry.xml")
    request = file("fakerequest.xml").read()
    print g.validate_request(request)
