#!/usr/bin/python
#Copyright (C) 2011-2015 QMMMW group
#This file is distributed under the terms of the
#GNU General Public License version 3 (GNU-GPLv3).
#
# Created by Riccardo Di Meo for the MS2 project 
#
# This program can be used and modified freely under the terms of the
# GNU general public license v2, the author doesn't take any
# responsability for the use of this program and/or for any damage
# that may come from it.
"""Usage:

  ./xyzsanitizer.py xyzfile datafile

where the xyzfile is the input xyz to correct and datafile is the lammps data used to create it.

This script converts a xyz file in 'LAMMPS format' (the first column is the index of the atom) to a standard xyz file.

The old data is backed-up into a file xyzfile_backup, and the program refuses to work if the backup file is already present in the directory.
"""

import sys
import os
import re
import optparse


# This table is used to establish a correspondence between lammps indexes and atoms
ATOMS_DATA = ((1.0079400000, "Hydrogen", "H"), (4.0026020000, "Helium", "He"),
              (6.9410000000, "Lithium", "Li"), (9.0121820000, "Beryllium", "Be"),
              (10.8110000000, "Boron", "B"), (12.0107000000, "Carbon", "C"),
              (14.0067000000, "Nitrogen", "N"), (15.9994000000, "Oxygen", "O"),
              (18.9994000000, "Fluorine", "F"), (20.1797000000, "Neon", "Ne"),
              (22.9897692800, "Sodium", "Na"), (24.3050000000, "Magnesium", "Mg"),
              (26.9815386000, "aluminium", "Al"), (28.0855000000, "Silicon", "Si"),
              (30.9737620000, "Phosphorus", "P"), (32.0650000000, "Sulphur", "S"),
              (35.4530000000, "Chlorine", "Cl"), (39.9480000000, "Argon", "Ar"),
              (39.0983000000, "Potassium", "K"), (40.0780000000, "Calcium", "Ca"),
              (44.9559120000, "Scandium", "Sc"), (47.8670000000, "Titanium", "Ti"),
              (50.9415000000, "Vanadium", "V"), (51.9961000000, "Chromium", "Cr"),
              (54.9380450000, "Manganese", "Mn"), (55.8450000000, "Iron", "Fe"),
              (58.9331950000, "Cobalt", "Co"), (58.6934000000, "Nickel", "Ni"),
              (63.5460000000, "Copper", "Cu"), (65.3800000000, "Zinc", "Zn"),
              (69.7230000000, "Gallium", "Ga"), (72.6400000000, "Germanium", "Ge"),
              (74.9216000000, "Arsenic", "As"), (78.9600000000, "Selenium", "Se"),
              (79.9040000000, "Bromine", "Br"), (83.7980000000, "Krypton", "Kr"),
              (85.4678000000, "Rubidium", "Rb"), (87.6200000000, "Strontium", "Sr"),
              (88.9058500000, "Yttrium", "Y"), (91.2240000000, "Zirkonium", "Zr"),
              (92.9063800000, "Niobium", "Nb"), (95.9600000000, "Molybdaenum", "Mo"),
              (98.0000000000, "Technetium", "Tc"), (101.0700000000, "Ruthenium", "Ru"),
              (102.9055000000, "Rhodium", "Rh"), (106.4200000000, "Palladium", "Pd"),
              (107.8682000000, "Silver", "Ag"), (112.4110000000, "Cadmium", "Cd"),
              (114.8180000000, "Indium", "In"), (118.7100000000, "Tin", "Sn"),
              (121.7600000000, "Antimony", "Sb"), (127.6000000000, "Tellurium", "Te"),
              (126.9044700000, "Iodine", "I"), (131.2930000000, "Xenon", "Xe"),
              (132.9054519000, "Cesium", "Cs"), (137.3270000000, "Barium", "Ba"),
              (138.9054700000, "Lanthanum", "La"), (140.1160000000, "Cerium", "Ce"),
              (140.9076500000, "Praseodymium", "Pr"), (144.2420000000, "Neodymium", "Nd"),
              (145.0000000000, "Promethium", "Pm"), (150.3600000000, "Samarium", "Sm"),
              (151.9640000000, "Europium", "Eu"), (157.2500000000, "Gadolinium", "Gd"),
              (158.9253500000, "Terbium", "Tb"), (162.5001000000, "Dysprosium", "Dy"),
              (164.9303200000, "Holmium", "Ho"), (167.2590000000, "Erbium", "Er"),
              (168.9342100000, "Thulium", "Tm"), (173.0540000000, "Ytterbium", "Yb"),
              (174.9668000000, "Lutetium", "Lu"), (178.4900000000, "Hafnium", "Hf"),
              (180.9478800000, "Tantalum", "Ta"), (183.8400000000, "Tungsten", "W"),
              (186.2070000000, "Rhenium", "Re"), (190.2300000000, "Osmium", "Os"),
              (192.2170000000, "Iridium", "Ir"), (192.0840000000, "Platinum", "Pt"),
              (196.9665690000, "Gold", "Au"), (200.5900000000, "Hydrargyrum", "Hg"),
              (204.3833000000, "Thallium", "Tl"), (207.2000000000, "Lead", "Pb"),
              (208.9804010000, "Bismuth", "Bi"), (210.0000000000, "Polonium", "Po"),
              (210.0000000000, "Astatine", "At"), (220.0000000000, "Radon", "Rn"),
              (223.0000000000, "Francium", "Fr"), (226.0000000000, "Radium", "Ra"),
              (227.0000000000, "Actinium", "Ac"), (232.0380600000, "Thorium", "Th"),
              (231.0358800000, "Protactinium", "Pa"), (238.0289100000, "Uranium", "U"),
              (237.0000000000, "Neptunium", "Np"), (244.0000000000, "Plutonium", "Pu"),
              (243.0000000000, "Americium", "Am"), (247.0000000000, "Curium", "Cm"),
              (247.0000000000, "Berkelium", "Bk"), (251.0000000000, "Californium", "Cf"),
              (252.0000000000, "Einsteinium", "Es"), (257.0000000000, "Fermium", "Fm"),
              (258.0000000000, "Mendelevium", "Md"), (259.0000000000, "Nobelium", "No"),
              (262.0000000000, "Lawrencium", "Lr"), (261.0000000000, "Rutherfordium", "Rf"),
              (262.0000000000, "Dubnium", "Db"), (266.0000000000, "Seaborgium", "Sg"),
              (264.0000000000, "Bohrium", "Bh"), (277.0000000000, "Hassium", "Hs"),
              (268.0000000000, "Meitnerium", "Mt"), (271.0000000000, "Ununnilium", "Ds"),
              (272.0000000000, "Unununium", "Rg"), (285.0000000000, "Ununbium", "Uub"),
              (284.0000000000, "Ununtrium", "Uut"), (289.0000000000, "Ununquadium", "Uuq"),
              (288.0000000000, "Ununpentium", "Uup"), (292.0000000000, "Ununhexium", "Uuh"),
              (294.0000000000, "Ununoctium", "Uuo"))

def warning(msg):
    sys.stderr.write("Warning: %s\n" % msg)

def error(msg):
    sys.stderr.write("ERROR: %s\n" % msg)
    raise SystemExit, 1

def parse_datafile(lammpsdata):
    """Parse a data file for the 'Masses' section"""
    
    # find the types first
    types = None
    masses = []
    while True:
        rawline = lammpsdata.readline()
        # EOF?
        if rawline == '':
            if types == None:
                error("unable to parse the LAMMPS data file: 'XX atom types' line not found!")
            else:
                error("unable to parse the LAMMPS data file: 'Masses' section not found!")
        # Purge the comments
        line = re.match("([^#]*)(#.*)?$", rawline).group(1)
       # Get the atom types
        res = re.match("[ \t]*([\d]+) atom types[ \t]*$", line)
        if res:
            types = int(res.group(1))

        # Search for a 'Masses' section
        if re.match("[ \t]*Masses[ \t]*$", line):
            if types == None:
                error("unable to parse the LAMMPS data file: 'Masses' section reached, but 'atom types' is nowhere to be found")                
            break

    mass_read = 0
    while mass_read < types:
        rawline = lammpsdata.readline()
        # Purge any comment from the line
        line = re.match("([^#]*)(#.*)?$", rawline).group(1)
        # Skip empty lines if immediately after the title
        if len(line.split()) == 0 and mass_read ==0:
            continue
        try:
            sindex, smass = line.split()
        except ValueError:
            error("unable to parse the LAMMPS data file: not enough data in the Mass section (line missing)")
        try:
            masses.append((int(sindex), float(smass)))
            mass_read += 1
        except ValueError:
            error("unable to parse the LAMMPS data file: invalid data in line '%s'" % line)
        
    if len(lammpsdata.readline().split()) != 0:
        error("unable to parse the LAMMPS data file: unexpected data after the Mass section")
        
    return masses

def find_match(mass):
    diffs = []
    for elmass, elname, elsymbol in ATOMS_DATA:
        diff = abs(elmass - mass)
        diffs.append((diff, elsymbol))
    diffs.sort(key = lambda x: x[0])
    return diffs[0][1]

def match_masses(massdata):
    """Return an index->symbol dictionary"""
    types = {}
    for index, mass in massdata:
        symbol = find_match(mass)
        types[index] = symbol
    return types

def filter_frame(src, dst, indexes):
    """Reads the data in src, writes it to destination. Easy isn't it?!"""
    while True:
        # Number of atoms
        try:
            line = src.readline()
            # If the line is empty, we just finished
            if line == "":
                return
            natoms = int(line)
            dst.write(line)
        except ValueError:
            error = "number of atoms expected, '%s' found" % line[:-1]
            raise ValueError, error
        # Comment 
        dst.write(src.readline())
        # Atoms data
        for i in range(natoms):
            line = src.readline()
            if line == "":
                raise ValueError, "incomplete frame found"
            try:
                sindex, sx, sy, sz = line.split()
                try:
                    index = int(sindex)
                except ValueError:
                    error = "an integer was expected for the index, where '%s' is not" % sindex
                    raise ValueError, error
                symbol = indexes[index]
                dst.write("%s %s %s %s\n" % (symbol, sx, sy, sz))
            except ValueError:
                error = "Data expected '%s' found" % line[:-1]
                raise ValueError, error

def count_available_frames(infile, thorough_check):
    """Count the frames in the input file

    seek back to start when finished"""
    nlines = 0
    framelist = []
    while True:
        # number of xyz coordinates            
        try:
            framelist.append(infile.tell())
            lines = int(infile.readline())
            nlines += 1
        except ValueError:
            del(framelist[-1])
            break
        if(infile.readline()) == '':
            warning("premature end of file at line  %d" % nlines)
            del(framelist[-1])
            break
        nlines += 1
        error_occurred = False
        for i in range(lines):
            line = infile.readline()
            if line == "":
                warning("premature end of file at line  %d" % nlines)
                error_occurred = True
                break
            nlines += 1
            fields = line.split()
            if len(fields) != 4:
                warning("wrong number of fields at line %d" % nlines)
                error_occurred = True
                break
            if thorough_check:
                try:
                    [float(field) for field in fields]
                except ValueError:
                    error("the coordinates at line '%d' are invalid" % nlines)                
        if error_occurred:
            del(framelist[-1])
            break
        
    infile.seek(0)
    return framelist

def mangle_frame(input, output, frame, frames, imdict):
    """Mangle a single frame.

    input is the input file pointer
    output is the output file pointer
    frame is the index of the frame
    frames is a list of positions of the start of each frame
    imdict is a dictionary that associates the index of the atom in
           the XYZ to a mass. If adicts is None, no mangling is performed

    The code assumes that at least a single frame fits in the memory"""

    # Correct the index so that it will start from 0 for positive indexes
    if frame > 0:
        frame -= 1
    
    try:
        framestart = frames[frame]
    except IndexError:
        error("the frame required is out of range (%d valid frames in the input file)" % len(frames))

    input.seek(framestart)

    # use 2 different blocks for filtering/copy: the poor's man optimization
    if imdict == None:
        # write-through
        if frame != -1 and frame != len(frames) - 1:
            # Not the last frame
            datasize = frames[frame + 1] - framestart
            data = input.read(datasize)
            output.write(data)
            del(data)
            return 0
        else:
            # We can't be sure theresn't garbage at the end of the
            # file: we can't just read everything
            line = input.readline()
            output.write(line)
            natoms = int(line)
            for i in range(natoms + 1):
                output.write(input.readline())
            return 0
    else:
        # sanitize the list
        line = input.readline()
        output.write(line)
        natoms = int(line)
        # Comment
        output.write(input.readline())
        for i in range(natoms):
            line = input.readline()
            fields = line.split()
            sindex, sx, sy, sz = line.split()
            # Get the index as integer
            try:
                index = int(sindex)
            except ValueError:
                error("an integer was expected in frame %d line %d, '%s' found" % (frame, i + 3, sindex))
            # Look up in the dictionary
            try:
                symbol = imdict[index]
            except KeyError:
                error("frame %d line %d: unable to find the correct mass for index %d (is the data file correct?)" % (frame, i + 3, index))
            output.write("%s %s %s %s\n" % (symbol, sx, sy, sz))

def mangle_all(input, output, imdict, thorough_check):
    """Mangle the whole file, one frame at a time

    input is the input file pointer
    output is the output file pointer
    imdict is a dictionary that associates the index of the atom in
           the XYZ to a mass. If adicts is None, no mangling is performed

    The code assumes that at least a single frame fits in the memory"""

    input.seek(0)
    nlines = 0
    framelist = []
    frame = ""
    while True:
        # number of xyz coordinates
        try:
            framelist.append(input.tell())
            line = input.readline()
            xyzlines = int(line)            
            nlines += 1
        except ValueError:
            del(framelist[-1])
            break
        frame += line
        line = input.readline()
        if line == '':
            warning("premature end of file at line  %d" % nlines)
            del(framelist[-1])
            break
        frame += line
        nlines += 1
        error_occurred = False
        for i in range(xyzlines):
            line = input.readline()
            if line == "":
                warning("premature end of file at line  %d" % nlines)
                error_occurred = True
                break
            nlines += 1
            fields = line.split()
            if len(fields) != 4:
                warning("wrong number of fields at line %d" % nlines)
                error_occurred = True
                break
            if thorough_check:
                try:
                    [float(field) for field in fields[1:]]
                except ValueError:
                    error("the coordinates at line '%d' are invalid" % nlines)
            if imdict != None:
                # Convert the index and re-write the line
                try:
                    symbol = imdict[int(fields[0])]
                except ValueError, err:
                    error("an integer was expected at line %d, '%s' found" % (nlines, fields[0]))
                except KeyError, err:
                    error("line %d: unable to find the correct mass for index %d (is the data file correct?)" % (nlines, fields[0]))
                newline = "%s %s %s %s\n" % (symbol, fields[1], fields[2], fields[3])
                frame += newline
            else:
                frame += line
        if error_occurred:
            del(framelist[-1])
            break
        # If no error occurred, write the output
        output.write(frame)
        frame = ""
        
    return framelist
            
def process_xyz(options):
    """Perform the operations required by the user"""
    
    # Read the LAMMPS data if this was required
    if options.sanitize:
        data = file(options.data)
        masses = parse_datafile(data)
        data.close()        
        indexes = match_masses(masses)
    else:
        indexes = None

    try:
        src = file(options.input)
    except IOError, err:
        error("unable to open '%s' for reading" % options.input)

    try:
        dst = file(options.output, "w")
    except IOError:
        error("unable to open '%s' for writing" % options.output)
        
    try:
        if options.frame != None:
            # if necessary, count the available frames
            frames = count_available_frames(src, options.thorough)
            try:
                mangle_frame(src, dst, options.frame, frames, indexes)
            except IOError, err:
                error("unable to write to '%s': %s" % (options.output, err[1]))   
        else:
            frames = None
            try:
                frames = mangle_all(src, dst, indexes, options.thorough)
            except IOError, err:
                error("unable to write to '%s': %s" % (options.output, err[1]))
    finally:
        src.close()
        dst.close()

    if options.print_frames:
        sys.stdout.write("%d frames found\n" % len(frames))

def parse_arguments():
    """Read the command line arguments"""
    
    usage = "usage: %prog [options] input.xyz"
    parser = optparse.OptionParser(usage = usage)
    
    # Output file (XYZ)
    parser.add_option("-o", "--output", dest = "output",
                      help = "output file (default: overwrite the input, preserve the original file with a _backup extension)",
                      default = None)
    
    # Data file (LAMMPS format, required only for sanification)
    parser.add_option("-d", "--data", dest = "data",
                      help = "a LAMMPS data file matching the input",
                      default = None)
    
    # Sanitize: yes/no
    parser.add_option("-s", "--sanitize", dest = "sanitize",
                      action = "store_true", default = False,
                      help = "convert the file in input into a regular XYZ file by using mass-guessing")

    # Hard check: yes/no
    parser.add_option("-t", "--thorough-checks", dest = "thorough",
                      action = "store_true", default = False,
                      help = "perform a deeper, slower check on the input file")
    
    # Print the total number of framse: yes/no
    parser.add_option("-p", "--print-frames", dest = "print_frames",
                      action = "store_true", default = False,
                      help = "print the total number of complete frames present in the input")
    
    # print only the selected frame
    parser.add_option("-n", "--frame", dest = "frame",
                      default = None, type = "int",
                      help = "print only the selected frame")
    
    # overwrite the backup file
    parser.add_option("-f", "--force", dest = "force",
                      default = False, action = "store_true",
                      help = "overwrite files (default: exit with error if an output file is already present)")
    
    (options, args) = parser.parse_args()

    # Check: input file specified?
    if len(args) > 1:
        parser.error("only one positional argument should be provided")
    elif len(args) == 0:
        parser.error("input xyz file not provided")
    # Save the value in the object
    options.input = args[0]

    # Check: input file present?
    if not os.path.isfile(options.input):
        parser.error("the input file is not present (or is not a file)")

    # Check: is the frame of the -n option not 0?
    if options.frame == 0:
        parser.error("the frames count starts from 1 (my sympathy fellow C coder...)")

    # Check: if the input has to be sanitized, the datafile must be present
    if options.sanitize and options.data == None:
        parser.error("a data file should be supplied in order for the input to be sanitized")
    elif options.data != None and not options.sanitize:
        warning("sanification of the output not activated: data file ignored")
    elif options.sanitize:
        if not os.path.isfile(options.data):
            parser.error("the data file provided is not present (or is not a file)")


    # Fix the output path
    if options.output == None:
        # Replace the input. This requires some trickery
        options.output = options.input
        options.input += "_backup"
        if os.path.exists(options.input):
            if options.force:
                # Ok, i can overwrite the backup. But it's not a file
                if not os.path.isfile(options.input):            
                    parser.error("unable to overwrite '%s': not a file" % options.input)
            else:
                parser.error("'%s' already present and -f not specified: cowardly bailing out..." % options.input)
        try:
            os.rename(options.output, options.input)
        except OSError, error:
            parser.error("unable to rename '%s' to '%s': %s" % (options.output, options.input, error[1]))
    else:
        if os.path.isdir(options.output):
            options.output = os.path.normpath(options.output + \
                                              "/" + os.path.basename(options.input))
            
    # Check: if no force is present and the output file is already in place, bail out
    if not options.force:
        if os.path.exists(options.output):
            parser.error("output file '%s' already present (and -f not specified): cowardly bailing out..." % options.output)
    return options

if __name__ == "__main__":
    options = parse_arguments()
    process_xyz(options)
    raise SystemExit, 0
