#!/usr/bin/env python
"""Copyright (C) 2011-2015 QMMMW group
   This file is distributed under the terms of the
   GNU General Public License version 3 (GNU-GPLv3)."""

"""This little code patches the LAMMPS and QE source trees (or at least it tries...).

Usage:

  patch_codes.py <action> <directory>

where action is one of:

  patch_lammps     :  patches LAMMPS with MS2
  revert_lammps    :  reverts a patched LAMMPS to it's original form
  build_lammps     :  tries to build LAMMPS
  patch_espresso   :  patches Quantum Espresso with MS2
  revert_espresso  :  reverts a patched QE to it's original form
  build_espresso   :  tries to build PWscf

and directory is the location of _absolute_ path to the position of the main program directory.
Keep in mind that for each action, the right directory should be provided!!!

Due to the high variability of systems and to the developement nature
of LAMMPS and QE the procedure is not guaranteed to work on both, if
at all."""

import sys, os, shutil, re, subprocess

# Suffix for the backups
SUFFIX = "_ms2backup"
# Should this procedure add also the fix for the Electrostatic coupling in LAMMPS
# (this implies that the Makefile.ms2 in the libms2 directory already contains the
# -lms2ec option)
PATCH_FOR_EC = True

WRONG_ARGS = 1      # The command line arguments are not correct
PATCH_FAILED = 2    # something went wrong while including the #define __MS2 line
ALREADY_PATCHED = 3 # Trying to patch an already patched package
CONFIGURE_ERROR = 4 # "configure" failed (espresso)
MAKE_ERROR = 5      # "make" failed
IMPORT_ERROR = 6    # configure wasn't properly executed before calling this script

def LOG(msg, newline = True):
    if newline:
        sys.stderr.write(msg + "\n")
    else:
        sys.stderr.write(msg)

def ERR(msg, code = None):
    sys.stderr.write("ERROR: " + msg + "\n")
    if code != None:
        raise SystemExit, code

# Add the directory with the modules to the list
modules_path = os.path.dirname(os.path.realpath(__file__))
sys.path.append(modules_path)

try:
    import paths
except ImportError:
    ERR("paths module not available: was configure correctly issued?", IMPORT_ERROR)

# All paths relative to the base directory
LAMMPS_MS2_FILES = ("src/fix_ms2.h", "src/fix_ms2.cpp",
                    "src/fix_ms2debug.h", "src/fix_ms2debug.cpp", "src/MAKE/Makefile.ms2")

LAMMPS_MS2EC_FILES = ("src/fix_ms2ec.h", "src/fix_ms2ec.cpp")

ESPRESSO_MS2_FILES = ("PW/src/ms2.f90" + SUFFIX,
                      "PW/src/Makefile"  + SUFFIX,
                      "PW/src/input.f90" + SUFFIX,
                      "PW/src/pwscf.f90" + SUFFIX,
                      "Modules/input_parameters.f90" + SUFFIX,
                      "install/make.sys.in" + SUFFIX,
                      "PW/src/make.deps" + SUFFIX)

ESPRESSO_TOBEPATCHED = ("PW/src/input.f90", "PW/src/pwscf.f90", "Modules/input_parameters.f90", "PW/src/setlocal.f90", "PW/src/forces.f90")

def __already_patched(directory, files = LAMMPS_MS2_FILES):
    for filename in files:
        fullpath = os.path.normpath(directory + "/" + filename)
        if os.path.isfile(fullpath):
            LOG("File '%s' found" % fullpath)
            return True
    return False

def __backup_file(pathtofile):
    """Returns True if the backup file is already present or the operations fails, False otherwise"""
    backupfile = pathtofile + SUFFIX
    if os.path.isfile(backupfile):
        LOG("Cannot backup again: '%s' already present" % pathtofile)
        return True
    try:
        os.rename(pathtofile, backupfile)
    except Exception, error:
        ERR("Cannot backup '%s': %s" % (pathtofile, str(error)))
        return True

def __revert_file(pathtofile):
    """Returns True if no backup file is present or the operations fails, False otherwise"""
    pathtobackup = pathtofile + SUFFIX
    LOG("Reverting '%s'..." % pathtofile)
    if os.path.isfile(pathtobackup):
        try:
            os.unlink(pathtofile)
        except OSError:
            pass
        try:
            os.rename(pathtobackup, pathtofile)
        except Exception, error:
            ERR("Cannot restore '%s' from '%s': %s" % (pathtofile, pathtobackup, str(error)))
            return True    

def __espresso_include_MS2(pathtofile):
    if __backup_file(pathtofile):
        LOG("'%s' not patched" % pathtofile)
        return True

    backupfile = pathtofile + SUFFIX
    f = file(backupfile, "r")
    data = f.read()
    f.close()

    # Define the __MS2 preproc symbol in the file
    f = file(pathtofile, "w")
    f.write("#define __MS2\n")
    f.write(data)
    f.close()

    LOG("'%s' patched!" % pathtofile)

    return False
            
def lammps_already_patched(directory):
    """Returns True if a relic of a patch operation is found, False otherwise"""
    return __already_patched(directory)

def espresso_already_patched(directory):
    """Returns True if a relic of a patch operation is found, False otherwise"""
    return __already_patched(directory, ESPRESSO_MS2_FILES)

def patch_lammps(directory):
    if lammps_already_patched(directory):
        ERR("""It seems that the LAMMPS directory contains some relic of an old MS2 installation:
revert the changes and try again""", ALREADY_PATCHED)

    sourcedir = os.path.abspath("../libms2/fix")
    for relpath in LAMMPS_MS2_FILES:
        name = os.path.basename(relpath)
        source = os.path.normpath(sourcedir + "/" + name)
        destination = os.path.normpath(directory + "/" + relpath)
        LOG("Copying '%s' to '%s'..." % (source, destination))
        try:
            shutil.copy(source, destination)
        except Exception, error:
            ERR("Unable to copy '%s' to '%s': %s\n" % (source, destination, error), PATCH_FAILED)
    # FIXME duplicated code...
    if PATCH_FOR_EC:
        sourcedir = os.path.abspath("../libms2ec/fix")
        for relpath in LAMMPS_MS2EC_FILES:
            name = os.path.basename(relpath)
            source = os.path.normpath(sourcedir + "/" + name)
            destination = os.path.normpath(directory + "/" + relpath)
            LOG("Copying '%s' to '%s'..." % (source, destination))
            try:
                shutil.copy(source, destination)
            except Exception, error:
                ERR("Unable to copy '%s' to '%s': %s\n" % (source, destination, error), PATCH_FAILED)
    
    LOG("LAMMPS correctly patched!\n")

def revert_lammps(directory):
    for relpath in LAMMPS_MS2_FILES + LAMMPS_MS2EC_FILES:
        destination = os.path.normpath(directory + "/" + relpath)
        try:
            os.unlink(destination)
            LOG("Removed '%s'..." % destination)
        except Exception, error:
            pass
    LOG("LAMMPS reverted to it's original form!\n")
    
def build_lammps(directory):
    sourcedir = os.path.normpath(directory + "/src")
    tmp = os.getcwd()
    os.chdir(sourcedir)
    try:
        os.chdir("STUBS")
        LOG("Building the fake MPI support...")
        p = subprocess.Popen("make",
                             shell = True)
        res = os.waitpid(p.pid, 0)[1]
        if res != 0:
            ERR("Fake MPI support not compiled properly: you are on your own...",
                  MAKE_ERROR)
            
        os.chdir("..")
        LOG("Building lmp_ms2...")
        p = subprocess.Popen("make ms2",
                             shell = True)
        res = os.waitpid(p.pid, 0)[1]
        if res != 0:
            ERR("lmp_ms2 not compiled properly: you are on your own...",
                  MAKE_ERROR)
    finally:
        os.chdir(tmp)
    LOG("lmp_ms2 correctly built. Copy it in the '%s/bin' directory to complete the installation" % paths.prefix)
    LOG("The executable can be found in '%s'" % sourcedir)
    
    

def patch_espresso(directory):
    if espresso_already_patched(directory):
        ERR("""It seems that the espresso directory contains some relics of an old MS2 installation:
revert the changes and try again""", ALREADY_PATCHED)

    # ms2.f90
    source = "../libms2ec/espresso/ms2.f90"
    destination = os.path.normpath(directory + "/PW/src/ms2.f90")
    # Do a backup first
    if __backup_file(destination):
        ERR("Unable to backup ms2.f90 Has the source been patched already?", PATCH_FAILED)
    try:
        shutil.copy(source, destination)
    except Exception, error:
        ERR("Unable to copy '%s' to '%s': %s\n" % (source, destination, error), PATCH_FAILED)
        
    # ecfunctions.f90 (no backup required)
    source = "../libms2ec/espresso/ecfunctions.f90"
    destination = os.path.normpath(directory + "/PW/src/ecfunctions.f90")
    try:
        shutil.copy(source, destination)
    except Exception, error:
        ERR("Unable to copy '%s' to '%s': %s\n" % (source, destination, error), PATCH_FAILED)
    
    # f90 files
    for filename in ESPRESSO_TOBEPATCHED:
        pathtofile = os.path.normpath(directory + "/" + filename)
        if __espresso_include_MS2(pathtofile):
            ERR("MS2 not included correctly in PWscf. Try to revert the changes first", PATCH_FAILED)

    # Make.sys.in
    makesysin = os.path.normpath(directory + "/install/make.sys.in")
    sys.stderr.write("Patching make.sys.in... ")
    if __backup_file(makesysin):
        ERR("MS2 not included correctly in PWscf. Try to revert the changes first", PATCH_FAILED)
    newname = makesysin + SUFFIX
    f = file(newname)
    data = f.read()
    f.close()
    data = re.sub("LD_LIBS[ \t]*=",paths.LD_LIBS,data)
    f = file(makesysin, "w")
    f.write(data)
    f.close()

    # PW/make.depend    
    depend = os.path.normpath(directory + "/PW/src/make.depend")
    backupfile = depend + SUFFIX
    if __backup_file(depend):
        ERR("MS2 not included correctly in PWscf. Try to revert the changes first", PATCH_FAILED)
    shutil.copy(backupfile, depend)
    f = file(depend, "a")
    f.write("""# Dependencies added by the script 'tools/patch.py' in the ms2 distribution
# for the inclusion of the ms2.f90 module with the Mechanical/Electrostatic Coupling
ms2.o : ../../Modules/cell_base.o
ms2.o : ../../Modules/constants.o
ms2.o : ../../Modules/fft_base.o
ms2.o : ../../Modules/griddim.o
ms2.o : ../../Modules/io_global.o
ms2.o : ../../Modules/ions_base.o
ms2.o : ../../Modules/kind.o
ms2.o : pwcom.o
ms2.o : scf_mod.o
ms2.o : ../../Modules/cell_base.o
ms2.o : ../../Modules/constants.o
ms2.o : ../../Modules/ions_base.o
ms2.o : ../../Modules/kind.o
ms2.o : pwcom.o""")
    f.close()

    # PW/Makefile
    sys.stderr.write("Patching PW/Makefile...")
    make = os.path.normpath(directory + "/PW/Makefile")
    if __backup_file(make):
        ERR("MS2 not included correctly in PWscf. Try to revert the changes first", PATCH_FAILED)
    newname = make + SUFFIX
    f = file(newname, "r")
    data = f.read()
    f.close()
    data = re.sub("PWLIBS[ \t]*=","PWLIBS  = ms2.o ",data)
    f = file(make, "w")
    f.write(data)
    f.close()
    
    LOG("Espresso correctly patched!\n")

def revert_espresso(directory):
    LOG("Removing ms2.f90")
    ms2 = os.path.normpath(directory + "/PW/src/ms2.f90")
    __revert_file(os.path.normpath(ms2))
    LOG("Removing ecfunctions.f90")
    ecfunctions = os.path.normpath(directory + "/PW/src/ecfunctions.f90")
    __revert_file(os.path.normpath(ecfunctions))

    for filename in ESPRESSO_TOBEPATCHED:
        __revert_file(os.path.normpath(directory + "/" + filename))
        
    makesysin = os.path.normpath(directory + "/install/make.sys.in")
    __revert_file(makesysin)

    depend = os.path.normpath(directory + "/PW/src/make.depend")
    __revert_file(depend)

    make = os.path.normpath(directory + "/PW/Makefile")
    __revert_file(make)

    LOG("Done")
    
        
def build_espresso(directory):
    LOG("Configuring the package...")
    tmp = os.getcwd()
    os.chdir(directory)
    try:
        p = subprocess.Popen("./configure --enable-signals",
                             shell = True)
        res = os.waitpid(p.pid, 0)[1]
        if res != 0:
            ERR("QE not configured properly: you are on your own...",
                  CONFIGURE_ERROR)
        p = subprocess.Popen("make pw",
                             shell = True)
        res = os.waitpid(p.pid, 0)[1]
        if res != 0:
            ERR("QE not compiled properly: you are on your own...",
                  MAKE_ERROR)
    finally:
        os.chdir(tmp)
    LOG("pw.x correctly built. Copy it in the '%s/bin' directory as 'pw_ms2.x' to complete the installation" % paths.prefix)
    LOG("The executable can be found in '%s'" % os.path.normpath(directory + "/PW"))

ACTIONS = { "patch_lammps": patch_lammps,
            "revert_lammps": revert_lammps,
            "build_lammps": build_lammps,
            "patch_espresso": patch_espresso,
            "revert_espresso": revert_espresso,
            "build_espresso": build_espresso}

def parse_n_run():
    if len(sys.argv) != 3:
        LOG(__doc__)
        ERR("Wrong number of arguments", WRONG_ARGS)

    action = sys.argv[1].lower()
    directory = sys.argv[2]

    # I lied in the help. since the path is passed from the configure,
    # in case the value is not absolute it CAN be converted by adding
    # a "..". Go tell this to the average user anyway ;-)
    if not os.path.isabs(directory):
        directory = os.path.abspath("../" + directory)

    if not os.path.isdir(directory):
        ERR("'%s' doesn't seem a directory" % directory, WRONG_ARGS)

    if not ACTIONS.has_key(action):
        ERR("'%s' is not a valid action" % action, WRONG_ARGS)

    apply(ACTIONS[action], (directory, ))

if __name__ == "__main__":    
    parse_n_run()
    
