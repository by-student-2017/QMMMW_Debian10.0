#!/usr/bin/env python
#Copyright (C) 2011-2015 QMMMW group
#This file is distributed under the terms of the
#GNU General Public License version 3 (GNU-GPLv3).
#
# Created for the MS2 project
#
# author: Riccardo Di Meo
#
"""Class to parse/build LAMMPS data files.

Specification of the format can be found at this address:

http://lammps.sandia.gov/doc/2001/data_format.html

The parsing performed by this module is somewhat stricter than the one
performed by LAMMPS, therefore this code could be used in principle to
check for errors that would be missed by LAMMPS"""

import sys, re, os, urllib2, getopt, warnings

DEBUG = True
DEBUG = False

# Default credentials to use if the db_* family of options is not set
# Replace them with the actual host, password and user if having them
# hard coded would be desirable
DEFAULT_HOST = "localhost"
try:
    DEFAULT_LOGIN = os.getlogin()
except:
    DEFAULT_LOGIN = "user"
DEFAULT_PASSWORD = ""

##
#@brief Print a warning on stderr
#
#@param msg whatever you like to be printed. End line not required
# 
#@return None
def WARNING(msg):
    """Print a warning on stderr

msg whatever you like to be printed. End line appended
 
returns None"""
    sys.stderr.write("WARNING: " + str(msg) + "\n")

## 
# Print a message to sys.stderr 
# 
# @param msg The message/data to be printed (newline appended)
# 
# @return None
#
def MSG(msg):
    sys.stderr.write(msg + "\n")

##
# Print an error and possibly exits with a SystemExit exception
# 
# @param msg the message to be printed (newline appended)
# @param code int: the code with which the function will exit (default: None. Don't exit)
# 
# @return None
#
def ERR(msg, code = None):
    sys.stderr.write("ERROR: " + str(msg) + "\n")
    if code != None:
        raise SystemExit, code

## 
# Print a message only if the DEBUG variable is present and set to a True-like value
# 
# @param msg the msg (string) to be printed. Newline NOT appended
# 
# @return None
#
def DEBUG_MSG(msg):
    try:
        if DEBUG:
            sys.stderr.write(msg)
    except NameError:
        pass

try:
    # Ignorance is bliss
#     with warnings.catch_warnings():
#             warnings.simplefilter("ignore", DeprecationWarning)
    import MySQLdb
    DB_INTERFACE = True
except ImportError, error:
    DB_INTERFACE = False
#    WARNING("Database interface not available (%s)" % error)

try:
    import pickatoms
    PICKATOMS = True
except ImportError, error:
    PICKATOMS = False
#    WARNING("Pickatoms  module not available (%s)" % error)


# Used only at parsing stage to get the right simulation type
TYPES = {"alanine": 1, "peptide": 2}

# Values used in the LAMMPSDATA._parse_section routine
# FLD_OPT can be orred with the other values 
FLD_INT        = 0         # Generic integer
FLD_DOUBLE     = 1         # Generic double
FLD_ATOM       = 3         # Atom number
FLD_BOND       = 4         # Bond number
FLD_ANGLE      = 5         # Angle number
FLD_DIH        = 6         # Dihedral number
FLD_IMP        = 7         # Improper number
FLD_TYPE       = 8         # Type number 
FLD_MOL        = 9         # Molecule    
FLD_BOND_TYPE  = 10        # Bond type 
FLD_ANGLE_TYPE = 11        # Angle type
FLD_DIH_TYPE   = 12        # Dihedral type
FLD_IMP_TYPE   = 13        # Improper type
FLD_OPT        = 32        # Additional flag to specify "optional fields"

# and corresponding conversions
FLD_VARTYPE = {
    FLD_INT        : int,
    FLD_DOUBLE     : float,
    FLD_ATOM       : int,
    FLD_BOND       : int,
    FLD_ANGLE      : int,
    FLD_DIH        : int,
    FLD_IMP        : int,
    FLD_MOL        : int,
    FLD_TYPE       : int,
    FLD_BOND_TYPE  : int,
    FLD_ANGLE_TYPE : int,
    FLD_DIH_TYPE   : int,
    FLD_IMP_TYPE   : int,
}

# And C types
FLD_PRINTTYPE = {
    FLD_INT        : "%d",
    FLD_DOUBLE     : "%-10.10g",
    FLD_ATOM       : "%d",
    FLD_BOND       : "%d",
    FLD_ANGLE      : "%d",
    FLD_DIH        : "%d",
    FLD_IMP        : "%d",
    FLD_MOL        : "%d",
    FLD_TYPE       : "%d",
    FLD_BOND_TYPE  : "%d",
    FLD_ANGLE_TYPE : "%d",
    FLD_DIH_TYPE   : "%d",
    FLD_IMP_TYPE   : "%d",
}



## A simple class that parses and mangles LAMMPS data files.
# 
# Keep in mind that:
# 
# -- data files are read into memory all at once (if you feed a
# gigabyte, the whole data is first read into a local variable and
# then parsed) and multiple copies of it are kept. 
# 
# -- the code accepts simple URLs: feeding an http link works (keep
# in mind the previous point...)
# 
# -- Not all possible checks are performed: if a valid file is
# passed, then the parser should be able to recognize it. However if
# an invalid file is parsed, there is no guarantee that the program
# will return an error.
# 
# -- Only atom-style 'full' is supported.
# 
# -- Only dihedral-style and angle-style 'charmm' is supported.
# 
# -- Only bond_style and improper_style 'harmonic'
#
# -- Only pair_style lj/charmm/coul/long is supported (lj/cut/coul/long required...)
# 
# -- In the database commit, the whole data is committed in a single
#    transaction (this could be a major performance issue). FIXME:
#    contatta zambon e chiedigli come fare.
class LAMMPSData:
    """A simple class that parses and mangles LAMMPS data files.

    Keep in mind that:

    -- data files are read into memory all at once (if you feed a
    gigabyte, the whole data is first read into a local variable and
    then parsed) and multiple copies of it are kept. 

    -- the code accepts simple URLs: feeding an http link works (keep
    in mind the previous point...)

    -- Not all possible checks are performed: if a valid file is
    passed, then the parser should be able to recognize it. However if
    an invalid file is parsed, there is no guarantee that the program
    will return an error.

    -- Only atom-style 'full' is supported.

    -- Only dihedral-style 'charmm' is supported.

    -- Only angle-style 'charmm' is supported.

    -- In the database commit, the whole data is committed in a single
       transaction (this could be a major performance issue). FIXME:
       contatta zambon e chiedigli come fare."""

    # Fields definition for all quantities in the data file. Since
    # different simulation types have different fields, a dictionary
    # of simulations is provided
    __section_formats = {
        1 : {
            # Atom properties sections
            "Atoms"                       : (FLD_ATOM, FLD_MOL, FLD_TYPE,                      # Atom number, molecule and type
                                             FLD_DOUBLE, FLD_DOUBLE, FLD_DOUBLE,               # x y z 
                                             FLD_DOUBLE,                                       # Charge
                                             FLD_INT | FLD_OPT,                                # Optional nx
                                             FLD_INT | FLD_OPT,                                # Optional ny
                                             FLD_INT | FLD_OPT),                               # Optional nz
            "Velocities"                  : (FLD_ATOM,                                         # Atom number
                                             FLD_DOUBLE, FLD_DOUBLE, FLD_DOUBLE),              # Vx, Vy, Vz
            "Masses"                      : (FLD_TYPE, FLD_DOUBLE),                            # Type, mass        
            "Shapes"                      : (FLD_TYPE, FLD_DOUBLE, FLD_DOUBLE, FLD_DOUBLE),    # Type, ellipsoid axis
            "Dipoles"                     : (FLD_TYPE, FLD_DOUBLE),                            # Type, dipole
            # Molecular topology sections
            "Bonds"                       : (FLD_BOND, FLD_BOND_TYPE,                          # Bond N, Bond type
                                             FLD_ATOM, FLD_ATOM),                              # Atom 1 and 2
            "Angles"                      : (FLD_ANGLE, FLD_ANGLE_TYPE,                        # Angle N, Angle type
                                             FLD_ATOM, FLD_ATOM, FLD_ATOM),                    # Atom 1, 2 and 3
            "Dihedrals"                   : (FLD_DIH, FLD_DIH_TYPE,                            # Dih. N and type
                                             FLD_ATOM, FLD_ATOM, FLD_ATOM, FLD_ATOM),          # Atom 1, 2, 3 and 4
            "Impropers"                   : (FLD_IMP, FLD_IMP_TYPE,                            # Imp. N and type
                                             FLD_ATOM, FLD_ATOM, FLD_ATOM, FLD_ATOM),          # Atom 1, 2, 3 and 4
            # Force field section
            "Pair Coeffs"                 : (FLD_TYPE,                                         # Type 
                                             FLD_DOUBLE, FLD_DOUBLE),  # Coefficients
            "Bond Coeffs"                 : (FLD_BOND_TYPE,                                    # Bond type
                                             FLD_DOUBLE, FLD_DOUBLE),                          # Coeffs
            "Angle Coeffs"                : (FLD_ANGLE_TYPE,                                   # Angle type
                                             FLD_DOUBLE, FLD_DOUBLE),  # Coeffs
            "Dihedral Coeffs"             : (FLD_DIH_TYPE,                                     # Dyhed. type
                                             FLD_DOUBLE, FLD_INT, FLD_INT),        # Coeffs
            "Improper Coeffs"             : (FLD_IMP_TYPE,                                     # Improper type
                                             FLD_DOUBLE, FLD_DOUBLE),                          # Coeff
            # Class 2 force field sections
            "BondBond Coeffs"             : (FLD_ANGLE_TYPE,                                   # Angle type
                                             FLD_DOUBLE, FLD_DOUBLE),                          # Coeff
            "BondAngle Coeffs"            : (FLD_ANGLE_TYPE,                                   # Angle type
                                             FLD_DOUBLE, FLD_DOUBLE),                          # Coeff
            "MiddleBondTorsion Coeffs"    : (FLD_DIH_TYPE,                                     # Dihedral type
                                             FLD_DOUBLE, FLD_DOUBLE, FLD_DOUBLE,               # A1 A2 A3
                                             FLD_DOUBLE),                                      # r2
            "EndBondTorsion Coeffs"       : (FLD_DIH_TYPE,                                     # Dihedral type
                                             FLD_DOUBLE, FLD_DOUBLE, FLD_DOUBLE,               # B1 B2 B3
                                             FLD_DOUBLE, FLD_DOUBLE, FLD_DOUBLE,               # C1 C2 C3
                                             FLD_DOUBLE, FLD_DOUBLE),                          # r1 r3
            "AngleTorsion Coeffs"         : (FLD_DIH_TYPE,                                     # Dihedral type
                                             FLD_DOUBLE, FLD_DOUBLE, FLD_DOUBLE,               # D1 D2 D3
                                             FLD_DOUBLE, FLD_DOUBLE, FLD_DOUBLE,               # E1 E2 E3
                                             FLD_DOUBLE, FLD_DOUBLE),                          # theta1 theta2
            "AngleAngleTorsion Coeffs"    : (FLD_DIH_TYPE,                                     # Dihedral type
                                             FLD_DOUBLE,                                       # M
                                             FLD_DOUBLE, FLD_DOUBLE),                          # theta1 theta2
            "BondBond13 Coeffs"           : (FLD_DIH_TYPE,                                     # Dihedral type
                                             FLD_DOUBLE,                                       # N
                                             FLD_DOUBLE, FLD_DOUBLE),                          # r1 r3
            "AngleAngle Coeffs"           : (FLD_IMP_TYPE,                                     # Improper type
                                             FLD_DOUBLE, FLD_DOUBLE, FLD_DOUBLE, FLD_DOUBLE)   # K, theta0, K_ub, r_ub
            },
        2: {
            # Atom properties sections
            "Atoms"                       : (FLD_ATOM, FLD_MOL, FLD_TYPE,                      # Atom number, molecule and type
                                             FLD_DOUBLE, FLD_DOUBLE, FLD_DOUBLE,               # x y z 
                                             FLD_DOUBLE,                                       # Charge
                                             FLD_INT | FLD_OPT,                                # Optional nx
                                             FLD_INT | FLD_OPT,                                # Optional ny
                                             FLD_INT | FLD_OPT),                               # Optional nz
            "Velocities"                  : (FLD_ATOM,                                         # Atom number
                                             FLD_DOUBLE, FLD_DOUBLE, FLD_DOUBLE),              # Vx, Vy, Vz
            "Masses"                      : (FLD_TYPE, FLD_DOUBLE),                            # Type, mass        
            "Shapes"                      : (FLD_TYPE, FLD_DOUBLE, FLD_DOUBLE, FLD_DOUBLE),    # Type, ellipsoid axis
            "Dipoles"                     : (FLD_TYPE, FLD_DOUBLE),                            # Type, dipole
            # Molecular topology sections
            "Bonds"                       : (FLD_BOND, FLD_BOND_TYPE,                          # Bond N, Bond type
                                             FLD_ATOM, FLD_ATOM),                              # Atom 1 and 2
            "Angles"                      : (FLD_ANGLE, FLD_ANGLE_TYPE,                        # Angle N, Angle type
                                             FLD_ATOM, FLD_ATOM, FLD_ATOM),                    # Atom 1, 2 and 3
            "Dihedrals"                   : (FLD_DIH, FLD_DIH_TYPE,                            # Dih. N and type
                                             FLD_ATOM, FLD_ATOM, FLD_ATOM, FLD_ATOM),          # Atom 1, 2, 3 and 4
            "Impropers"                   : (FLD_IMP, FLD_IMP_TYPE,                            # Imp. N and type
                                             FLD_ATOM, FLD_ATOM, FLD_ATOM, FLD_ATOM),          # Atom 1, 2, 3 and 4
            # Force field section
            "Pair Coeffs"                 : (FLD_TYPE,                                         # Type 
                                             FLD_DOUBLE, FLD_DOUBLE, FLD_DOUBLE, FLD_DOUBLE),  # Coefficients
            "Bond Coeffs"                 : (FLD_BOND_TYPE,                                    # Bond type
                                             FLD_DOUBLE, FLD_DOUBLE),                          # Coeffs
            "Angle Coeffs"                : (FLD_ANGLE_TYPE,                                   # Angle type
                                             FLD_DOUBLE, FLD_DOUBLE, FLD_DOUBLE, FLD_DOUBLE),  # Coeffs
            "Dihedral Coeffs"             : (FLD_DIH_TYPE,                                     # Dyhed. type
                                             FLD_DOUBLE, FLD_INT, FLD_INT, FLD_DOUBLE),        # Coeffs
            "Improper Coeffs"             : (FLD_IMP_TYPE,                                     # Improper type
                                             FLD_DOUBLE, FLD_DOUBLE),                          # Coeff
            # Class 2 force field sections
            "BondBond Coeffs"             : (FLD_ANGLE_TYPE,                                   # Angle type
                                             FLD_DOUBLE, FLD_DOUBLE),                          # Coeff
            "BondAngle Coeffs"            : (FLD_ANGLE_TYPE,                                   # Angle type
                                             FLD_DOUBLE, FLD_DOUBLE),                          # Coeff
            "MiddleBondTorsion Coeffs"    : (FLD_DIH_TYPE,                                     # Dihedral type
                                             FLD_DOUBLE, FLD_DOUBLE, FLD_DOUBLE,               # A1 A2 A3
                                             FLD_DOUBLE),                                      # r2
            "EndBondTorsion Coeffs"       : (FLD_DIH_TYPE,                                     # Dihedral type
                                             FLD_DOUBLE, FLD_DOUBLE, FLD_DOUBLE,               # B1 B2 B3
                                             FLD_DOUBLE, FLD_DOUBLE, FLD_DOUBLE,               # C1 C2 C3
                                             FLD_DOUBLE, FLD_DOUBLE),                          # r1 r3
            "AngleTorsion Coeffs"         : (FLD_DIH_TYPE,                                     # Dihedral type
                                             FLD_DOUBLE, FLD_DOUBLE, FLD_DOUBLE,               # D1 D2 D3
                                             FLD_DOUBLE, FLD_DOUBLE, FLD_DOUBLE,               # E1 E2 E3
                                             FLD_DOUBLE, FLD_DOUBLE),                          # theta1 theta2
            "AngleAngleTorsion Coeffs"    : (FLD_DIH_TYPE,                                     # Dihedral type
                                             FLD_DOUBLE,                                       # M
                                             FLD_DOUBLE, FLD_DOUBLE),                          # theta1 theta2
            "BondBond13 Coeffs"           : (FLD_DIH_TYPE,                                     # Dihedral type
                                             FLD_DOUBLE,                                       # N
                                             FLD_DOUBLE, FLD_DOUBLE),                          # r1 r3
            "AngleAngle Coeffs"           : (FLD_IMP_TYPE,                                     # Improper type
                                             FLD_DOUBLE, FLD_DOUBLE, FLD_DOUBLE, FLD_DOUBLE)   # K, theta0, K_ub, r_ub
            }
        }

    # This is the list of fields in the MySQL db, each field should
    # match one in the __section_formats dictionary, with the same
    # order. the id_simulation is implicit and asssumed as always
    # present
    __mysql_names = {
        1: {"Angles": ("MS2_DATA_angles",
                       ("angle", "type", "atom1", "atom2", "atom3")),
            "AngleTorsion Coeffs": ("MS2_DATA_angletorsion_coeffs",
                                    ("type", "D1", "D2", "D3", "E1", "E2", "E3", "theta1", "theta2")),
            "AngleAngleTorsion Coeffs": ("MS2_DATA_angleangletorsion_coeffs",
                                         ("type", "M", "theta1", "theta2")),
            "AngleAngle Coeffs": ("MS2_DATA_angleangle_coeffs",
                                  ("type", "K", "theta0", "K_ub", "r_ub")),
            "Angle Coeffs": ("MS2_DATA_angle_coeffs",
                             ("type", "coeff1", "coeff2")),
            "Atoms": ("MS2_DATA_atoms",
                      ("id_atom", "molecule", "type", "charge", "x", "y", "z", "nx", "ny", "nz")),
            "BondAngle Coeffs": ("MS2_DATA_bondangle_coeffs",
                                 ("type", "coeff1", "coeff2")),
            "BondBond13 Coeffs": ("MS2_DATA_bondbond13_coeffs",
                                  ("type", "N", "r1", "r3")),
            "BondBond Coeffs": ("MS2_DATA_bondbond_coeffs",
                                ("type", "coeff1", "coeff2")),
            "Bonds": ("MS2_DATA_bonds",
                      ("bond", "type", "atom1", "atom2")),
            "Bond Coeffs": ("MS2_DATA_bond_coeffs",
                            ("type", "coeff1", "coeff2")),
            "box_size": ("MS2_DATA_box_size",
                         ("lindex", "val1", "val2", "label1", "label2")),
            "box_tilt": ("MS2_DATA_box_tilt",
                         ("lindex", "xy", "xz", "yz")),
            "Dihedrals": ("MS2_DATA_dihedrals",
                          ("dihedral", "type", "atom1", "atom2", "atom3", "atom4")),
            "Dihedral Coeffs": ("MS2_DATA_dihedral_coeffs",
                                ("type", "coeff1", "coeff2", "coeff3")),
            "Dipoles": ("MS2_DATA_dipoles",
                        ("type", "dipole")),
            "EndBondTorsion Coeffs": ("MS2_DATA_endbondtorsion_coeffs",
                                      ("type", "B1", "B2", "B3", "C1", "C2", "C3", "r1", "r3")),
            "Impropers": ("MS2_DATA_impropers",
                          ("improper", "type", "atom1", "atom2", "atom3", "atom4")),
            "Improper Coeffs": ("MS2_DATA_improper_coeffs",
                                ("type", "coeff1", "coeff2")),
            "Masses": ("MS2_DATA_masses",
                       ("type", "mass")),
            "MiddleBondTorsion Coeffs": ("MS2_DATA_middlebondtorsion_coeffs",
                                         ("type", "A1", "A2", "A3", "r2")),
            "Pair Coeffs": ("MS2_DATA_pair_coeffs",
                            ("type", "coeff1", "coeff2")),
            "Shapes": ("MS2_DATA_shapes",
                       ("type", "x axis", "y axis", "z axis")),
            "Velocities": ("MS2_DATA_velocities",
                           ("id_atom", "Vx", "Vy", "Vz"))
            },
        2: {"Angles": ("MS2_DATA_angles",
                       ("angle", "type", "atom1", "atom2", "atom3")),
            "AngleTorsion Coeffs": ("MS2_DATA_angletorsion_coeffs",
                                    ("type", "D1", "D2", "D3", "E1", "E2", "E3", "theta1", "theta2")),
            "AngleAngleTorsion Coeffs": ("MS2_DATA_angleangletorsion_coeffs",
                                         ("type", "M", "theta1", "theta2")),
            "AngleAngle Coeffs": ("MS2_DATA_angleangle_coeffs",
                                  ("type", "K", "theta0", "K_ub", "r_ub")),
            "Angle Coeffs": ("MS2_DATA_angle_coeffs",
                             ("type", "coeff1", "coeff2", "coeff3", "coeff4")),
            "Atoms": ("MS2_DATA_atoms",
                      ("id_atom", "molecule", "type", "charge", "x", "y", "z", "nx", "ny", "nz")),
            "BondAngle Coeffs": ("MS2_DATA_bondangle_coeffs",
                                 ("type", "coeff1", "coeff2")),
            "BondBond13 Coeffs": ("MS2_DATA_bondbond13_coeffs",
                                  ("type", "N", "r1", "r3")),
            "BondBond Coeffs": ("MS2_DATA_bondbond_coeffs",
                                ("type", "coeff1", "coeff2")),
            "Bonds": ("MS2_DATA_bonds",
                      ("bond", "type", "atom1", "atom2")),
            "Bond Coeffs": ("MS2_DATA_bond_coeffs",
                            ("type", "coeff1", "coeff2")),
            "box_size": ("MS2_DATA_box_size",
                         ("lindex", "val1", "val2", "label1", "label2")),
            "box_tilt": ("MS2_DATA_box_tilt",
                         ("lindex", "xy", "xz", "yz")),
            "Dihedrals": ("MS2_DATA_dihedrals",
                          ("dihedral", "type", "atom1", "atom2", "atom3", "atom4")),
            "Dihedral Coeffs": ("MS2_DATA_dihedral_coeffs",
                                ("type", "coeff1", "coeff2", "coeff3", "coeff4")),
            "Dipoles": ("MS2_DATA_dipoles",
                        ("type", "dipole")),
            "EndBondTorsion Coeffs": ("MS2_DATA_endbondtorsion_coeffs",
                                      ("type", "B1", "B2", "B3", "C1", "C2", "C3", "r1", "r3")),
            "Impropers": ("MS2_DATA_impropers",
                          ("improper", "type", "atom1", "atom2", "atom3", "atom4")),
            "Improper Coeffs": ("MS2_DATA_improper_coeffs",
                                ("type", "coeff1", "coeff2")),
            "Masses": ("MS2_DATA_masses",
                       ("type", "mass")),
            "MiddleBondTorsion Coeffs": ("MS2_DATA_middlebondtorsion_coeffs",
                                         ("type", "A1", "A2", "A3", "r2")),
            "Pair Coeffs": ("MS2_DATA_pair_coeffs",
                            ("type", "coeff1", "coeff2", "coeff3", "coeff4")),
            "Shapes": ("MS2_DATA_shapes",
                       ("type", "x axis", "y axis", "z axis")),
            "Velocities": ("MS2_DATA_velocities",
                           ("id_atom", "Vx", "Vy", "Vz"))
            }
        }
    
    def __init__(self, URL = None, simulation_type = TYPES[TYPES.keys()[0]]):
        self.__full = False
        if URL != None:
            self.parse_URL(URL)
        self.simulation_type = simulation_type

    def flush_data(self):
        """Remove all the LAMMPS data from the parser.

        Used to go back to a clean-consistent state after an error or,
        on user request, to parse another file."""
        # Misc vars: not really LAMMPS data
        self.__current_line = -1
        self.__lines = None
        
        # Header
        try:
            del(self.__headerdata)
        except:
            pass
        # Sections
        try:
            del(self.__sections_data)
        except:
            pass
        
        self.__full = False

    def parse_URL(self, URL):
        """Parse a LAMMPS data file

        URL: link to the file to parse

        Returns True on error, False on success"""
        if self.__full:
            WARNING("Cannot parse the data: LAMMPS data already present")
            return True

        try:
            f = urllib2.urlopen(URL)
            text = f.read() 
            f.close()
        except RuntimeError, err:
            ERR("Unable to get the data from '%s': %s" % (URL, err))
            return True

        self.parse(text)
        return False


    def parse_file(self, filename):
        """Parse a LAMMPS data file

        filename: the name of the file to parse

        Returns True on error, False on success"""
        if self.__full:
            WARNING("Cannot parse the data: LAMMPS data already present")
            return True

        try:
            f = file(filename)
            text = f.read() 
            f.close()
        except Exception, err:
            ERR("Unable to get the data from '%s': %s" % (filename, err))
            return True
        
        self.parse(text)
        return False

    def parse(self, text):
        """Parse input in the form of a LAMMPS data file.

        text: the complete content of a LAMMPS data file"""

        self.__lines = text.splitlines()

        self.__current_line = 0

        # Parse the header
        self.__header()

        # Parse the other sections
        try:
            self._sections()
        except RuntimeError, error:
            ERR(str(error), 1)
        except ValueError:
            ERR("Data conversion failed on line %d" % self.__current_line, 1)
        # We do have data in the structures
        self.__full = True
            
    def __header(self):
        """Parse the first definition, until the \"Masses\" section

        The missing values are added"""
        # The box size is not mandatory!

        DEBUG_MSG("Parsing the header...")
        # TOKENS
        # FIXME: DOUBLE and INTEGER match wrong expressions too (like
        # 0.004.4e12 or ++++34+34). They do match the correct one
        # though, therefore is fine for what i need
        INTEGER   = "([0-9]+)"
        BLANK     = "[ \t]+"
        STRING    = "([^ \t]+)"
        DOUBLE    = "([0-9.eE+\-]+)"
        BOXEXP    = "([xyz](lo|hi))"
        # Matching regexps for the header expressions
        NUM   = INTEGER + BLANK + STRING + "$"
        TYPES = INTEGER + BLANK + STRING + BLANK + STRING + "$"
        BOX   = DOUBLE  + BLANK + DOUBLE + BLANK + BOXEXP + BLANK + BOXEXP + "$"
        TILT  = DOUBLE  + BLANK + DOUBLE  + BLANK + DOUBLE  + BLANK + "xy xz yz$"
        # available names for the number and types (FIXME: this could be done better with sets)
        AVAILNUM = {"atoms": None, "bonds": None, "angles": None,
                    "dihedrals": None, "impropers": None}
        AVAILTYPES = {"atom": None, "bond": None,
                      "angle": None, "dihedral": None,
                      "improper": None}
        # This option isn't supported: we will exit if we ever find it
        UNSUPPORTED = "extra bond per atom"
        
        # Create a data structure for the various keywords
        self.__headerdata = {"number":{}, "types":{}, "box":[], "tilt": None}
        
        # Discard the first line
        self.__current_line += 1

        # Temporary location for the box data
        tmpheader = {}
        for rawline in self.__lines[self.__current_line:]:
            # Strip away any comment
            tmp = re.match("([^#]*)(#.*)?$", rawline).group(1)
            # And trailing/heading space...
            line = re.match("[ \t]*(.*[^ \t])?[ \t]*$", tmp).group(1)

            # Blank/comment line
            if line == '' or line == None:
                self.__current_line += 1
                continue

            if re.search(re.escape(UNSUPPORTED), line):
                error = "The option '%s' is not supported (line %d)" % (UNSUPPORTED, self.__current_line)
                raise RuntimeError, error

            # X number (atoms, dihedrals, etc...)
            tmp = re.match(NUM, line)
            if tmp:
                value = int(tmp.group(1))
                name  = tmp.group(2)
                if not AVAILNUM.has_key(name):
                    error = "On line %d: '%s' is not a vaild quantity" % (self.__current_line, name)
                    raise RuntimeError, error
                self.__headerdata["number"][name] = value
                self.__current_line += 1
                continue

            # X types (atoms, dihedrals, etc...)
            tmp = re.match(TYPES, line)
            if tmp:
                value = int(tmp.group(1))
                types = tmp.group(3)
                name  = tmp.group(2)
                if types != "types":
                    error = "On line %d: expected a 'types' keyword, found '%s'" % (self.__current_line, types)
                    raise RuntimeError, error
                if not AVAILTYPES.has_key(name):
                    error = "On line %d: '%s' is not a vaild type" % (self.__current_line, name)
                    raise RuntimeError, error
                self.__headerdata["types"][name] = value
                self.__current_line += 1
                continue

            # xlo/hi etc. expression
            tmp = re.match(BOX, line)
            if tmp:
                val1 = float(tmp.group(1))
                val2 = float(tmp.group(2))
                st1  = tmp.group(3)
                st2  = tmp.group(5)
                tmpheader[(st1, st2)] = (val1, val2)
                self.__current_line += 1
                continue

            tmp = re.match(TILT, line)
            if tmp:
                if self.__headerdata["tilt"] != None:
                    self._abort()
                val1 = float(tmp.group(1))
                val2 = float(tmp.group(2))
                val3 = float(tmp.group(3))
                self.__headerdata["tilt"] = (val1, val2, val3)
                self.__current_line += 1
                continue
                        
            # If we didn't match anything, then the header section is terminated
            DEBUG_MSG("Done\n")
            break
        
        for key, value in tmpheader.iteritems():
            self.__headerdata["box"].append((value[0], value[1], key[0], key[1]))

        # Check that the box  are in the correct number
        lines = len(self.__headerdata["box"])
        if (lines != 0) and (lines != 3):
            error = "Incorrect box definition: after reaching the header boundary (line %d)" % (self.__current_line + 1)
            raise RuntimeError, error

        for i in ("atoms", "bonds", "angles", "dihedrals", "impropers"):
            if not self.__headerdata["number"].has_key(i):
                self.__headerdata["number"][i] = 0
        
        for i in ("atom","bond","angle","dihedral","improper"):
            if not self.__headerdata["types"].has_key(i):
                self.__headerdata["types"][i] = 0
                    

    def _parse_section(self, fmt, section_name):
        """Parse a generic section in the data file"""
        # Ignore the first line of the section
        self.__current_line += 1

        DEBUG_MSG("Parsing %s..." % section_name)

        # The line can have all optional values or none
        Nfields_all = len(fmt)
        fmt_min = [ val for val in fmt if (val & FLD_OPT) == 0 ]
        Nfields_min = len(fmt_min)

        data = []

        end_of_data = False
        for line in self.__lines[self.__current_line:]:
            self.__current_line += 1
            # Purge Comments and split
            tmp = re.match("([^#]*)", line).group(1).split()
            # A blank line implies the end of the data
            if re.match("[ \t]*$", line):
                break
            elif (len(tmp) != Nfields_all) and (len(tmp) != Nfields_min):
                self._abort()
            newdata = []
            if len(tmp) == Nfields_all:
                # Full format: parse the line
                for i in range(Nfields_all):
                    tmp2 = fmt[i] & (~FLD_OPT)
                    newdata.append(FLD_VARTYPE[tmp2](tmp[i]))
                data.append(tuple(newdata))
            else:
                # Replace FLD_OPT values with integer 0
                j = 0
                for i in range(Nfields_all):
                    if fmt[j] & FLD_OPT:
                        newdata.append(0)
                    else:
                        newdata.append(FLD_VARTYPE[fmt_min[j]](tmp[i]))
                        j += 1
                data.append(newdata)
            
        # Ok, we are done with the data in the section, however we
        # still have to purge all the trailing blank lines (if any)
        for line in self.__lines[self.__current_line:]:
            if re.match("[ \t]*$", line):
                self.__current_line += 1
                continue
            break

        self.__sections_data[section_name] = data
        DEBUG_MSG("Done\n")
            
    def _abort(self):
        error = "LAMMPS data mismatch at line %d" % (self.__current_line + 1)
        raise RuntimeError,error
        
    def _verify_values(self):
        """Check if the 'x' numbers and 'x' type match.

        Throw in a couple of other checks, as a bonus...

        Raises RuntimeError if the tests are not passed"""

        if len(self.__headerdata["types"]) == 0 or len(self.__headerdata["number"]) == 0:
            raise RuntimeError, "Empty simulations are not allowed"


        if not (self.__sections_data.has_key("Atoms") and self.__sections_data.has_key("Masses")):
            raise RuntimeError, "Both the Atoms and Masses sections should be present"


        # Lists of check to perform.
        # First field the section type, second the section name, third the data section name        
        checks = (
            # Number checks
            ("number", "atoms", ("Atoms", "Velocities")),
            ("number", "bonds", ("Bonds",)),
            ("number", "angles", ("Angles",)),
            ("number", "dihedrals", ("Dihedrals",)),
            ("number", "impropers", ("Impropers",)),
            # Type checks
            ("types", "atom", ("Masses", "Shapes", "Dipoles", "Pair Coeffs")),
            ("types", "bond", ("Bond Coeffs", )),
            ("types", "angle", ("Angle Coeffs", "BondBond Coeffs", "BondAngle Coeffs", )),
            ("types", "dihedral", ("Dihedral Coeffs", "MiddleBondTorsion Coeffs",
                                  "EndBondTorsion Coeffs", "AngleTorsion Coeffs",
                                  "AngleAngleTorsion Coeffs", "BondBond13 Coeffs")),
            ("types", "improper", ("Improper Coeffs", "AngleAngle Coeffs")),            
        )
        # Perform the checks. Skip sections, if not found
        for check in checks:
            value    = check[0]
            quantity = check[1]
            section  = check[2]
            N = self.__headerdata[value][quantity]
            
            for section in section:
                if self.__sections_data.has_key(section):
                    if len(self.__sections_data[section]) != N:
                        error = "Invalid %s of %s in the %s section" % (value, quantity, section)
                        raise RuntimeError, error
        
    def _sections(self):
        """Parse the sections in the file

        NOTE: LAMMPS support for the comments right after the names of
        the sections seem to be pretty random (works on single word
        sections, not on double word ones, for instance...) and
        therefore i will consider any comment after a section name
        like an error"""

        self.__sections_data = {}

        while True:
            # Strip any unneeded space (comments should be apparently be kept)
            # tmp = re.match("([^#]*)(#.*)?$", self.__lines[self.__current_line]).group(1)
            line = re.match("[ \t]*(.*[^ \t])?[ \t]*$", self.__lines[self.__current_line]).group(1)
            self.__current_line += 1
            # This should be granted by the logic of the parser
            assert(line != None and line!= '')
                
            # Find the section name
            section_name = re.match("(.*[^ \t])[ \t]*$", line).group(1)
            # Get the correct format
            try:
                fmt =  self.__section_formats[self.simulation_type][section_name]
            except KeyError, err:
                error = "Unrecognized section '%s' at line %d" % (section_name, self.__current_line)
                raise RuntimeError, error
            # Feed it to the worker function
            self._parse_section(fmt, section_name)
            if self.__current_line == len(self.__lines):
                break

        self._verify_values()

#########################################################
#             FILE OUTPUT FUNCTIONS                     #
#########################################################

    def __get_format(self, section_name):
        """Given  a section, return an appropriate format string"""
        values = self.__section_formats[self.simulation_type][section_name]
        fmt = FLD_PRINTTYPE[values[0] & (~FLD_OPT)]
        for element in values[1:]:
            fmt += " " + FLD_PRINTTYPE[element  & (~FLD_OPT)]
        fmt += "\n"
        return fmt
        
    def dump_data_file(self, filename):
        """Writes the LAMMPS data, correctly formatted, on a file.

        filename:   file that will be created/overwritten with the data

        Returns True on error, False on success"""

        data_string = self.dump_data()
        if data_string == None:
            return True

        f = file(filename, "w")
        f.write(data_string)
        f.close()
        
        return False 
        
    def dump_data(self):
        """Returns the content of the file, correctly formatted

        data on success, None on error"""

        if not self.__full:
            WARNING("Cannot dump the data: no data present")
            return None

        data = "LAMMPS Description\n\n"

        for qnt,value in self.__headerdata["number"].iteritems():
            data += "%15d %s\n" % (value, qnt)

        data += "\n"

        for qnt,value in self.__headerdata["types"].iteritems():
            data += "%15d %s types\n" % (value, qnt)
        
        data += "\n"
        
        for values in self.__headerdata["box"]:
            data += " %-10.10g %-10.10g %3s %3s\n" % values
            
        data += "\n"

        if self.__headerdata["tilt"] != None:
            data += " %-10.10g %-10.10g %-10.10g xy xz yz\n" % self.__headerdata["tilt"]

        sections_done = {}

        for name in ("Atoms", "Masses"):
            data += "\n%s\n\n" % name
            fmt = self.__get_format(name)
            for line in self.__sections_data[name]:
                data += "  " + fmt % tuple(line)
            sections_done[name] = 1

        for name, section_data in self.__sections_data.iteritems():
            if sections_done.has_key(name):
                continue
            data += "\n%s\n\n" % name
            fmt = self.__get_format(name)
            for line in section_data:
                data += "  " + fmt % tuple(line)
            sections_done[name] = 1
            
        return data

#########################################################
#             DATABASE FUNCTIONS                        #
#########################################################

    def __check_tables(self, cursor):
        """Verify that the section we have are consistent with the DB"""
        try:
            cursor.execute("SHOW TABLES")
            tables = dict([ (val[0], True) for val in cursor.fetchall()])
            for section_name in self.__sections_data.keys():
                db_section = self.__mysql_names[self.simulation_type][section_name][0]
                if not tables.has_key(db_section):
                    ERR("The section '%s' in the data file is not present in the DB" % db_section)
                    return True
        except MySQLdb.Error,error:
            ERR("Error %d: %s\n" % (error.args[0], error.args[1]))
            return True
        return False

    # self.__mysql_names[self.simulation_type][section_name][0] (nome della tabella) 
    # self.__mysql_names[self.simulation_type][section_name][1] (tuple con i valori, in ordine)
    # self.__section_formats[self.simulation_type][section_name] tuple con i formati da stampare
    def __insert_instruction(self, section_name):
        """Create the insert instruction that will be used to populate de tables."""
        values = self.__section_formats[self.simulation_type][section_name]
        tablename = self.__mysql_names[self.simulation_type][section_name][0]
        fieldnames = self.__mysql_names[self.simulation_type][section_name][1]

        fields = "id_simulation"
        for name in fieldnames:
            fields += ", %s" % name

        formats = "%d"
        for fmt in values:
            formats += ", %s" % FLD_PRINTTYPE[fmt & (~FLD_OPT)]

        tmp = (tablename, fields, formats)
        command = """INSERT %s
        (%s)
        VALUES (%s)""" % tmp

#        DEBUG_MSG("COMMAND:\n'%s'\n" % command)
        return command

    def _dump_header_tables(self, cursor, simindex):
        """Dump in the DB only the header data required to re-create the data file, if present"""

        DEBUG_MSG("Dumping box size...")
        index = 1
        for line in self.__headerdata["box"]:
            data = tuple([index] + list(line))
            command = """INSERT %s
            (id_simulation, lindex, val1, val2, label1, label2)
            VALUES (%d, %d, %-10.10g, %-10.10g, '%s', '%s')"""
            instruction = command % tuple([self.__mysql_names[self.simulation_type]["box_size"][0], simindex] + list(data))        
            cursor.execute(instruction)
            index += 1
        DEBUG_MSG("Done\n")
        
        if self.__headerdata["tilt"] != None:
            DEBUG_MSG("Dumping box tilt...")
            command = """INSERT %s
            (id_simulation, lindex, xy, xz, yz)
            VALUES (%d, 1, %-10.10g, %-10.10g, %-10.10g)"""
            instruction = command % tuple([self.__mysql_names[self.simulation_type]["box_tilt"][0], simindex] + list(self.__headerdata["tilt"]))
            cursor.execute(instruction)
            DEBUG_MSG("Done\n")
                    
    def _dump_table(self, simindex, cursor, section_name):
        """Dump a single table to the DB.

        section_name is the name of the section in our data structure"""
        DEBUG_MSG("Dumping %s..." % section_name)
        fmt = self.__insert_instruction(section_name)
        for line in self.__sections_data[section_name]:
            cursor.execute(fmt % tuple([simindex] + list(line)))
        DEBUG_MSG("Done\n")

    def _flush_database(self, cursor, simindex):
        cursor.execute("DELETE FROM `%s`" % self.__mysql_names[self.simulation_type]["box_size"][0])
        cursor.execute("DELETE FROM `%s`" % self.__mysql_names[self.simulation_type]["box_tilt"][0])
        for section in self.__section_formats[self.simulation_type].keys():
            cursor.execute("DELETE FROM `%s`" % self.__mysql_names[self.simulation_type][section][0])
        

    def _write_tables(self, simindex, cursor, flush = False):
        """Dump all the data into the DB tables
        
        FIXME: This uses a single transaction to write the whole
        content... not a brilliant idea probably"""
        
        cursor.execute("START TRANSACTION")
        if flush:
            self._flush_database(cursor, simindex)
        try:
            self._dump_header_tables(cursor, simindex)
            for section in self.__sections_data.keys():
                self._dump_table(simindex, cursor, section)
            cursor.execute("COMMIT")
        except MySQLdb.Error, error:
            ERR("Error %d: %s\n" % (error.args[0], error.args[1]))
            cursor.execute("ROLLBACK")
            return True


    def __connect(self, host, user, password, db):
        """Establish a connection to the database"""
        if host == None:
            host = DEFAULT_HOST
        if user == None:
            user = DEFAULT_LOGIN
        if password == None:
            password = DEFAULT_PASSWORD
        if db == None:
            ERR("Database not set!")
            return True
        
        # Connect to the database
        connection = MySQLdb.connect(host = host, user = user,
                                     passwd = password, db = db)
        cursor = connection.cursor()
        cursor.execute("SET autocommit = 0")
        return connection, cursor

    def commit_to_db(self, simindex, host = None, user = None, password = None, db = None, flush_first = False):
        """Commit all the data to a database

        returns True on error, False on success"""
        if not DB_INTERFACE:
            WARNING("Database interface not present")
            return True

        if not self.__full:
            WARNING("No data to populate the database with")
            return True

        if simindex == None:
            ERR("The simulation index was not specified", 1)

        # TODO/FIXME: codice un po' schifoso...
        try:
            connection, cursor = self.__connect(host, user, password, db)
        except MySQLdb.Error, error:
            ERR("Error %d: %s\n" % (error.args[0], error.args[1]))
            try:
                connection.close()
            except Exception:
                pass
            return True
        # Check if all the tables are present
        try:
            # Check if our sections correspond to a table name
            if self.__check_tables(cursor):
                return True

            # Write the sections into the tables
            if self._write_tables(simindex, cursor, flush = flush_first):
                return True
        finally:
            # Finalize the DB regardless of errors
            cursor.close()
            connection.close()            
        return False

    def _read_db_tables(self, cursor, simindex):
        """Read the content of the database tables into the instance"""
        self.__headerdata = {"number":{}, "types":{}}
        # Read the "special" box size table
        command = "SELECT lindex, val1, val2, label1, label2 from %s WHERE id_simulation = %d"
        instruction = command % (self.__mysql_names[self.simulation_type]["box_size"][0], simindex)
        num = cursor.execute(instruction)
        if num == 3:
            self.__headerdata["box"] = []
            for line in cursor.fetchall():
                self.__headerdata["box"].append(line[1:])
        elif num == 0:
            self.__headerdata["box"] = []
        else:
            raise RuntimeError, "Inconsistent data in the  db in table 'box size'"
        # Read the "special" box tilt table
        command = "SELECT lindex, xy, xz, yz FROM `%s`"
        instruction = command % self.__mysql_names[self.simulation_type]["box_tilt"][0]
        num = cursor.execute(instruction)
        if num != 0:
            MSG("Box tilt found")            
            self.__headerdata["tilt"] = cursor.fetchall()[0][1:]
        else:
            self.__headerdata["tilt"] = None
                
        self.__sections_data = {}
        # HIC SUNT LEONES: mi sta beccando anche il simulation index!
        # Mi serve una funziona che mi metta la lista della roba da leggere
        for section in self.__section_formats[self.simulation_type].keys():
            DEBUG_MSG("Field %s\n" % section)
            tablename = self.__mysql_names[self.simulation_type][section][0]
            fields = self.__mysql_names[self.simulation_type][section][1]
            # Get the list of fields to retrieve
            fmt = fields[0]
            for field in fields[1:]:
                fmt += ", `%s`" % field
            command = "SELECT %s FROM `%s` WHERE id_simulation = %d"
            instruction = command % (fmt, tablename, simindex)
            num = cursor.execute(instruction)
            DEBUG_MSG("Instruction used: %s\n" % instruction)
            # Is there any data?
            if num == 0:
                continue
            # Create the structure where i'll put it
            self.__sections_data[section] = []
            DEBUG_MSG("Section '%s' created\n" % section)
            # Now fill it
            for line in cursor.fetchall():
                self.__sections_data[section].append(line)

    def read_from_db(self, simindex, host = None, user = None, password = None, db = None):
        """Read the content of a LAMMPS simulation from a database

        returns True on error, False on success"""
        if not DB_INTERFACE:
            WARNING("Database interface not present")
            return True

        if self.__full:
            WARNING("Data already in the instance")
            return True

        if simindex == None:
            ERR("A simulation index must be specified!", 1)
        
        # TODO/FIXME: codice un po' schifoso...
        try:
            connection, cursor = self.__connect(host, user, password, db)
        except MySQLdb.Error, error:
            ERR("Error %d: %s\n" % (error.args[0], error.args[1]))
            try:
                connection.close()
            except Exception:
                pass
            return True

        try:
            # Read all the tables from the DB
            self._read_db_tables(cursor, simindex)
        except MySQLdb.Error, error:
            ERR("Error %d: %s\n" % (error.args[0], error.args[1]))
            try:
                connection.close()
            except Exception:
                pass
            self.flush_data()
            return True
        # Re-create the header from the information gathered
        try:
            self.__rebuild_header()
        except KeyError, err:
            self.flush_data
            cursor.close()
            connection.close()
            
        # The db connection is not needed anymore
        try:
            cursor.close()
            connection.close()
        except Exception:
            pass
        
        # Verify that all the numbers between header and section match
        try:
            self._verify_values()
        except RuntimeError, error:
            ERR(error)
            self.flush_data()
            return True
        
        self.__full = True
        return False

    def flush_db(self, simindex, host = None, user = None, password = None, db = None):
        """Clear all tables from the database.

        True on error, False on success"""
        try:
            connection, cursor = self.__connect(host, user, password, db)
        except MySQLdb.Error, error:
            ERR("Error %d: %s\n" % (error.args[0], error.args[1]))
            try:
                connection.close()
            except Exception:
                pass
            return True
        cursor.execute("START TRANSACTION")
        self._flush_database(cursor, simindex)
        cursor.execute("COMMIT")
        
        cursor.close()
        connection.close()

        return False

#########################################################
#          DATA REDUCTION FUNCTIONS                     #
#########################################################

    def __get_types(self, table, table_name):
        """Return the number of different entries in the 2th column of the table"""
        types = {}
        for line in table:
            types[line[1]] = True

        if max(types) != len(types):
            WARNING("the number of types is different from the maximum type (%s)" % table_name)
            
        return len(types)
    
    def __rebuild_header(self):
        """Build the LAMMPS data header from the sections"""
        self.__headerdata["number"]["atoms"] = self.__headerdata["types"]["atom"] = 0
        self.__headerdata["number"]["bonds"] = self.__headerdata["types"]["bond"] = 0
        self.__headerdata["number"]["angles"] = self.__headerdata["types"]["angle"] = 0
        self.__headerdata["number"]["dihedrals"] = self.__headerdata["types"]["dihedral"] = 0
        self.__headerdata["number"]["impropers"] = self.__headerdata["types"]["improper"] = 0
        # Atoms and Masses should always be present
        self.__headerdata["number"]["atoms"]      = len(self.__sections_data["Atoms"])
        self.__headerdata["types"]["atom"] = len(self.__sections_data["Masses"])
        
        # Check if the other values are present too
        if self.__sections_data.has_key("Bonds"):
            self.__headerdata["number"]["bonds"] = len(self.__sections_data["Bonds"])
            self.__headerdata["types"]["bond"] = self.__get_types(self.__sections_data["Bonds"], "Bonds")
            
        if self.__sections_data.has_key("Angles"):
            self.__headerdata["number"]["angles"] = len(self.__sections_data["Angles"])
            self.__headerdata["types"]["angle"] = self.__get_types(self.__sections_data["Angles"], "Angles")
            
        if self.__sections_data.has_key("Dihedrals"):
            self.__headerdata["number"]["dihedrals"] = len(self.__sections_data["Dihedrals"])
            self.__headerdata["types"]["dihedral"] = self.__get_types(self.__sections_data["Dihedrals"], "Dihedrals")
            
        if self.__sections_data.has_key("Impropers"):
            self.__headerdata["number"]["impropers"] = len(self.__sections_data["Impropers"])
            self.__headerdata["types"]["improper"] = self.__get_types(self.__sections_data["Impropers"], "Impropers")
            
    def _adjust_indexes(self, master_table_name, index, secondary_tables_names):
        """Adjust the indexes in the master table (column 'index') so that they become consecutive

        master_table_name: the name of the table where the relevant indexes are defined
        index       : the column of the master_table where they reside
        secondary_tables_names: a tuple of tuples where the first element of each item
                                is the name of a table, and the second, the index of it
                                that needs adjustment"""

        if not self.__sections_data.has_key(master_table_name):
            return

        conversion = {}
        # Get the angle types:
        types = [ i[index] for i in self.__sections_data[master_table_name]]
        types.sort()
        # Create the mapping
        idx = 1
        for i in range(len(types)):
            if conversion.has_key(types[i]):
                continue
            conversion[types[i]] = idx
            idx += 1

        # Rescale the master_table
        for line_num in range(len(self.__sections_data[master_table_name])):
            line = list(self.__sections_data[master_table_name][line_num])
            line[index] = conversion[line[index]]
            self.__sections_data[master_table_name][line_num] = tuple(line)
            
        # Rescale all other tables
        for table_name, column in secondary_tables_names:
            if not self.__sections_data.has_key(table_name):
                continue
            for line_num in range(len(self.__sections_data[table_name])):
                line = list(self.__sections_data[table_name][line_num])
                line[column] = conversion[line[column]]
                self.__sections_data[table_name][line_num] = tuple(line)

    def _rescale_indexes(self):
        """Adjust all indexes in the tables in order for LAMMPS to like them

        This involves essentially changing the types and coeffs"""
        # Indexes. Not strictly required by LAMMPS, but auspicable
        self._adjust_indexes("Atoms", 0, (("Velocities", 0),
                                          ("Bonds", 2), ("Bonds", 3),
                                          ("Angles", 2), ("Angles", 3), ("Angles", 4),
                                          ("Dihedrals", 2), ("Dihedrals", 3), ("Dihedrals", 4), ("Dihedrals", 5),
                                          ("Impropers", 2), ("Impropers", 3), ("Impropers", 4), ("Impropers", 5)))
        self._adjust_indexes("Bonds", 0, ())
        self._adjust_indexes("Angles", 0, ())
        self._adjust_indexes("Dihedrals", 0, ())
        self._adjust_indexes("Impropers", 0, ())
        
        # Types: must be in order
        self._adjust_indexes("Atoms", 2,
                             (("Masses", 0), ("Shapes", 0), ("Dipoles", 0), ("Pair Coeffs", 0)))
        self._adjust_indexes("Angles", 1,
                             (("Angle Coeffs", 0), ("BondBond Coeffs", 0), ("BondAngle Coeffs", 0)))
        self._adjust_indexes("Bonds", 1,
                             (("Bond Coeffs", 0),))
        self._adjust_indexes("Dihedrals", 1,
                             (("Dihedral Coeffs", 0), ("MiddleBondTorsion Coeffs", 0),
                              ("EndBondTorsion Coeffs", 0), ("AngleTorsion Coeffs", 0),
                              ("AngleAngleTorsion Coeffs", 0), ("BondBond13 Coeffs", 0)))
        self._adjust_indexes("Impropers", 1, (("Improper Coeffs",0), ("AngleAngle Coeffs", 0)))

    def __purge_type(self, type_table, type_column, tables):
        """Remove all the types not present in the reference table

        type_table: the reference table: the type column contains the type to keep
        tables:     the linked tables to purge"""
        
        # Get the atom types: if the table doesn't exist there's no point continuing
        if not self.__sections_data.has_key(type_table):
            return 
            
        types = dict([(i[type_column], True) for i in self.__sections_data[type_table]])
        ntypes = len(types)

        # Remove the missing types from all the relevant sections
        for section in tables:
            if not self.__sections_data.has_key(section):
                continue
            DEBUG_MSG("Clearing %s\n" % section)
            # delete the types that aren't present anymore
            for i in range(len(self.__sections_data[section]) - 1, -1, -1):
                if not types.has_key(self.__sections_data[section][i][0]):
                    del(self.__sections_data[section][i])
                
    def __purge_atoms(self, purged):
        """Remove the atoms from the data.

        This could be done in SQL code though...

        Indexes are not adjusted!"""

        # Remove it from "Atoms" and "Velocities". FIXME: does the job. Horrible code though...
        for section in ("Atoms", "Velocities"):
            if not self.__sections_data.has_key(section):
                continue
            DEBUG_MSG("Clearing %s\n" % section)
            vals = [ i for i in self.__sections_data[section] if purged.has_key(i[0])]
            for i in vals:
                index = self.__sections_data[section].index(i)
                del(self.__sections_data[section][index])


        # Remove the unused atom types
        self.__purge_type("Atoms", 2,("Masses", "Shapes", "Dipoles", "Pair Coeffs"))

                            
        # Remove the atoms from the remaining tables: they share the same characteristics
        for section in ("Bonds", "Angles", "Dihedrals", "Impropers"):
            if not self.__sections_data.has_key(section):
                continue
            DEBUG_MSG("Clearing %s\n" % section)
            vals = []
            # Get all lines containing an atom to remove
            for line in self.__sections_data[section]:
                if len([ i for i in line[2:] if purged.has_key(i)]) != 0:
                    vals.append(line)
                    continue
            # Remove the lines
            for line in vals:
                index = self.__sections_data[section].index(line)
                del(self.__sections_data[section][index])

        # Remove the missing Bonds types
        self.__purge_type("Bonds", 1,
                          ("Bond Coeffs",))

        # Remove the missing Agles types 
        self.__purge_type("Angles", 1,
                          ("Angle Coeffs", "BondBond Coeffs", "BondAngle Coeffs"))
        # Remove the missing Dihedrals types 
        self.__purge_type("Dihedrals", 1,
                          ("Dihedral Coeffs", "MiddleBondTorsion Coeffs", "EndBondTorsion Coeffs", "AngleTorsion Coeffs", "AngleAngleTorsion Coeffs", "BondBond13 Coeffs"))
        # Remove the missing Improper types 
        self.__purge_type("Impropers", 1,
                          ("AngleAngle Coeffs", "Improper Coeffs"))

        empty_sections =[ section for section,data in self.__sections_data.iteritems() if len(data) == 0 ]
        for section in empty_sections:
            del(self.__sections_data[section])


    def __get_selected_atoms(self, expression):
        """Obtain the list of atoms selected"""
        import array
    
        # See if we do have the library available
        if not PICKATOMS:
            ERR("The pickatoms module is not available", 1)
        
        # Data not loaded
        if not self.__full:
            WARNING("No data to reduce")
            return None
        
        # Get the list of types with the proper order (which means:
        # rescale everything from a [1,N] to a [0,N[ sequence
        N = max([t[0] for t in self.__sections_data["Atoms"]])
        type_vect = array.array("i",[-1] * (N + 1))
        for atom in range(len(self.__sections_data["Atoms"])):
            type_vect[self.__sections_data["Atoms"][atom][0]] = self.__sections_data["Atoms"][atom][2]

        # This is the result, however it should be rescaled by 1
        tmp = pickatoms.parse_expression(type_vect, expression)

        picked_atoms = []
        for i in range(1, N + 1):
            if tmp[i] != -1:
                picked_atoms.append(i)
        return picked_atoms

    def select_atoms(self, expression):
        """Reduce the atoms to a subset by using the pickatoms module (a hybrid SWIG/C interface in the parser directory of the MS2 distribution)

        expression is a string accepted by the parser, like:

        (1-3) OR TYPE 2
        1,2,5,10-20

        etc. See the documentation in the parser directory for more info.

        Returns True on error, False on success"""
        
        picked_atoms = self.__get_selected_atoms(expression)
        if picked_atoms == None:
            return True
        if len(picked_atoms) == 0:
            ERR("The subset should contain at least 1 atom", 1)
        return self.reduce_data(picked_atoms)

    def print_selected(self, expression):
        """Print the list of atoms selected by the pickatoms module (a hybrid SWIG/C interface in the parser directory of the MS2 distribution)

        expression is a string accepted by the parser, like:

        (1-3) OR TYPE 2
        1,2,5,10-20

        etc. See the documentation in the parser directory for more info.

        Returns True on error, False on success"""
        
        picked_atoms = self.__get_selected_atoms(expression)
        if picked_atoms == None:
            return True
        print "SELECTED:",
        for atom in picked_atoms:
            print "%d" % atom,
        print 
        return False
    
    def reduce_data(self, atoms_subset):
        """Placeholder. Reduce the data to a subset of the atoms

        atoms_subset is a tuple or list of atoms that will be included
        in the simulation (other atoms will be removed)

        Returns True on error, False on success"""
        if not self.__full:
            WARNING("Cannot reduce the data: no data present")
            return True

        atoms_present = [ (i[0],True) for i in self.__sections_data["Atoms"]]
        # Build the list of atoms that will be removed
        atoms_removed = dict(atoms_present)
        for i in atoms_subset:
            try:
                del(atoms_removed[i])
            except ValueError, err:
                ERR("There is no %d atom" % i)
                return True
            
        # For each atom in the list, remove every reference
        self.__purge_atoms(atoms_removed)
        
        # Rescale indexes so that the types are consecutive
        self._rescale_indexes()

        # Re-adjust headers
        self.__rebuild_header()
        
    # FIXME: aggiungi il match delle masse
    def dump_xyzfile(self, filename):
        """Write the data to a file with XYZ format.

        Return True on error, False on success."""

        # Data not loaded
        if not self.__full:
            WARNING("No data to save")
            return True

        try:
            f = file(filename, "w")
        except IOError, err:
            ERR("IOError opening file %s (%s)" % (filename, err))
            return True

        try:
            # Size e Atom
            f.write("%d\nAtoms\n" % len(self.__sections_data["Atoms"]))
            # All atoms
            for atom in self.__sections_data["Atoms"]:
                f.write("%d %g %g %g\n" % (atom[2], atom[4], atom[5], atom[6]))
            f.close()
        except IOError, err:
            ERR("IOError writing on file %s (%s)" % (filename, err))
            return True

        return False

def parse_options():
    """Parse the command line options and execute the specified actions.

    Exits with 1 on error and with 0 on success."""

    if PICKATOMS:
        pickatoms = "available"
    else:
        pickatoms = "not available"

    if DB_INTERFACE:
        mysql = "available"
    else:
        mysql = "not available"
    

    help_string = """%s [options/actions]

The actions take place in the order in which they are encountered
(multiple actions of the same type are allowed, the only limit being
the maximum line length allowed by the shell active).

Options and flags become active from the point where they are
specified and remain such until overridden by another flag of the same
type (--type being the only exception, see below for more info.).

Options can be cleared by just specifying them with an empty string
(like '').

Some options may not be available if the MySQLdb or pickatoms modules
are not correctly installed: the detected modules are shown at the
bottom of this help screen.

*** Options (become active in the order they are declared)

    --type     (alanine|peptide)  the kind of data file used: affects the
                                  format of the data accepted by the script
                                  This is the only option that takes effect
                                  regardless of the point in which it is
                                  specified (default: alanine)

    --db_host       address       host where the database is
    
    --db_user       user          user to access the database
    
    --db_passwd     password      password to access the database (don't
                                 use this option unless you know what you
                                 are doing: the password can be read by
                                 other users!)
                                 
    --db_passwd_env envvar        read the password for the database
                                 from the environment variable 'envvar'
                                 (overwrites the value in db_passwd)
                                 
    --db_database   db           name of the database to access

    --db_simulation index        index of the simulation to use
    
    --ignore_errors              don't exit on error
    
    --exit_on_error              return on error with code 1 (default)

    --verbose                    print the commands being executed

    --brief                      don't print the command being executed (default)


*** Actions (executed in the order they are found):

    --URL            url        read data from URL
    
    --input          filename   read data from file
    
    --db_input                  read data  from a database

    --flush                     clear the data from the instance
    
    --flush_db                  remove all the data from the database
                                [DANGEROUS: USE IT ONLY FOR TESTING!!!]   
    
    --reduce_list    atom_list  select only the atoms in the list (a list is
                                a comma separated enumeration of atoms)
                                
    --select_atoms   expression select only the atoms which match the
                                expression (see the documentation in 
                                the ms2/parser directory). Required the
                                pickatoms module

    --print_selected expression print the indexes of the atoms which match
                                the expression (see the documentation
                                in the ms2/parser directory)

    --output         filename   write the data to file
    
    --db_output                 write the data to a DB

    --xyz            filename   write the data to a file in XYZ format        

    --help                      print this message and exit


The pickatoms module is %s
The interface to MySQL is %s
""" % (sys.argv[0], pickatoms, mysql)

    options = {
        "db_host=": None, "db_user=": None,
        "db_passwd=": None, "db_passwd_env=": None,
        "db_database=" :None, "db_simulation=": None,
        }
    
    flags = {
        "ignore_errors": False, "exit_on_error": True,
        "brief": True, "verbose": False,
        }

    actions = {
        "URL=": None, "input=": None, "db_input": None,
        "flush": None, "flush_db": None,
        "reduce_list=": None, "select_atoms=": None,
        "output=": None, "db_output": None, "print_selected=": None,
        "xyz=": None,
        "help": None
        }

    simulation_type  = None

    try:
        events, extra_arguments = getopt.getopt(sys.argv[1:],"", options.keys() + actions.keys() + flags.keys() + ["type="])
    except getopt.GetoptError, error:
        ERR(error, 1)

    # Extra arguments are forbidden
    if len(extra_arguments):
        ERR("Extra arguments are not allowed %s" % (tuple(extra_arguments),), 1)

    # No options => help. Don't check for no actions. If the user is
    # so dumb he wants to use this code as bulky replacement for
    # "sleep", that's his/her business...
    if len(events) == 0:
        print help_string
        raise SystemExit, 0

    # Check if help was specified
    try:
        events.index(("--help",''))
        print help_string
        raise SystemExit, 0        
    except ValueError:
        pass

    # Check if the type was specified
    d = dict(events)
    if d.has_key("--type"):
        if TYPES.has_key(d["--type"]):
            MSG("Type set to '%s'" % d["--type"])
            simulation_type = TYPES[d["--type"]]
        else:
            ERR("The type selected is invalid", 1)
    else:
        MSG("Type set to the default value (%s)" % TYPES.keys()[0])
        simulation_type = TYPES[TYPES.keys()[0]]

    # Create a LAMMPS data parser
    instance = LAMMPSData(simulation_type = simulation_type)

    # Start doing things
    for option, value in events:
        # If we got an option, just change it
        if options.has_key(option[2:] + "="):
            if value != "":
                options[option[2:] + "="] = value
            else:
                options[option[2:] + "="] = None
            # env deserves special treatment
            if option == "--db_passwd_env":
                options["db_passwd="] = os.getenv(value, None)
                if options["db_passwd="] == None:
                    ERR("The environment varible '%s' doesn't exist" % value, 1)
            if option == "--db_simulation":
                try:
                    options["db_simulation="] = int(value)
                except ValueError, error:
                    ERR("The simulation index should be an integer", 1)
            continue
                
        # Flags
        if option == "--ignore_errors":
            flags["ignore_errors"] = True
            flags["exit_on_error"] = False
            continue
            
        if option == "--exit_on_error":
            flags["ignore_errors"] = False
            flags["exit_on_error"] = True
            continue
        
        if option == "--brief":
            flags["brief"] = True
            flags["verbose"] = False
            continue

        if option == "--verbose":
            flags["brief"] = False
            flags["verbose"] = True
            continue

        # Everything else is a non-help action. Although it's a bit
        # confusing, this code does the same thing over and over
        # again...
        # Input from a URL
        if option == "--URL":
            if flags["verbose"]:
                MSG("executing %s" % option)
            try:
                if instance.parse_URL(value) \
                       and flags["exit_on_error"]:
                    raise SystemExit, 1
            except Exception,err:
                ERR(str(err), 1)
        # Input from a file
        elif option == "--input":
            if flags["verbose"]:
                MSG("executing %s" % option)
            try:
                if instance.parse_file(value) \
                       and flags["exit_on_error"]:
                    raise SystemExit, 1
            except RuntimeError,err:
                ERR(str(err), 1)
        # Input from a MySQL database
        elif option == "--db_input":
            if flags["verbose"]:
                MSG("executing %s" % option)
            try:
                if instance.read_from_db(options["db_simulation="],
                                         host = options["db_host="],
                                         user = options["db_user="],
                                         password = options["db_passwd="],
                                         db = options["db_database="])  \
                                         and flags["exit_on_error"]:
                    raise SystemExit, 1
            except Exception,err:
                ERR(str(err), 1)
        # Remove all data from the parser
        elif option == "--flush":
            if flags["verbose"]:
                MSG("executing %s" % option)
            try:
                if instance.flush_data() \
                       and flags["exit_on_error"]:
                    raise SystemExit, 1
            except Exception,err:
                ERR(str(err), 1)
        # Remove alla data from the current db
        elif option == "--flush_db":
            if flags["verbose"]:
                MSG("executing %s" % option)
            try:
                if instance.flush_db(options["db_simulation="],
                                     host = options["db_host="],
                                     user = options["db_user="],
                                     password = options["db_passwd="],
                                     db = options["db_database="]) \
                                     and flags["exit_on_error"]:
                    raise SystemExit, 1
            except Exception,err:
                ERR(str(err), 1)
        # Remove all atoms non in the list
        elif option == "--reduce_list":
            if flags["verbose"]:
                MSG("executing %s" % option)
            try:
                lista = [int(i) for i in value.split(",")]
            except ValueError, err:
                ERR("Unable to parse '%s'" % value, 1)
            try:
                if instance.reduce_data(lista) \
                       and flags["exit_on_error"]:
                    raise SystemExit, 1
            except Exception,err:
                ERR(str(err), 1)
        # Remove all atoms that doesn't match the expression
        elif option == "--select_atoms":
            if flags["verbose"]:
                MSG("executing %s" % option)
            try:
                if instance.select_atoms(value) \
                       and flags["exit_on_error"]:
                    raise SystemExit, 1
            except Exception,err:
                ERR(str(err), 1)
        # Print the atoms selected with the expression
        elif option == "--print_selected":
            if flags["verbose"]:
                MSG("executing %s" % option)
            try:
                if instance.print_selected(value) \
                       and flags["exit_on_error"]:
                    raise SystemExit, 1
            except Exception,err:
                ERR(str(err), 1)
                
        # Write to a file
        elif option == "--output":
            if flags["verbose"]:
                MSG("executing %s" % option)
            try:
                if instance.dump_data_file(value) \
                       and flags["exit_on_error"]:
                    raise SystemExit, 1
            except Exception,err:
                ERR(str(err), 1)
        # Write to a database
        elif option == "--db_output":
            if flags["verbose"]:
                MSG("executing %s" % option)
            try:
                if instance.commit_to_db(options["db_simulation="],
                                         host = options["db_host="],
                                         user = options["db_user="],
                                         password = options["db_passwd="],
                                         db = options["db_database="]) \
                                         and flags["exit_on_error"]:
                    raise SystemExit, 1
            except Exception,err:
                ERR(str(err), 1)
        # Write to an XYZ file
        elif option == "--xyz":
            if flags["verbose"]:
                MSG("executing %s" % option)
            try:
                if instance.dump_xyzfile(value) \
                       and flags["exit_on_error"]:
                    raise SystemExit, 1
            except Exception,err:
                ERR(str(err), 1)        
    raise SystemExit, 0

if __name__ == "__main__":
    try:
        parse_options()
    except SystemExit, code:
        raise SystemExit, code
    except AssertionError, code:
        ERR("Assertion in the code failed. Contact the developer", 69)
    except Exception, code:
        ERR("Unhandled exception: '%s'\n" % code, 69)
