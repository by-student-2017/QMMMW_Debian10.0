//!
//! Copyright (C) 2011-2015 QMMMW group
//! This file is distributed under the terms of the
//! GNU General Public License version 3 (GNU-GPLv3).
//!
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <errno.h>
#include "../common/ms2_errors.h"
#include "../common/ms2_definitions.h"
#include "pickatoms.h"

extern FILE *yyin;
extern char *yyin_string;

extern range parsing_result;
extern range atoms;
extern int N;

extern int yyparse(void);


/** 
 * The yacc function used to print an error
 * 
 * @param str the error string
 */
void yyerror(char *str)
{
  fprintf(stderr, "Parsing ERROR: %s\n", str);
}

/** Initialize the parser with the vector passed from LAMMPS

    I can use the reference since I'm going to treat it read-ony
    anyway.
*/

/** 
 * Initialize the parser using an array obtained by LAMMPS (LAMMPS::NS::atoms->types)
 * 
 * @param Natoms The number of atoms in the array
 * @param types The array of types (treated as constant)
 */
void _init_parser(int Natoms, int *types)
{
  /// Set the total number of atoms
  N = Natoms;

  /// Set the reference
  atoms = types;
  
  {
    /**
     * Check if the higher type is less or equal than the number of atoms
     */
    int i, max = -1;
    for(i = 0; i < N; i++)
      max = max > types[i] ? max : types[i];
    assert(max < N);
  }
  parsing_result = NULL;
}

void _setInput(FILE *finput, const char *sinput)
{
  yyin = finput;
  yyin_string = sinput;
}

/** 
 * Read an espression from the descriptor, parse it, and return the list of selected atoms.
 * 
 * @param N the size of the lammps_type array
 * @param lammps_types an array of types similar to that obtained from LAMMPS (atoms->types)
 * @param input the descriptor from which the expression to be parsed is read
 * 
 * @return an array similar to lammps_type, where the cells containing
 * -1 are atoms to be discarded. NULL is returned on error
 */
int *_parse_file(int N, int *lammps_types, FILE *input)
{
  int res;

  MSG("initializing the parser...");
  _init_parser(N, lammps_types);

  yyin = input;
  yyin_string = NULL;

  MSG("parsing...");
  res = yyparse();

  if (res != 0) {
    ERR("parsing failed (%d)!\n", ERROR_PARSING);
    return NULL;
  }

  if(parsing_result == NULL) {
    ERR("No valid expression found (%d)!\n", ERROR_PARSING);
    return NULL;
  }

#ifdef DEBUG
  MSG("Parsing succeded (results in 'atoms_chosen.txt')\n");

  /**
   * This block is used to get a picture of the atoms chosen after
   * the expression is parsed
   */
  {
    int i;
    FILE *f = fopen("atoms_chosen.txt","w");
    for(i=0;i<N;i++)
      if(parsing_result[i] != -1)
	fprintf(f, "Atom %d, type %d\n", i, parsing_result[i]);
    fclose(f);
  }
#endif

  return parsing_result;
}

/** 
 * Conunts the number of atoms selected
 * 
 * @param N the number of elements in the result 
 * @param result the array of types
 * 
 * @return the number of elements which are not -1
 */
int _atoms_chosen(int N, range result)
{
  int M = 0;
  int i;
  for(i = 0;i < N; i++)
    M += result[i] != -1? 1: 0;
  return M;
}

/** 
 * Read a file with a valid parser expression and returns a integer
 * array with the range selected or NULL on error
 * 
 * @param N number of elements in the lammps_types array
 * @param lammps_types an array of N elements, each one containing the type of the atom in LAMMPS (usually a reference to the atoms->type array in the LAMMPS source)
 * @param M The number of atoms selected by the parser
 * @param filename the file where the expression to be feed to the parser is stored
 * 
 * @return an array of N integer, each one containing the original type value, if the atom is selected, or -1 if the atom at that position is discarder. NULL is returned on error.
 */
int *parse_file(int N, int *lammps_types, int *M, char *filename)
{
  FILE *f;
  range result;

  if(filename == NULL)
    filename = MS2_ATOM_SPEC;

  /// Open the file with the atom expression
  MSG("opening the atoms file...");
  f = fopen(filename, "r");
  if(f == NULL) {
    int err = errno;
    char s[80];
    snprintf(s, 80, "Cannot open '%s' (%d)", filename, ERROR_ATOM_FILE_NOT_OPENED);
    errno = err;
    perror(s);
    return NULL;
  }

  /// Parse the result 
  result = _parse_file(N, lammps_types, f);

  fclose(f);

  /// Count the number of atoms picked
  if(result != NULL)
    *M = _atoms_chosen(N, result);

  return result;
}



  
