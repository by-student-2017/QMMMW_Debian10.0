//!
//! Copyright (C) 2011-2015 QMMMW group
//! This file is distributed under the terms of the
//! GNU General Public License version 3 (GNU-GPLv3).
//!
#ifndef DRIVER_SEMANTIC_H
#define DRIVER_SEMANTIC_H

#ifdef __cplusplus
extern "C" {
#endif 

#include <stdio.h>

// Structures
typedef int* range;

// Needed by the parser
typedef union _semval {
  int *range;
  int   intval;
} semval;

//! The location where the result of the parsing will be returned
extern range parsing_result;

// Diseq. symbols
#define SEM_EQ 0     // = 
#define SEM_NE 1     // !=
#define SEM_LT 2     // <
#define SEM_LE 3     // <=
#define SEM_GT 4     // >
#define SEM_GE 5     // >=

//!
//! Range operations: needed by bison: each one is associated to one
//! or more operator
//!


//! range con tutti gli atomi
range range_universe(void);
//! range vuoto
range range_empty(void);
//! range1 OR range2
range range_union(range r1, range r2);
//! range1 AND range2
range range_intersection(range r1, range r2);
//! range1 XOR range2
range range_xor(range r1, range r2);
//! range1 meno gli elementi di range2
range range_diff(range r1, range r2);
//! NOT range
range range_neg(range r);
//! Nuovo range costituito da un punto
range range_single(int value);
//! Nuovo range che va da start a stop
range range_new(int start, int stop);
//! Sceglie solo il tipo specificato (1 int)
range range_type(int type);
//! Sceglie tutti i range di tutti gli atomi nella lista
range range_type_from_range(range r);
//! Scegli i tipi con una disequazione
range range_type_diseq(int value, int diseq_type);
//! Scegli gli atomi con una disequazione
range range_diseq(int value, int diseq_type);

#ifdef __cplusplus
}
#endif 

#endif
