//!
//! Copyright (C) 2011-2015 QMMMW group
//! This file is distributed under the terms of the
//! GNU General Public License version 3 (GNU-GPLv3).
//!
#include "driver_semantic.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>

extern FILE *yyin;
extern char *yyin_string;

range parsing_result;
range atoms = NULL;
int N;

range range_type(int atom_type)
{
  int i;
  range r=range_universe();
  for(i = 0; i < N; i++)
    r[i] = atoms[i] == atom_type ? atoms[i] : -1;
  return r;
}

range range_type_diseq(int value, int diseq_type)
{
  int i;
  range r;
  r = range_empty();
  switch(diseq_type) {
  case SEM_EQ:
    for(i = 0; i < N; i++)
      if(atoms[i] == value)
	r[i] = atoms[i];
    break;
  case SEM_NE:
    for(i = 0; i < N; i++)
      if(atoms[i] != value)
	r[i] = atoms[i];
    break;
  case SEM_LT:
    for(i = 0; i < N; i++)
      if(atoms[i] < value)
	r[i] = atoms[i];
    break;
  case SEM_LE:
    for(i = 0; i < N; i++)
      if(atoms[i] <= value)
	r[i] = atoms[i];
    break;
  case SEM_GT:
    for(i = 0; i < N; i++)
      if(atoms[i] > value)
	r[i] = atoms[i];
    break;
  case SEM_GE:
    for(i = 0; i < N; i++)
      if(atoms[i] >= value)
	r[i] = atoms[i];
    break;
  }
  return r;
}

range range_diseq(int value, int diseq_type)
{
  int i;
  range r;
  r = range_empty();
  switch(diseq_type) {
  case SEM_EQ:
    for(i = 0; i < N; i++)
      if(i == value)
	r[i] = atoms[i];
    break;
  case SEM_NE:
    for(i = 0; i < N; i++)
      if(i != value)
	r[i] = atoms[i];
    break;
  case SEM_LT:
    for(i = 0; i < N; i++)
      if(i < value)
	r[i] = atoms[i];
    break;
  case SEM_LE:
    for(i = 0; i < N; i++)
      if(i <= value)
	r[i] = atoms[i];
    break;
  case SEM_GT:
    for(i = 0; i < N; i++)
      if(i > value)
	r[i] = atoms[i];
    break;
  case SEM_GE:
    for(i = 0; i < N; i++)
      if(i >= value)
	r[i] = atoms[i];
    break;
  }
  return r;
}

range range_universe(void)
{
  range r = malloc(N * sizeof(int));
  if(r == NULL) {
    perror("Universe not created");
    exit(errno);
  }
  memcpy(r, atoms, sizeof(int) * N);
  return r;
}

range range_empty(void)
{
  range r = malloc(N * sizeof(int));
  if(r == NULL) {
    perror("Universe not created");
    exit(errno);
  }
  memset(r, -1 , sizeof(int) * N);
  return r;
}


range range_union(range a, range b)
{
  int i;
  for(i = 0; i < N; i++)
    a[i] = a[i] > b[i] ? a[i] : b[i];

  free(b);
  b = NULL;

  return a;
}

range range_intersection(range a, range b)
{
  int i;
  for(i = 0; i < N; i++)
    a[i] = a[i] > b[i] ? b[i] : a[i];

  free(b);
  b = NULL;

  return a;

}

range range_xor(range a, range b)
{
  int i;
  for(i = 0; i < N; i++)
    a[i] = a[i] == b[i]? -1: atoms[i];

  free(b);
  b = NULL;

  return a;
}

range range_diff(range a, range b)
{
  int i;
  for(i = 0; i < N; i++)
    a[i] = b[i] != -1 ?-1 :a[i];
    
  free(b);
  b = NULL;

  return a;
}


range range_neg(range a)
{
  int i;
  for(i = 0; i < N; i++)
    a[i] = a[i] == -1 ? atoms[i] : -1;

  return a;
}

range range_single(int value)
{
  range r;
  r = range_universe();
  if(!((value < 0) || (value >=N)))
    r[value] = -1;
  // Turn it before negating
  return range_neg(r);
}


range range_new(int a, int b)
{
  range r;
  int start, stop;

  // If start or stop are out of bounds, reset them
  start = a < 0 ? 0 : a;
  stop  = b > N - 1 ? N -1 : b;

  // If start is greater than stop, return an empty range
  if(start > stop)
    return range_single(-1);

  // If start is equal to range, return a single element range
  if(start == stop)
    return range_single(start);

  // Otherwise, create a new one
  r = range_universe();
  memset(&r[start], -1, (stop - start + 1) * sizeof(int));
 
  return range_neg(r);
}
void print_range(range r)
{
  int i;
  for(i=0;i<N;i++)
    if(r[i] != -1)
      printf("%d   type %d\n", i, r[i]);
    else
      printf("%d     X\n", i);

}

range range_type_from_range(range r)
{
  range out;
  int i,j;
  out = range_empty();
  for(i=0;i<N;i++)
    if(r[i] != -1)
      for(j=0;j<N;j++)
	if(atoms[j] == r[i])
	  out[j] = atoms[j];

  free(r);
  r = NULL;

  return out;
 
}



//! Used by old_init_parser to deallocate the memory
void finalize(void)
{
  free(atoms);
  atoms = NULL;
}

  
