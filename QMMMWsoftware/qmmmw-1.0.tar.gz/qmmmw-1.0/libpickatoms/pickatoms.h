//!
//! Copyright (C) 2011-2015 QMMMW group
//! This file is distributed under the terms of the
//! GNU General Public License version 3 (GNU-GPLv3).
//!
#ifndef PARSER_H
#define PARSER_H

#ifdef __cplusplus
extern "C" {
#endif 

#include <stdio.h>
#include "driver_semantic.h"


//! parse the qe_atoms.txt file and return an array with the mask to apply
//! N and lammps_types are, respectively, natoms and atoms->types, will be 
//! filled with the number of chosen atoms

  /** 
   * Read a file with a valid parser expression and returns a integer
   * array with the range selected or NULL on error
   * 
   * @param N number of elements in the lammps_types array
   * @param lammps_types an array of N elements, each one containing the type of the atom in LAMMPS (usually a reference to the atoms->type array in the LAMMPS source)
   * @param M The number of atoms selected by the parser
   * @param filename the file where the expression to be feed to the parser is stored
   * 
   * @return an array of N integer, each one containing the original type value, if the atom is selected, or -1 if the atom at that position is discarder. NULL is returned on error.
   */
  int *parse_file(int N, int *lammps_types, int *M, char *filename);

  /** 
   * Print a range. Used for debugging purpose only
   * 
   * @param r The range to print
   */
  void print_range(range r);

  
#ifdef __cplusplus
}
#endif 

#endif
