"""Copyright (C) 2011-2015 QMMMW group
   This file is distributed under the terms of the
   GNU General Public License version 3 (GNU-GPLv3)."""
# Created by Riccardo Di Meo for SISSA
"""Pickatoms module created to replace the swig module with the same purpose"""

import ctypes
import sys
import array

# Load the pickatoms library
lib = ctypes.cdll.LoadLibrary("libpickatoms.so")

# I guess libc will be installed in this system, will it?
# NOTE: in 2050 the version of libc is likely gonna change, and this
# code will require some modifications
try:
    libc = ctypes.cdll.LoadLibrary("libc.so.6")
except OSError, error:
    sys.stderr.write("Unable to load the libc.so.6 library, which is required for this tool to work\n")
    raise SystemExit, 1

# Set the correct output arguments for the types we need
# lib.parse_file.restype = ctypes.c_void_p
# lib.parse_file.argtype = [ctypes.c_int, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p]
lib._parse_file.restype  = ctypes.c_void_p
lib._parse_file.argtype  = [ctypes.c_int, ctypes.c_void_p, ctypes.c_void_p]
lib._init_parser.restype = None
lib._init_parser.argtype = [ctypes.c_int, ctypes.c_void_p]
lib.yyparse.restype = ctypes.c_int
lib.yyparse.argtype = None
lib._setInput.restype = None
lib._setInput.argtype = [ctypes.c_void_p, ctypes.c_void_p]

# And for our helper functions
libc.fopen.restype  = ctypes.c_void_p
libc.fopen.argtype  = [ctypes.c_char, ctypes.c_char]
libc.fclose.restype = None
libc.fclose.argtype = [ctypes.c_void_p]
libc.free.restype = None
libc.free.argtype = [ctypes.c_void_p]

def parse_expression(lammps_array, expression):
    """Parse a libpickatoms expression.

    lammps_array: an array of type 'i' with the list of types, as passed by lammps (index start from 0)
    expression:   the expression to be parsed"""
    # convert the input into a C array
    cinput = ctypes.create_string_buffer(lammps_array.tostring())
    
    # Get the length 
    length = ctypes.c_int(len(lammps_array))

    # Initiaize the parser
    lib._init_parser(length, cinput)

    # Set the value of yyin_string and yyin to make the parser read the expression
    lib._setInput(ctypes.c_void_p(0),
                  ctypes.pointer(ctypes.create_string_buffer(expression)))
    
    # Parse the data
    res = lib.yyparse()

    if(res != 0):
        raise RuntimeError, "Parsing failed"
        return None

    presult = ctypes.c_void_p.in_dll(lib, "parsing_result")

    if presult == 0:
        raise RuntimeError, "The espression feed to the parser was invalid"
        return None

    # Convert the output into a python array
    output = array.array("i", ctypes.string_at(presult,
                                               lammps_array.itemsize * len(lammps_array)))
    return output

def parse_file(lammps_array, filename):
    """Parse the content of a file.

    lammps_array: an array of type 'i' with the lammps type for each atom (indexes start from 0)
    filename:     the name of a file containing the expression to be parsed

    This function is actually here as a bonus: it's not used by the portal or lammps_tools
    """
    # c_int length of the array
    N = ctypes.c_int(len(lammps_array))
    # get the file pointer
    filep = libc.fopen(filename, "r")
    # convert the input into an array
    tmp0 = array.array("i", lammps_array)
    tmp = tmp0.tostring()
    cbuffer = ctypes.create_string_buffer(tmp)
    # call functions
    coutput = lib._parse_file(N, cbuffer, filep)
    # Close the file
    libc.fclose(filep)
    # Convert the output into a python array
    output = array.array("i", ctypes.string_at(coutput,
                                               tmp0.itemsize * len(lammps_array)))
    libc.free(coutput)
    return output

if __name__ == "__main__":
    print "...Testing the module:"
    lammps_array = array.array("i",[1,1,2,3,4,4,5,5])
    print "Result obtained: ", parse_expression(lammps_array, "0-2,5,7")
    print "Ok (no errors)!"
