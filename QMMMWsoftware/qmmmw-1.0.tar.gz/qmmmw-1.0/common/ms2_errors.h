//!
//! Copyright (C) 2011-2015 QMMMW group
//! This file is distributed under the terms of the
//! GNU General Public License version 3 (GNU-GPLv3).
//!
#ifndef MS2_ERRORS_H
#define MS2_ERRORS_H
//! This file contains the error codes used by our implementation to
//! signal a problem.
//!
//! To distinguish them from the standard error, they will all start
//! from 32

//!
//! Exit codes for the driver
//! 
//! A configuration file could not be read by the user
#define DRIVER_INVALID_FILE 16
//! The size of the LAMMPS slave sistem != the atoms selected by the user
#define DRIVER_SIZE_MISMATCH 17
//! Unable to allocate memory for the exchange vectors
#define DRIVER_MEMORY_NOT_ALLOCATED 18
//! Unable to initialize the MPI support
#define DRIVER_MPI_INIT_FAILED 19

//!
//! Exit codes for the parsing library
//!

//! file with the atom list not found
#define ERROR_ATOM_FILE_NOT_OPENED 31
//! input file not parsed correctly
#define ERROR_PARSING 32

//!
//! Exit codes for the shmem library
//!

//! The environment variable wasn't found
#define NO_ENV_VAR 64
//! shared memory not initialized
#define SHM_INIT_FAILED 66
//! the name of the shmem handler contains a "/"
#define SHM_MALFORMED_ENV_CONTENT 67
//! unable to open the stream for the errors
#define SHM_LOG_ERROR 68
//! The number of QE atoms differs for LAMMPS master and slave
#define SHM_ATOMS_NUM_DIFFERS 69
// One of the processes didn't found shm handler
#define SHM_TIMEOUT_EXPIRED 70
// Error waiting for a semaphore
#define SHM_SEM_WAIT_FAILED 71
// One or more processes are dead while we where waiting for it
#define SHM_WAITING_A_DEAD_PROCESS 72

#endif
