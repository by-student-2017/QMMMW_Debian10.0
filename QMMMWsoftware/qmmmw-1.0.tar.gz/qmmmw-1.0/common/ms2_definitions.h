//!
//! Copyright (C) 2011-2015 QMMMW group
//! This file is distributed under the terms of the
//! GNU General Public License version 3 (GNU-GPLv3).
//!
#ifndef MS2_DEFINITIONS_H
#define MS2_DEFINITIONS_H
//! File with various definitions required for the MS2 interfaces
//! It's a sort of "config file"

// Relevant for the parser
#ifndef MS2_ATOM_SPEC
#define MS2_ATOM_SPEC "qe_atoms.txt"
#endif

#define MS2_MASTER_LOG "master.log"
#define MS2_SLAVE_LOG  "slave.log"

//! Constants relevant for the shared memory module
#ifndef SHM_ENV_VAR
#define SHM_ENV_VAR "SHM_NAME"
#endif

//! The environment variable holding the logfile for shm operations
#ifndef SHM_ENV_VAR_LOG
#define SHM_ENV_VAR_LOG "SHM_LOGS"
#endif

//! Maximum length for the shared memory name
#define SHM_MAXSHNAME 10
//! How long (in seconds) a slave will wait for a shm descriptor to appear
#define SHM_TIMEOUT 60
//! This defines the period of wait on every sem_wait: the bigger it
//! is, the more time will pass before a process aknowledge a peer's
//! death, but also the smaller the overhead on waits
//! Keep it above a couple of seconds
#define SHM_CHECK_PERIOD 5

#define ERR(format, ...) fprintf(stderr, "* ERROR:  "format"\n", ##__VA_ARGS__)
#define VERR(string)     fprintf(stderr, "* ERROR:  %s\n", string)
#define MSG(format, ...) fprintf(stderr, "* MSG  :  "format"\n", ##__VA_ARGS__)
#define VMSG(string)     fprintf(stderr, "* MSG  :  %s\n", string)

//! Constants needed for the value conversion
//! Kcal in jaul
#define KCAL_J 4184
//! Avogadro constant
#define MOL    6.0221415e23
//! Force, espresso-style in Newtons
#define QE_FORCE_N 4.1193647e-8
//! Force, LAMMPS style (when using "real" units), in Newton
#define LAMMPS_FORCE_N 6.9476946033234188e-11
//! Factor the QE forces should be multiplied for, in order to get the LAMMPS "real" units Forces
#define LAMMPS_QE (QE_FORCE_N/LAMMPS_FORCE_N)



#endif
