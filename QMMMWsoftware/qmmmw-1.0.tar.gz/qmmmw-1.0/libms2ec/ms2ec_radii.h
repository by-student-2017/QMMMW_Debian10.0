//!
//! Copyright (C) 2011-2015 QMMMW group
//! This file is distributed under the terms of the
//! GNU General Public License version 3 (GNU-GPLv3).
//!
#ifndef MS2EC_RADII_H
#define MS2EC_RADII_H
/** 

    Atomic radii for the various elements in picometers.

    A value of -1 has the meaning of "data not available".

    Source: wikipedia 
    [ http://en.wikipedia.org/wiki/Atomic_radii_of_the_elements_(data_page) ]

    All values have been converted, just in case...
*/

/// Number of elements in the arrays
const int  ms2ec_elements              = 116;
/// The Z of the indexed element. Not required for this setup, might be handy for future implementations 
/// where the data will be read from a file
const int  ms2ec_Z[116]                = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116};
/// The symbol of the element
const char ms2ec_element[116][4]       = {"H", "He", "Li", "Be", "B", "C", "N", "O", "F", "Ne", "Na", "Mg", "Al", "Si", "P", "S", "Cl", "Ar", "K", "Ca", "Sc", "Ti", "V", "Cr", "Mn", "Fe", "Co", "Ni", "Cu", "Zn", "Ga", "Ge", "As", "Se", "Br", "Kr", "Rb", "Sr", "Y", "Zr", "Nb", "Mo", "Tc", "Ru", "Rh", "Pd", "Ag", "Cd", "In", "Sn", "Sb", "Te", "I", "Xe", "Cs", "Ba", "La", "Ce", "Pr", "Nd", "Pm", "Sm", "Eu", "Gd", "Tb", "Dy", "Ho", "Er", "Tm", "Yb", "Lu", "Hf", "Ta", "W", "Re", "Os", "Ir", "Pt", "Au", "Hg", "Tl", "Pb", "Bi", "Po", "At", "Rn", "Fr", "Ra", "Ac", "Th", "Pa", "U", "Np", "Pu", "Am", "Cm", "Bk", "Cf", "Es", "Fm", "Md", "No", "Lr", "Rf", "Db", "Sg", "Bh", "Hs", "Mt", "Ds", "Rg", "Cn", "Uut", "Uuq", "Uup", "Uuh"};
/// Name of the element
const char ms2ec_elname[116][15]       = {"hydrogen", "helium", "lithium", "beryllium", "boron", "carbon", "nitrogen", "oxygen", "fluorine", "neon", "sodium", "magnesium", "aluminium", "silicon", "phosphorus", "sulfur", "chlorine", "argon", "potassium", "calcium", "scandium", "titanium", "vanadium", "chromium", "manganese", "iron", "cobalt", "nickel", "copper", "zinc", "gallium", "germanium", "arsenic", "selenium", "bromine", "krypton", "rubidium", "strontium", "yttrium", "zirconium", "niobium", "molybdenum", "technetium", "ruthenium", "rhodium", "palladium", "silver", "cadmium", "indium", "tin", "antimony", "tellurium", "iodine", "xenon", "caesium", "barium", "lanthanum", "cerium", "praseodymium", "neodymium", "promethium", "samarium", "europium", "gadolinium", "terbium", "dysprosium", "holmium", "erbium", "thulium", "ytterbium", "lutetium", "hafnium", "tantalum", "tungsten", "rhenium", "osmium", "iridium", "platinum", "gold", "mercury", "thallium", "lead", "bismuth", "polonium", "astatine", "radon", "francium", "radium", "actinium", "thorium", "protactinium", "uranium", "neptunium", "plutonium", "americium", "curium", "berkelium", "californium", "einsteinium", "fermium", "mendelevium", "nobelium", "lawrencium", "rutherfordium", "dubnium", "seaborgium", "bohrium", "hassium", "meitnerium", "darmstadtium", "roentgenium", "copernicium", "ununtrium", "ununquadium", "ununpentium", "ununhexium"};
/// Atomic radius: empirical value
const int  ms2ec_r_empirical[116]      = {35, -1, 145, 105, 85, 70, 65, 60, 50, -1, 180, 150, 125, 110, 100, 100, 100, 71, 220, 180, 160, 140, 135, 140, 140, 140, 135, 135, 135, 135, 130, 125, 115, 115, 115, -1, 235, 200, 180, 155, 145, 145, 135, 130, 135, 140, 160, 155, 155, 145, 145, 140, 140, -1, 260, 215, 195, 185, 185, 185, 185, 185, 185, 180, 175, 175, 175, 175, 175, 175, 175, 155, 145, 135, 135, 130, 135, 135, 135, 150, 190, 180, 160, 190, -1, -1, -1, 215, 195, 180, 180, 175, 175, 175, 175, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
/// Atomic radius: computed value
const int  ms2ec_r_calculated[116]     = {53, 31, 167, 112, 87, 67, 56, 48, 42, 38, 190, 145, 118, 111, 98, 88, 79, 71, 243, 194, 184, 176, 171, 166, 161, 156, 152, 149, 145, 142, 136, 125, 114, 103, 94, 88, 265, 219, 212, 206, 198, 190, 183, 178, 173, 169, 165, 161, 156, 145, 133, 123, 115, 108, 298, 253, -1, -1, 247, 206, 205, 238, 231, 233, 225, 228, -1, 226, 222, 222, 217, 208, 200, 193, 188, 185, 180, 177, 174, 171, 156, 154, 143, 135, -1, 120, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
/// Van der Waals radius
const int  ms2ec_r_vdWaals[116]        = {120, 140, 182, 153, 192, 170, 155, 152, 147, 154, 227, 173, 184, 210, 180, 180, 175, 188, 275, 231, 211, -1, -1, -1, -1, -1, -1, 163, 140, 139, 187, 211, 185, 190, 185, 202, 303, 249, -1, -1, -1, -1, -1, -1, -1, 163, 172, 158, 193, 217, 206, 206, 198, 216, 343, 268, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 175, 166, 155, 196, 202, 207, 197, 202, 220, 348, 283, -1, -1, -1, 186, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
/// Covalent radius
const int  ms2ec_r_covalent[116]       = {38, 32, 134, 90, 82, 77, 75, 73, 71, 69, 154, 130, 118, 111, 106, 102, 99, 97, 196, 174, 144, 136, 125, 127, 139, 125, 126, 121, 138, 131, 126, 122, 119, 116, 114, 110, 211, 192, 162, 148, 137, 145, 156, 126, 135, 131, 153, 148, 144, 141, 138, 135, 133, 130, 225, 198, 169, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 160, 150, 138, 146, 159, 128, 137, 128, 144, 149, 148, 147, 146, -1, -1, 145, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
/// three bonds covalent radius
const int  ms2ec_r_3bond_covalent[116] = {-1, -1, -1, 85, 73, 60, 54, 53, 53, -1, -1, 127, 111, 102, 94, 95, 93, 96, -1, 133, 114, 108, 106, 103, 103, 102, 96, 101, 120, -1, 121, 114, 106, 107, 110, 108, -1, 139, 124, 121, 116, 113, 110, 103, 106, 112, 137, -1, 146, 132, 127, 121, 125, 122, -1, 149, 139, 131, 128, -1, -1, -1, -1, 132, -1, -1, -1, -1, -1, -1, 131, 122, 119, 115, 110, 109, 107, 110, 123, -1, 150, 137, 135, 129, 138, 133, -1, 159, 140, 136, 129, 118, 116, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 131, 126, 121, 119, 118, 113, 112, 118, 130, -1, -1, -1, -1};

#endif
