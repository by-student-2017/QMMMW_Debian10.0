//!
//! Copyright (C) 2011-2015 QMMMW group
//! This file is distributed under the terms of the
//! GNU General Public License version 3 (GNU-GPLv3).
//!
#include "ms2ec.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <dlfcn.h>
#include "ms2base.h"
#include "ms2ec_radii.h"
#include "../libpickatoms/pickatoms.h"

//! MASK with the atoms in the QM subset
int *qmmask = NULL;
//! Atomic radii of all atoms. Master/QM only
double *aradii = NULL;
//! Charges of the system, QM only
double *__ms2ec_charges = NULL;
//! The number of atoms in the QM subset
int __ms2ec_qmatoms = -1;
//! The total number of atoms in the simulation
int __ms2ec_natoms = -1;
//! The last error encountered
const char *ms2ec_error = NULL;
//! new entry: information about the cell in the master process. Used also by the qm process
// Note: using a static array doesn't work
double *master_cell;


// Master process only: partial results from slave and qm
double *forces_slave = NULL, *forces_qm = NULL;
// Slave process only: vector used to save the positions before reduction
double *tmpdata = NULL;

#define DEBUG(...)      { fprintf(stderr, __VA_ARGS__); };
#define ERROR(argument) { fprintf(stderr, "%s\n", argument); };
#define ERROR2(...)     { fprintf(stderr, __VA_ARGS__); };

// The library will save here a report of how the atoms are matched
#define REPORTFILE  "atomic_matching.txt"

int __ms2ec_parse_expression(int *types, char *atoms_filename)
{
  char *tmp;
  int *tmp_array;

  if(qmmask != NULL) {
    ms2ec_error = "The module was not correctly finalized: unable to setup the MS2 support";
    return 1;
  }
    
  // Allocate a temporary array to hold a rescaled copy of the types array
  tmp_array = (int *) malloc(sizeof(int) * (__ms2ec_natoms + 1));
  if(tmp_array == NULL) {
    ms2ec_error = "Not enough memory for the temporary types array in ms2ec.c";
    return 1;
  }

  // Copy the types into the temporary array (shifted by 1)
  tmp_array[0] = -1;
  memcpy((void *) (tmp_array + 1), types, sizeof(int) * __ms2ec_natoms);
  // Feed the array to libpickatoms 
  tmp = atoms_filename == NULL? NULL:(strlen(atoms_filename) == 0? NULL: atoms_filename);
  qmmask = parse_file(__ms2ec_natoms + 1, tmp_array, &__ms2ec_qmatoms, tmp);

  // Free the temporary_array
  free(tmp_array);

  // Check that the list was parsed correctly
  if(qmmask == NULL) {
    ms2ec_error = "Unable to parse the expression for the selelction of the QM subset";
    return 1;
  }

  // If this doesn't happen we are in big troubles (and the value in
  // __ms2ec_qmatoms is also off by one...). I think is an unnecessary
  // measure though.
  assert(qmmask[0] == -1);

  // Rescale the output: copy qmmask[1:] into tmp_array[] and then
  // switch them
  tmp_array = (int *) malloc(sizeof(int) * __ms2ec_natoms);
  if(tmp_array == NULL) {
    ms2ec_error = "Not enough memory for the temporary types array in ms2ec.c";
    free(qmmask);
    return 1;
  }

  memcpy((void *) tmp_array, (void *) (qmmask + 1), sizeof(int) * __ms2ec_natoms);
  free(qmmask);
  qmmask = tmp_array;

  return 0;
}

void *pack_EC_data(size_t *datasize)
 {
   void *data;

   // Total data = 1 int vectors + 2 double vector, all of natoms elements
   *datasize = sizeof(int) * __ms2ec_natoms + 2 * sizeof(double) * __ms2ec_natoms + 9 * sizeof(double);

   data = malloc(*datasize);
   if (data == NULL) {
     ms2ec_error = "pack_EC_data: unable to allocate the memory required for the first data transmission";
     return NULL;
   }

   // Pack all the data. FIXME: ugly code... perhaps a little semplification would be in order
   // FIXME: doesn't work between machines with different endianness
   memcpy(data,                                      qmmask, __ms2ec_natoms * sizeof(int));
   memcpy(data + __ms2ec_natoms * sizeof(int),       aradii, __ms2ec_natoms * sizeof(double));
   memcpy(data + __ms2ec_natoms * (sizeof(double) + sizeof(int)), __ms2ec_charges, __ms2ec_natoms * sizeof(double));
   memcpy(data + __ms2ec_natoms * (sizeof(double) + sizeof(int)) + __ms2ec_natoms * sizeof(double), master_cell, sizeof(double) * 9);
   return data;
 }

int unpack_EC_data(void *data)
{
  // Get the mask
  qmmask = (int *) calloc(__ms2ec_natoms, sizeof(int));
  if(qmmask == NULL) {
    ERROR("unpack_EC_data: unable to allocate the memory for the QMmask");
    return 1;
  }
  memcpy(qmmask, data, __ms2ec_natoms * sizeof(int));

  // Get the radii
  aradii = (double *) calloc(__ms2ec_natoms, sizeof(double));
  if(aradii == NULL) {
    ERROR("unpack_EC_data: unable to allocate the memory for the atomic radii");
    return 1;
  }
  memcpy(aradii, data + __ms2ec_natoms * sizeof(int), __ms2ec_natoms * sizeof(double));
  
  // Get the charges
  __ms2ec_charges = (double *) calloc(__ms2ec_natoms, sizeof(double));
  if(__ms2ec_charges == NULL) {
    ERROR("unpack_initialization_data: unable to allocate the memory for the charges");
    return 1;
  }
  memcpy(__ms2ec_charges, data + __ms2ec_natoms * (sizeof(double) + sizeof(int)), __ms2ec_natoms * sizeof(double));

  // Get the cell size
  master_cell = (double *) calloc(9, sizeof(double));
  if(master_cell == NULL) {
    ERROR("unpack_initialization_data: unable to allocate the memory for the cell data");
    return 1;
  }  
  memcpy(master_cell, data + __ms2ec_natoms * (sizeof(double) + sizeof(int)) + __ms2ec_natoms * sizeof(double), sizeof(double) * 9);

  return 0;
}

// Use the QMmask to pack the natoms data to a qmatoms vector
// a.k.a. from big to small
void __pack_MM_data(void *src, void *dst, size_t elsize)
{
  int i, j;
  j = 0;
  for(i=0;i<__ms2ec_natoms;i++)
    if(qmmask[i] != -1) {
      memcpy(dst + j * elsize, src + i * elsize, elsize);
      j++;
    }
  assert(j == __ms2ec_qmatoms);
}

// Use the QMmask to unpack qmatoms elements into a natoms vector
// a.k.a. from small to big
void __ms2ec_mix_forces(double *dst, double *fslave, double *fqm)
{
  int i, j;
#ifdef DUMPFORCES
  FILE *f;

  f = fopen("forces.txt", "w");
#endif

  j = 0;
  for(i=0;i<__ms2ec_natoms;i++)
    if(qmmask[i] != -1) {
      dst[3 * i + 0] += fqm[3 * i + 0] - fslave[3 * j + 0];
      dst[3 * i + 1] += fqm[3 * i + 1] - fslave[3 * j + 1];
      dst[3 * i + 2] += fqm[3 * i + 2] - fslave[3 * j + 2];
#ifdef DUMPFORCES
      fprintf(f, "%g %g\n", fqm[3 * i + 0], fslave[3 * j + 0]);
      fprintf(f, "%g %g\n", fqm[3 * i + 1], fslave[3 * j + 1]);
      fprintf(f, "%g %g\n", fqm[3 * i + 2], fslave[3 * j + 2]);
#endif
      j++;
    } else {
      dst[3 * i + 0] += fqm[3 * i + 0];
      dst[3 * i + 1] += fqm[3 * i + 1];
      dst[3 * i + 2] += fqm[3 * i + 2];
    }
  assert(j == __ms2ec_qmatoms);
#ifdef DUMPFORCES
  fclose(f);
#endif
}

#define MS2EC_RADIUS ms2ec_r_covalent
int __ms2ec_fill_radii(int *Z)
{
  int i, j;
  int el;
  char errmsg[150];
  FILE *reportfile;
  int opened = 1;

  reportfile = fopen(REPORTFILE, "w");

  if(reportfile == NULL) {
    fprintf(stderr, 
	    "libms2ec: Warning: unable to write the report file '%s': dumping to stderr", 
	    REPORTFILE);
    opened = 0;
    reportfile = stderr;
  }
  fprintf(reportfile, "libms2ec: report of atom index -> type/radius matching\n");
  for(i=0;i<__ms2ec_natoms;i++) {
    el = -1;
    for(j=0;j<ms2ec_elements;j++)
      if(ms2ec_Z[j] == Z[i]) {
	el = j;
	break;
      }
    if(el == -1) {
      snprintf(errmsg, 150, "Unable to find element Z = %d in our list (%s:%d)", 
	       Z[i],
	       __FILE__,
	       __LINE__);
      ERROR(errmsg);
      return 1;
    }
    aradii[i] = (double) MS2EC_RADIUS[el] / 100.0;
    if(MS2EC_RADIUS[el] == -1) {
      snprintf(errmsg, 150, "Atomic radius for atom of type Z=%d not availabe (%s:%d)", 
	       Z[i],
	       __FILE__,
	       __LINE__);
      ERROR(errmsg);
      return 1;
    }
    fprintf(reportfile, "libms2ec: atom %6d --> type: %-3s radius: %-g A\n", i, ms2ec_element[j], aradii[i]);
  }
  fflush(reportfile);
  if(opened)
    fclose(reportfile);
  return 0;
}
 
int ms2ec_master_initialize(int argc, char *argv[], int atom_num, int *types, 
			    double *atom_charges,
			    int *atom_Z, const double *celldata)
{
  int errcode;
  int res;
  void *data;
  size_t datasize;  // Size of the data returned by pack_initialization_data
  int res_s, res_q; // error codes for collective operations
  int send_buf[2];  // buffer to send the natoms and qmatoms. 
                    // Assume that the byte order is the same
  
  // Set the number of atoms
  __ms2ec_natoms  = atom_num;
  // Set the charges and atomic number
  __ms2ec_charges = atom_charges;

  // Make a copy of the celldata
  master_cell = (double *) calloc(9, sizeof(double));
  if(master_cell == NULL) {
    ms2ec_error = "Not enough memory for the master_cell array in ms2ec.c";
    return 1;
  }
  memcpy(master_cell, celldata, sizeof(double) * 9);

  // Allocate an array for the atomic radii and fill it
  aradii = (double *) calloc(__ms2ec_natoms, sizeof(double));
  if(aradii == NULL) {
    ms2ec_error = "Not enough memory for the atomicradii array in ms2ec.c";
    return 1;
  }
  __ms2ec_fill_radii(atom_Z);

  // Get the set of QM atoms with libpickatoms
  errcode = __ms2ec_parse_expression(types, argv[0]);
  if(errcode) {
    ERROR(ms2ec_error);
    return 1;
  }

  // Ensure that the charges are 0 for the QM atoms
  {
    int i;
    static char error[100];
    for(i = 0; i < atom_num;++i) 
      if((qmmask[i] != -1) && (atom_charges[i] != 0.0)) {
	snprintf(error, 100, "All QM charges in the master data file should be 0 (charge %d = %g)", i + 1, atom_charges[i]);
	ms2ec_error = error;
	ERROR(ms2ec_error);
	return 1;
      }
  }

  // Allocate enough space for the temporary force vectors and a temporary vector
  forces_slave  = (double *) calloc(__ms2ec_qmatoms * 3, sizeof(double));
  if(forces_slave == NULL) {
    ERROR("Unable to allocate the space for the slave force vector");
    return 1;
  }
  forces_qm     = (double *) calloc(__ms2ec_natoms  * 3, sizeof(double));
  if(forces_qm == NULL) {
    ERROR("Unable to allocate the space for the qm force vector");
    return 1;
  }
  tmpdata = (double *) calloc(__ms2ec_qmatoms * 3, sizeof(double));
  if(tmpdata == NULL) {
    ERROR("Unable to allocate the space for temporary data on the slave");
    return 1;
  }

  // Get the module and funcations on the master process
  res = ms2base_master_init(argv[1], argc - 2, argv + 2);
  if(res) {
    ERROR("Unable to initialize the master process!");
    return 1;
    }
  
  // Propagate the total number of atoms
  send_buf[0] = __ms2ec_natoms;
  send_buf[1] = __ms2ec_qmatoms;
  ms2base_master_to_peers(send_buf, sizeof(int) * 2, &res_s, &res_q);
  if(res_s) {
    ERROR("Unable to send the total number of atoms to the slave process");
  }
  if(res_q) {
    ERROR("Unable to send the total number of atoms to the QM process");
  }
  if(res_s || res_q)
    return 1;

  // Pack the data required for the initialization of the QM/EC part on the QM process
  data = pack_EC_data(&datasize);
  if(data == NULL) {
    ERROR(ms2ec_error)
      return 1;
  }
  res = ms2base_master_to_qm(data, datasize);
  if(res) {
    ERROR("Unable to send the initialization data to the qm process");
    return 1;
  }
  free(data);

  // the atomic charges are a borrowed reference which will be removed after the return.
  // Clear the value to avoid unwanted accesses.
  __ms2ec_charges = NULL;

  return res;
}

int ms2ec_slave_initialize(int argc, char *argv[], 
			   int quantum_atoms)
{
  int res;
  int recv_buf[2];  // Pairs with send_buf in the master process


  __ms2ec_qmatoms = quantum_atoms;

  // Load the transport module
  res = ms2base_slave_init(argv[0], argc - 1, argv + 1);
  if(res) {
    ERROR("Module initialization failed on the slave process!");
    return 1;
  }

  // Receive the total number of atoms and double check the # of qm atoms
  res = ms2base_slave_from_master(recv_buf);
  if(res != 0) {
    ERROR("Unable to receive the number of atoms in the simulation!");
    return 1;
  }
  __ms2ec_natoms = recv_buf[0];
  if(recv_buf[1] != __ms2ec_qmatoms) {
    char error[500];
    snprintf(error,500, "The size of the Quantum subset differs between the master and slave process (local = %d vs remote = %d)!\n", __ms2ec_qmatoms, recv_buf[1]);
    ERROR(error);
    return 1;
  }
  __ms2ec_qmatoms = recv_buf[1];

  // Allocate a temporary vector
  tmpdata = (double *) calloc(__ms2ec_qmatoms * 3, sizeof(double));
  if(tmpdata == NULL) {
    ERROR("Unable to allocate the space for temporary data on the slave");
    return 1;
  }
  
  return res;
}

int ms2ec_qm_initialize(int argc, char *argv[], 
			int quantum_atoms, 
			int *totatoms, int **mask, double **allcharges, double **atomic_radii, double **celldata)
{
  int res;
  void *data;
  size_t datasize;
  int recv_buf[2];  // Pairs with send_buf in the master process

  __ms2ec_qmatoms = quantum_atoms;
  
  res = ms2base_qm_init(argv[0], argc - 1, argv + 1);
  if(res) {
    ERROR("Module initialization failed on the QM process!");
    return 1;
  }

  // Two messages for the initializatin measn it will a rather slow process
  // It's done only once, so I don't really give a damn.
  res = ms2base_qm_from_master(&recv_buf);
  if(res != 0) {
    ERROR("Unable to receive the number of atoms in the simulation!");
    return 1;
  }

  __ms2ec_natoms = recv_buf[0];
  if(recv_buf[1] != __ms2ec_qmatoms) {
    ERROR("The size of the Quantum subset differs between the master and qm process (wrong subset defintion or mismatching architectures)!");
    return 1;
  }

  // Allocate the space for the message. This is done only on this occasion
  datasize = sizeof(int) * __ms2ec_natoms + sizeof(double) * __ms2ec_natoms + sizeof(double) * __ms2ec_natoms + 9 * sizeof(double);
  data = malloc(datasize);
  if(data == NULL) {
    ERROR("Unable to allocate enough data for a temporary recv buffer");
    return 1;
  }

  res = ms2base_qm_from_master(data);
  if(res != 0) {
    ERROR("Unable to receive the data required for the initialization on the slave process!");
    free(data);
    return 1;
  }
  
  res = unpack_EC_data(data);
  if(res != 0) {
    free(data);
    return 1;
  }
  free(data);

  // Allocate enough space for the vector with the temporary data
  tmpdata = (double *) calloc(__ms2ec_qmatoms * 3, sizeof(double));
  if(tmpdata == NULL) {
    ERROR("Unable to allocate the space for temporary data on the quantum process");
    return 1;
  }

  // Pass the data to the quantum code
  *totatoms = __ms2ec_natoms;
  *mask = qmmask;
  *allcharges = __ms2ec_charges;
  *atomic_radii = aradii;
  *celldata = master_cell;
  return res;
}


// I think that 1024 arguments in a single string are probably enough...
#define MAX_ARGV 1024
char **__ms2base_convert_string_to_args(char *args, int *argc)
{
  char *ptr;      // State pointer for strtok_r
  char **argv;    // the new array of arguments
  char *res;

  assert(MAX_ARGV > 0);
  
  argv = (char **) calloc(MAX_ARGV + 1, sizeof(char *));
  if(!argv)
    return NULL;

  *argc = 0;

  // First pass
  res = strtok_r(args, "\t ", &ptr);
  if(!res) {
    ERROR2("Transport name missing ("__FILE__":%d!\n", __LINE__);
    free(argv);
    return NULL;
  }

  argv[*argc] = strdup(res);
  if(!argv[*argc]) {
    ERROR("Unable to allocate enough memory for the transport arguments");
    free(argv);
    return NULL;
  }
  *argc += 1;

  // Following arguments
  while((res = strtok_r(NULL, "\t ", &ptr)) != NULL) {
    // If you specify a string of more than 1024 tokens, a program
    // crash is what you deserve
    assert(*argc < MAX_ARGV);
    argv[*argc] = strdup(res);
    if(!argv[*argc]) {
      int i;
      ERROR("Unable to allocate enough memory for the transport arguments");
      for(i=*argc - 1; i>=0;i++)
	free(argv[i]);
      free(argv);
      return NULL;
    }
    *argc += 1;
  }

  argv[*argc] = NULL;

  return argv;
}
#undef MAX_ARGV

int ms2ec_qm_initialize_simplified(char *args, int qatoms,   // Output from QE
				   int *totatoms, int **mask, double **allcharges,
				   double **atomic_radii, double **celldata)  // Input from the master
{
  char **argv;
  int argc, retval, i;

  argv = __ms2base_convert_string_to_args(args, &argc);
  if(!argv) {
    ERROR2("Unable to convert a single string to arguments in "__FILE__":%d\n", __LINE__);
    return 1;
  }
  retval = ms2ec_qm_initialize(argc, argv, qatoms, totatoms, mask, allcharges, atomic_radii, celldata);

  // Free the memory for the arguments
  for(i=0;i<argc;i++)
    free(argv[i]);
  free(argv);
  return retval;
}

void __ms2ec_print_vector(double *v3ctor, int el, const char *fmt, int inc)
{
  int i;
  static int counter = 0;
  for(i=0;i<el;i++) 
    fprintf(stderr, fmt, counter, i, v3ctor[3 * i + 0], v3ctor[3 * i + 1], v3ctor[3 * i + 2]); 
  counter += inc;
}

int ms2ec_master_send_positions(double *pos)
{
#ifdef DEBUGINFO
  __ms2ec_print_vector(pos, __ms2ec_natoms, "%d:  POS0[%d] = %12.6g %12.6g %12.6g\n", 0);
#endif
  if(ms2base_master_to_qm(pos, sizeof(double) * __ms2ec_natoms * 3) != 0) {
    ERROR("Unable to send the positions to the qm process");
    return 1;
  }

  __pack_MM_data(pos, tmpdata, sizeof(double) * 3);   // TODO: missing qmatoms * 3 * double vector
  if(ms2base_master_to_slave(tmpdata, sizeof(double) * __ms2ec_qmatoms * 3) != 0) {
    ERROR("Unable to send the positions to the slave process");
    return 1;
  }
  return 0;
}

int ms2ec_slave_recv_positions(double *pos)
{
  if(ms2base_slave_from_master(pos) != 0) {
    ERROR("Unable to receive the position from the master process!");
    return 1;
  }
  return 0;
}

int ms2ec_qm_recv_positions(double *pos)
{
  if(ms2base_qm_from_master(pos) != 0) {
    ERROR("Unable to receive the positions from the master process!");
    return 1;
  }
  return 0;
}

int ms2ec_master_recv_forces(double *forces)
{
  int res;
  int i;
#ifdef DEBUGINFO
  __ms2ec_print_vector(forces, __ms2ec_natoms, "%d:  FORCE1[%d] = %12.6g %12.6g %12.6g\n", 0);
#endif
  res = ms2base_master_from_slave(forces_slave);
  if(res) {
    ERROR("forces not received from the slave process!");
    return 1;
  }

  res = ms2base_master_from_qm(forces_qm);
  if(res) {
    ERROR("forces not received from the qm process!");
    return 1;
  }

  // Compose the forces
  __ms2ec_mix_forces(forces, forces_slave, forces_qm);

#ifdef DEBUGINFO
  __ms2ec_print_vector(forces, __ms2ec_natoms, "%d:  FORCE2[%d] = %12.6g %12.6g %12.6g\n", 1);
#endif


  return res;
}

int ms2ec_slave_send_forces(double *forces)
{
  if(ms2base_slave_to_master(forces, 
			     sizeof(double) * 3 * __ms2ec_qmatoms) != 0) {

    ERROR("Unable to send the forces back to the master");
    return 1;
  }
  return 0;
}

int ms2ec_qm_send_forces(double *forces)
{
  if(ms2base_qm_to_master(forces, 
			  sizeof(double) * 3 * __ms2ec_natoms) != 0) {

    ERROR("Unable to send the forces back to the master");
    return 1;
  }
  return 0;
}

int ms2ec_master_finalize(void)
{
  free(qmmask);
  free(tmpdata);
  free(forces_slave);
  free(forces_qm);
  free(aradii);
  free(master_cell);
  return ms2base_master_finalize();
}

int ms2ec_slave_finalize(void)
{
  free(tmpdata);
  return ms2base_slave_finalize();
}

int ms2ec_qm_finalize(void)
{
  free(tmpdata);
  free(qmmask);
  free(aradii);
  free(__ms2ec_charges);
  free(master_cell);
  return ms2base_qm_finalize();
}
