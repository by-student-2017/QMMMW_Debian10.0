//!
//! Copyright (C) 2011-2015 QMMMW group
//! This file is distributed under the terms of the
//! GNU General Public License version 3 (GNU-GPLv3).
//!
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "ms2base_debug.h"
#include <dlfcn.h>
#include <openssl/md5.h>


/**
   DEBUG module for the ms2base transports.

   Most code ripped from ms2base.c
*/

#define MSG(...) {fprintf(stderr, "libms2base_debug: " __VA_ARGS__);}


/*
   INITIALIZATION FUNCTIONS
*/
void *__ms2base_lib = NULL;
char *__ms2base_debug_modulename = NULL;
char *__ms2base_debug_library_name = NULL;

int __ms2base_debug_get_args(int *argc, char ***argv)
{
  if(*argc == 0) {
    MSG("insufficient arguments for the debug module\n");
    return 1;
  }

  (*argc)--;
  __ms2base_debug_modulename = strdup(*argv[0]);
  *argv = *argv + 1;

  if(strlen(__ms2base_debug_modulename) > 20) {
    MSG("module name '%s' is too long (max 20 chars. allowed)\n", __ms2base_debug_modulename);
    return 1;
  }

  asprintf(&__ms2base_debug_library_name, "libms2base_%s.so", __ms2base_debug_modulename);
  if(__ms2base_debug_library_name == NULL) {
    MSG("unable to allocate enough space for the library name (modulename = '%s')\n", __ms2base_debug_modulename);
    return 1;
  }

  __ms2base_lib = dlopen(__ms2base_debug_library_name, RTLD_NOW | RTLD_GLOBAL);
  if(__ms2base_lib == NULL) {
    MSG("unable to open '%s': %s\n", __ms2base_debug_library_name, dlerror());
    return 1;
  }
  return 0;
}

void __ms2base_debug_print_hash(char *funcname, char *md5hash)
{
  char hash[33];
  int *tmp = (int *) md5hash;
  snprintf(hash, 33, "%.8x%.8x%.8x", tmp[0], tmp[1], tmp[2], tmp[3]);
  MSG("%-20s: %s\n", funcname, hash);
}


#define INIT_FUNCTION(FUNCNAME)                                           \
  int ms2base_debug_ ## FUNCNAME(int argc, char *argv[])                  \
{                                                                         \
  char *symname;                                                          \
  int (*sym)(int, char **);                                               \
                                                                          \
  if(__ms2base_debug_get_args(&argc, &argv)) return 1;                      \
                                                                          \
  asprintf(&symname, "ms2base_%s_" # FUNCNAME, __ms2base_debug_modulename); \
  sym = (void *) dlsym(__ms2base_lib, symname);                             \
  free(symname);                                                          \
  if(!sym) {                                                              \
    MSG("unable to get symbol '%s': %s\n", "" # FUNCNAME, dlerror());     \
    return 1;                                                             \
  }                                                                       \
  return sym(argc,argv);                                                  \
}                                                                         \

INIT_FUNCTION(master_init);

INIT_FUNCTION(slave_init);

INIT_FUNCTION(qm_init);
#undef INIT_FUNCTION


/*
   TRANSMISSION FUNCTIONS
*/

#define SEND_FUNCTION(FUNCNAME)                                                \
 int ms2base_debug_ ## FUNCNAME(void *data, size_t size)                       \
 {									       \
   char *symname;							       \
   int (*sym)(void *, size_t size);					       \
   asprintf(&symname, "ms2base_%s_" # FUNCNAME, __ms2base_debug_modulename);     \
   sym = (void *) dlsym(__ms2base_lib, symname);				       \
   free(symname);							       \
   if(!sym) {								       \
     MSG("unable to get symbol '%s': %s\n", "" # FUNCNAME, dlerror());	       \
     return 1;								       \
   }									       \
									       \
   {									       \
     MD5_CTX c;								       \
     unsigned char output[128];						       \
     MD5_Init(&c);							       \
     MD5_Update(&c, data, (unsigned long) size);			       \
     MD5_Final(output, &c);						       \
     __ms2base_debug_print_hash("" # FUNCNAME, output);			       \
   }									       \
	                                                                       \
   MSG("sending datasize = %ld\n", (long) size);   			       \
   if(sym(&size, sizeof(size_t))) {					       \
     MSG("unable to-wrap the data by sending the data size\n");		       \
     return 1;								       \
   }									       \
   return sym(data, size);						       \
 }                                                                             \


SEND_FUNCTION(master_to_slave);

SEND_FUNCTION(master_to_qm);

SEND_FUNCTION(slave_to_master);

SEND_FUNCTION(qm_to_master);
#undef SEND_FUNCTION

#define RECV_FUNCTION(FUNCNAME)                                                  \
int ms2base_debug_ ## FUNCNAME(void *data)					 \
{										 \
  char *symname;								 \
  int (*sym)(void *);								 \
  size_t size;									 \
  int status;									 \
										 \
  asprintf(&symname, "ms2base_%s_" # FUNCNAME, __ms2base_debug_modulename);	 \
  sym = (void *) dlsym(__ms2base_lib, symname);					 \
  free(symname);								 \
  if(!sym) {									 \
    MSG("unable to get symbol '%s': %s\n", "" # FUNCNAME, dlerror());		 \
    return 1;									 \
  }										 \
  										 \
  if(sym(&size)) {								 \
     MSG("unable to un-wrap the data by receiving the data\n");			 \
     return 1;									 \
  }										 \
  MSG("received datasize = %ld\n", (long) size);				 \
  status = sym(data);							         \
  {									         \
    MD5_CTX c;								         \
    unsigned char output[128];						         \
    MD5_Init(&c);							         \
    MD5_Update(&c, data, (unsigned long) size);					 \
    MD5_Final(output, &c);							 \
    __ms2base_debug_print_hash("" # FUNCNAME, output);				 \
  }										 \
  return status;								 \
}                                                                                \

RECV_FUNCTION(master_from_slave);

RECV_FUNCTION(master_from_qm);

RECV_FUNCTION(slave_from_master);

RECV_FUNCTION(qm_from_master);
#undef RECV_FUNCTION

/*
   FINALIZATION FUNCTIONS
*/

void __ms2base_debug_finalize(void)
{
  if(__ms2base_lib != NULL) {
    dlclose(__ms2base_lib);
    __ms2base_lib = NULL;
  }

  free(__ms2base_debug_modulename);
  __ms2base_debug_modulename = NULL;

  free(__ms2base_debug_library_name);
  __ms2base_debug_library_name = NULL;
}

#define FINAL_FUNCTION(FUNCNAME)                                          \
int ms2base_debug_ ## FUNCNAME(void)                                      \
{                                                                         \
  int status = 0;                                                         \
  char *symname;                                                          \
  int (*sym)(void);                                                       \
  asprintf(&symname, "ms2base_%s_" # FUNCNAME, __ms2base_debug_modulename); \
  sym = (void *) dlsym(__ms2base_lib, symname);                             \
  free(symname);                                                          \
  if(!sym) {                                                              \
    MSG("unable to get symbol '%s': %s\n", "" # FUNCNAME, dlerror());     \
    return 1;                                                             \
  }                                                                       \
  status = sym();                                                         \
  __ms2base_debug_finalize();                                             \
 return status;                                                           \
}                                                                         \

FINAL_FUNCTION(master_finalize);

FINAL_FUNCTION(slave_finalize);

FINAL_FUNCTION(qm_finalize);
#undef FINAL_FUNCTION

