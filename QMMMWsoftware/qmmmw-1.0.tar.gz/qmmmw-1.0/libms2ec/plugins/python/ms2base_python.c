//!
//! Copyright (C) 2011-2015 QMMMW group
//! This file is distributed under the terms of the
//! GNU General Public License version 3 (GNU-GPLv3).
//!
#include "ms2base_python.h"
#include <stdio.h>

#define ERROR(message) fprintf(stderr, __FILE__":%d %s\n", __LINE__, message)
#define FINALIZE_POBJ(name) if(name) {Py_DECREF(name);name = NULL;}

// The reference to the module "array"
PyObject *arraymodule;
// The instance of the MS2 module in the python script
PyObject *pyMS2instance;

// Finalize the python interpreter
void finalize_python()
{
  FINALIZE_POBJ(arraymodule);
  FINALIZE_POBJ(pyMS2instance);
  Py_Finalize();
}

// Initialize python (the role is passed to the class instance)
int init_python(int role, int argc, char *argv[])
{
  PyObject *pyModuleName;
  PyObject *pyModule;
  PyObject *pyArgs;
  PyObject *pyValue, *pyValue2;
  PyObject *pyMS2class;
  double *tmparray;
  PyObject *tmpstring;
  int args, index, i;

  // Start the interpreter
  Py_Initialize();

  // Get the module. It will be passed to the module itself anyway
  if(argv[0] == NULL) {
    ERROR("Invalid argument");
    Py_Finalize();
    return 1;
  }

  // Convert the name of the module from C string to Python
  pyModuleName = PyString_FromString(argv[0]);
  if(!pyModuleName) {
    PyErr_Print();
    PyErr_Clear();
    finalize_python();
    return 1;
  }

  // Import the module requested by the user
  pyModule = PyImport_Import(pyModuleName);
  Py_DECREF(pyModuleName);

  if(!pyModule) {
    PyErr_Print();
    PyErr_Clear();
    finalize_python();
    return 1;
  }

  // Import the module "Array"
  arraymodule = PyImport_ImportModule("array");
  if(!arraymodule) {
    PyErr_Print();
    PyErr_Clear();
    finalize_python();
    return 1;
  }

  // Get the class with the code. Unlike the older MC version, a single class is used in this version
  // with an extra argument (the first one) determining the role (0,
  // 1, 2 for master/slave and qe respectively)
  pyMS2class = PyObject_GetAttrString(pyModule, "MS2base");
  Py_DECREF(pyModule);

  if(!pyMS2class) {
    PyErr_Print();
    finalize_python();
    return 1;
  }

  // Find out if the object is callable and a class
  if(!PyClass_Check(pyMS2class) && !PyType_Check(pyMS2class)) {
    fprintf(stderr, "MS2base should be a class object\n");
    Py_DECREF(pyMS2class);
    return 1;
  }

  // Create the tuple that will hold the arguments
  pyArgs = PyTuple_New((Py_ssize_t) argc + 1);
  if(!pyArgs) {
    PyErr_Print();
    PyErr_Clear();
    finalize_python();
    return 1;
  }

  // Add the arguments: first the role of the class
  index = 0;
  pyValue = PyInt_FromLong((long) role);
  if(!pyValue) {
    Py_DECREF(pyArgs);
    PyErr_Print();
    PyErr_Clear();
    finalize_python();
    return 1;
  }
  PyTuple_SetItem(pyArgs, index++, pyValue);

  for(i=0;i<argc;i++) {
    pyValue = PyString_FromString(argv[i]);
    if(!pyValue) {
      Py_DECREF(pyArgs);
      PyErr_Print();
      PyErr_Clear();
      finalize_python();
      return 1;
    }
    PyTuple_SetItem(pyArgs, index++, pyValue);
  }
  //PyObject_Print(pyArgs, stdout, 0);

  // Create an instance out of the class (it will be stored in the pyMS2instance variable)
  pyMS2instance = PyObject_CallObject(pyMS2class, pyArgs);
  Py_DECREF(pyMS2class);
  Py_DECREF(pyArgs);
  if(!pyMS2instance) {
    PyErr_Print();
    PyErr_Clear();
    finalize_python();
    return 1;
  }
  
  return 0;
}

int ms2base_python_master_init(int argc, char *argv[])
{
  if(init_python(0, argc,argv))
    return 1;
  return 0;
}

int ms2base_python_slave_init(int argc, char *argv[])
{
  if(init_python(1, argc,argv))
    return 1;
  return 0;
}

int ms2base_python_qm_init(int argc, char *argv[])
{
  if(init_python(2, argc,argv))
    return 1;
  return 0;
}

// Creates an object from the data passed as argument. Keep in mind that this copies the data!
// Returns NULL on error
PyObject *arrayFromData(void *data, size_t size)
{
  PyObject *pyarray;
  // Allocate the input and output arrays
  PyObject *tmpstring = PyString_FromStringAndSize((char *) data, size);
  if(!tmpstring) {
    PyErr_Print();
    PyErr_Clear();
    finalize_python();
    return NULL;
  }
    
  pyarray = PyObject_CallMethod(arraymodule,
				   "array",
				   "sO","b", tmpstring);

  if(!pyarray) {
    Py_DECREF(tmpstring);
    PyErr_Print();
    PyErr_Clear();
    finalize_python();
    return NULL;
  }
  return pyarray;
}   

// Creates an empty array (NULL on error)
PyObject *emptyArray(void)
{
  return arrayFromData(NULL, 0);
}   

int python_call(PyObject *argument, char *methodName) 
{
  // Call the function using the array as an argument
  int res;
  PyObject *pyRetval = PyObject_CallMethod(pyMS2instance, methodName, "O", argument);  
  if(!pyRetval) {
    PyErr_Print();
    PyErr_Clear();
    finalize_python();
    return 1;
  }
  
  // Test if the result is True (which means error...)
  res = PyObject_IsTrue(pyRetval);
  Py_DECREF(pyRetval);

  switch(res) {
  case -1:
    // The test on the return value failed: this is an exception and should be reported to the user
    PyErr_Print();
    PyErr_Clear();
    // Fall through!
  case 1:
    // This means that the function is reporting failure (pyRetVal was actually checked for true): the interpreter is ok
    finalize_python();
    return 1;
  }

  return 0;
}

int pymemcpy(void *data, PyObject *pydata)
{
  void *pyarray;
  size_t size;
  if(PyObject_AsReadBuffer(pydata, (const void **) &pyarray, &size) < 0) {
    PyErr_Print();
    PyErr_Clear();
    finalize_python();
    return 1;
  }
  // If the array is ok, copy the data back
  memcpy(data, pyarray, size);

  return 0;
}

int ms2base_python_master_to_slave(void *data, size_t size)
{
  PyObject *pydata = arrayFromData(data, size);
  if(pydata == NULL)
    return 1;
  if(python_call(pydata, "master_to_slave"))
    return 1;
  Py_DECREF(pydata);
  return 0;
}

int ms2base_python_slave_from_master(void *data)
{
  PyObject *pydata = emptyArray();
  if(pydata == NULL)
    return 1;
  if(python_call(pydata, "slave_from_master"))
    return 1;
  if(pymemcpy(data, pydata))
    return 1;
  Py_DECREF(pydata);
  return 0;
}


int ms2base_python_master_to_qm(void *data, size_t size)
{
  PyObject *pydata = arrayFromData(data, size);
  if(pydata == NULL)
    return 1;
  if(python_call(pydata, "master_to_qm"))
    return 1;
  Py_DECREF(pydata);
  return 0;
}

int ms2base_python_qm_from_master(void *data)
{
  PyObject *pydata = emptyArray();
  if(pydata == NULL)
    return 1;
  if(python_call(pydata, "qm_from_master"))
    return 1;
  if(pymemcpy(data, pydata))
    return 1;
  Py_DECREF(pydata);
  return 0;
}


int ms2base_python_slave_to_master(void *data, size_t size)
{
  PyObject *pydata = arrayFromData(data, size);
  if(pydata == NULL)
    return 1;
  if(python_call(pydata, "slave_to_master"))
    return 1;
  Py_DECREF(pydata);
  return 0;
}

int ms2base_python_master_from_slave(void *data)
{
  PyObject *pydata = emptyArray();
  if(pydata == NULL)
    return 1;
  if(python_call(pydata, "master_from_slave"))
    return 1;
  if(pymemcpy(data, pydata))
    return 1;
  Py_DECREF(pydata);
  return 0;
}


int ms2base_python_qm_to_master(void *data, size_t size)
{
  PyObject *pydata = arrayFromData(data, size);
  if(pydata == NULL)
    return 1;
  if(python_call(pydata, "qm_to_master"))
    return 1;
  Py_DECREF(pydata);
  return 0;
}

int ms2base_python_master_from_qm(void *data)
{
  PyObject *pydata = emptyArray();
  if(pydata == NULL)
    return 1;
  if(python_call(pydata, "master_from_qm"))
    return 1;
  if(pymemcpy(data, pydata))
    return 1;
  Py_DECREF(pydata);
  return 0;
}


int ms2base_python_master_finalize(void)
{
  finalize_python();
}

int ms2base_python_slave_finalize(void)
{
  finalize_python();
}

int ms2base_python_qm_finalize(void)
{
  finalize_python();
}
    
