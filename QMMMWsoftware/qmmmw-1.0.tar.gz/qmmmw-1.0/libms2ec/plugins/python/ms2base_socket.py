"""Copyright (C) 2011-2015 QMMMW group
   This file is distributed under the terms of the
   GNU General Public License version 3 (GNU-GPLv3)."""
"""Socket transport module for libms2base (MS2 project, EC algorithm).

This module shows an example of how a python script can be written to
exchange the data between the processes in a MS2 simulation.

Python scripts to be used in tandem with the libms2base_python.so
plugin require at least one class, which should be called MS2base and
contain 6 methods beside init (each receiving a byte array as only
argument, which will be used for input or output, depending on the
purpose of the call):

master_to_slave
master_to_qm
slave_to_master
qm_to_master
slave_from_master
qm_from_master
master_from_slave
master_from_qm

A init method should also be specified, keeping in mind that the
number of parameters passed to it is linked to the number of
parameters in the lammps input file.

Keep in mind that due to a design decision, the function receiving the
data have no idea about the size of the data itself (an empty array is
passed to them) and therefore a mean should be found to transmit to
the receiver the length of the payload.

See the code for more details."""

import socket
import sys
import re
import array
import struct

# Maximum length of the password (chars above that are truncated,
# shorter password will be padded)
MAXPASS = 10
# constants for the roles
ROLE_MASTER = 0
ROLE_SLAVE  = 1
ROLE_QM     = 2

def INFO(msg):
    sys.stderr.write(msg + "\n")

def ERROR(msg):
    sys.stderr.write("ERROR: %s \n" % msg)

class MS2base:
    """Class used to handle the data transmission

    The class is used for all 3 roles (a change from the same plugin
    in the MC algorithm, where each master, slave and qm had their own
    class) and is used to instantiate an object at the very start of
    the plugin initialization."""
    
    def __init__(self, role, script_name, host, port, password):
        """Initialization function.

        The arguments list contains the tokens the user wrote in the
        LAMMPS configuration file, with the important add of the role
        one, which is always present. De facto this means that the
        first argument after role is the name of the loaded script
        (which might come in handy anyway).

        Being the init always the same, should the programs in the
        different roles require a different number of arguments, the
        user can use default arguments, read the arguments as a tuple
        or even use different scripts for the master/slave/qe.

        role:        (0|1|2) for master/slave and qm respectively
        script_name: the name of the script (without extension)
        host:        the hostname of the server (ignored on the master)
        port:        the listening port
        password:    a simple password to protect the connection
                     (don't use a precious one: it will travel the
                     network in plaintext!!)"""
        
        # do some sanity check on the arguments
        try:
            self.port = int(port)
        except ValueError,error:
            raise ValueError, "The port argument should be an integer!\n"
        
        if len(password) > MAXPASS:
            sys.stderr.write("Password length truncated to %s characters" % MAXPASS)
            self.password = password[:MAXPASS]
        else:
            self.password = password[:MAXPASS] + " " * (MAXPASS - len(password[:MAXPASS]))
        
        self.role        = role
        self.script_name = script_name
        self.host        = host

        # Initialize some variables to simplify the destructor
        self.master = self.slave = self.qm = None

        # Initialize the socket
        if(role == ROLE_MASTER):
            self._init_server()
        else:
            self._init_client()
            
    def _init_server(self):
        """Initialize the server, wait until 2 connections are
        established and authenticated"""
        ssocket = socket.socket()

        # Set a bunch of useful options for a server
        ssocket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR,True)
        ssocket.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE,True)
        ssocket.setsockopt(socket.SOL_TCP, socket.TCP_KEEPCNT,30)
        ssocket.setsockopt(socket.SOL_TCP, socket.TCP_KEEPIDLE,60)
        ssocket.setsockopt(socket.SOL_TCP, socket.TCP_KEEPINTVL,60)
        
        ssocket.bind(("0.0.0.0", self.port))
        ssocket.listen(10)

        # Get te connection to the clients
        try:
            self._wait_connections_from_clients(ssocket)
        finally:
            ssocket.close()

    def __recv_data(self, s, size):
        data = ""
        received = 0
        while received < size:
            tmp = s.recv(size - received)
            if tmp == "":
                raise socket.error,(69,"Connection prematurely closed")
            data += tmp
            received = len(data)
        return data

    def __send_data(self, s, data):
        tosend = len(data)
        sent = 0
        while sent < tosend:
            tmp = s.send(data[sent:])
            sent += tmp
        return sent
            

    def _wait_connections_from_clients(self, server):
        """Wait until a slave and a quantum are correctly authenticated
    
        If two clients of the same type (slave or quantum) try to
        connect with a valid password, exit with an exception (because
        I would suspect that in this case the simulation is not
        configured correctly).

        The sockets for the qm and slave are saved in self.qm and
        self.slave."""
        while True:
            print "Waiting for a connection"
            (s, (source, port)) = server.accept()
            try:
                output = self.__recv_data(s, MAXPASS + 1)
            except socket.error:
                INFO("Client discarded ('%s' prematurely closed the connection)" % source)
                continue
                
            role = output[0]
            password = output[1:]
            if password != self.password:
                print "'%s'" % output
                print "'%s'" % self.password
                INFO("Client discarded from %s (wrong password)" % source)
                s.close()
                continue

            if role == "S":
                if self.slave != None:
                    raise RuntimeError, "Received 2 connections from 2 authenticated slaves (duplicated role?!)"
                self.slave = s
                INFO("Received valid connection from %s as slave role" % source)
                if self.qm != None:
                    break
            elif role == "Q":
                if self.qm != None:
                    raise RuntimeError, "Received 2 connections from 2 authenticated qm"
                self.qm = s
                INFO("Received valid connection from %s as quantum role" % source)
                if self.slave != None:
                    break
            else:
                INFO("Client discarded from %s (wrong role '%s')" % (source, role))
                s.close()
                continue
        INFO("Ready to start the simulation")


    def _init_client(self):
        """Initialize the connection to the server.

        The socket is saved in self.master."""
        self.master = socket.socket()
        try:
            self.master.connect((self.host, self.port))
        except socket.error:
            ERROR("Unable to connect to the server (%s:%d)" % (self.host, self.port))
            raise socket.error
        INFO("Connected")

        # Try to send the role and password
        if self.role == 1:
            self.__send_data(self.master, "S" + self.password)
        elif self.role == 2:
            self.__send_data(self.master, "Q" + self.password)
            
        INFO("Password and role sent")


    def __del__(self):
        if(self.slave):
            self.slave.close()
        if(self.qm):
            self.qm.close()
        if(self.master):
            self.master.close()
    
    def data_from(self, data, s):
        """Generic data receiver

        data is an empty array received from the C plugin that needs
        to be populated with the information received from the peer.

        Returns True on error or False on success"""
        # Assume that at least the size of the payload is received in one chunk
        sizeraw = s.recv(struct.calcsize("!i"))
        if(len(sizeraw) != struct.calcsize("!i")):
            raise RuntimeError, "Network error in data_from (size of payload not correcty received)"
        size = struct.unpack("!i", sizeraw)[0]
        received = 0
        while received < size:
            tmp = s.recv(size - received)
            if tmp == "":
                raise socket.error,(69,"Connection prematurely closed")
            data += array.array("b", tmp)
            received = len(data)
        return False

    def data_to(self, data, s):
        """Generic data sender

        The size of the data is sent first to allow the receiver to know the payload volume.

        Returns True on error or False on success"""
        # Assume that at least the size of the data is sent in one chunk (it's like 4 bytes...)
        size = struct.pack("!i", len(data))
        if(s.send(size) != struct.calcsize("!i")):
            raise RuntimeError, "Network error in data_to (size of payload not correcty sent)"
        tosend = len(data)
        sent = 0
        while sent < tosend:
            tmp = s.send(data[sent:])
            sent += tmp
        return False

    def master_to_slave(self, data):
        """Used in the master role to send data to the slave"""
        return self.data_to(data, self.slave)
  
    def master_to_qm(self, data):
        """Used in the master role to send data to the qm"""
        return self.data_to(data, self.qm)
  
    def slave_to_master(self, data):
        """Used in the slave role to send data to the master"""
        return self.data_to(data, self.master)
  
    def qm_to_master(self, data):
        """Used in the qm role to send data to the master"""
        return self.data_to(data, self.master)
  
    def qm_from_master(self, data):
        """Used in the qm role to receive data from the master"""
        return self.data_from(data, self.master)
  
    def master_from_qm(self, data):
        """Used in the master role to receive data from the qm"""
        return self.data_from(data, self.qm)
  
    def slave_from_master(self, data):
        """Used in the slave role to receive data from the master"""
        return self.data_from(data, self.master)
  
    def master_from_slave(self, data):
        """Used in the master role to receive data from the slave"""
        return self.data_from(data, self.slave)
  
