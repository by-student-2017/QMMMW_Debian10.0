//!
//! Copyright (C) 2011-2015 QMMMW group
//! This file is distributed under the terms of the
//! GNU General Public License version 3 (GNU-GPLv3).
//!
#ifndef MS2BASE_PYTHON_H
#define MS2BASE_PYTHON_H
#include <Python.h>
#include <stdlib.h>

// Note that each "receive" function reads the incoming data from the data itself
// the data is always passed to python as an array of signed chars
// (this allows for both symmetric calls and the ability to read data by
// reference)
//
// The recv functions also pass an empty array which is extended by
// python and copied back into the C data

int ms2base_python_master_init(int argc, char *argv[]);
int ms2base_python_slave_init(int argc, char *argv[]);
int ms2base_python_qm_init(int argc, char *argv[]);    

int ms2base_python_master_to_slave(void *data, size_t size);
int ms2base_python_slave_from_master(void *data);

int ms2base_python_master_to_qm(void *data, size_t size);
int ms2base_python_qm_from_master(void *data);

int ms2base_python_slave_to_master(void *data, size_t size);
int ms2base_python_master_from_slave(void *data);

int ms2base_python_qm_to_master(void *data, size_t size);
int ms2base_python_master_from_qm(void *data);

int ms2base_python_master_finalize(void);
int ms2base_python_slave_finalize(void);
int ms2base_python_qm_finalize(void);    

#endif
