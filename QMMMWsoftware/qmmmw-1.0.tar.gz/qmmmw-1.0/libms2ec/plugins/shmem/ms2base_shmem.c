//!
//! Copyright (C) 2011-2015 QMMMW group
//! This file is distributed under the terms of the
//! GNU General Public License version 3 (GNU-GPLv3).
//!
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <time.h>
#include <string.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <assert.h>
#include <errno.h>
#include <pthread.h>
#include <fcntl.h>

#include "ms2base_shmem.h"

// seconds between checks of the pthread_conds
#define TIMEOUT 1 

// FIXME: lousy macro programming
#define MSG(fmt,...)  { fprintf(stderr, "libms2base_shmem    info: " fmt "\n", __VA_ARGS__); } 
#define WARN(fmt,...) { fprintf(stderr, "libms2base_shmem Warning: " fmt "\n", __VA_ARGS__); } 
#define ERR(fmt,...)  { fprintf(stderr, "libms2base_shmem   ERROR: " fmt "\n", __VA_ARGS__); } 

typedef struct  {
  pthread_mutex_t mutex;    //  lock for the condition
  pthread_cond_t  cond;	    //  condition 
  pid_t  mpid, spid, qpid;  //  PID for the processes
  int    counter;	    //  counter to ensure that the synchronization is conserved
  int    sender;	    //  index of the sender   (0: master 1: slave 2: qe)
  int    receiver;	    //  index of the receiver (0: master 1: slave 2: qe)
  size_t tot_shm_size;	    //  total size of the allocated memory
  size_t max_msg_size;	    //  maximum size any message
  size_t msg_size;	    //  size of the current message
} ms2base_shmem_t;


const char *roles[3] = {"master", "slave", "quantum"};

// Maximum size of the shared memory string
#define MAXLEN 1000

// Shared memory handler name and file pointer
char __ms2base_shmem_name[MAXLEN + 1];
int   __ms2base_shmem_fd = -1;

// Memory reference
ms2base_shmem_t *__ms2base_shmem_header = NULL;
// Last seen size of shmem
size_t __ms2base_shmem_totsize = -1;

// Role of the current process
int myrole = -1;

void __ms2base_shmem_print_struct(void)
{
  fprintf(stderr, "DUMP START OF STRUCT DATA\n");
  fprintf(stderr, "DUMP  mpid         : %d\n", (int) (__ms2base_shmem_header->mpid)          );
  fprintf(stderr, "DUMP  spid         : %d\n", (int) (__ms2base_shmem_header->spid)          );
  fprintf(stderr, "DUMP  qpid         : %d\n", (int) (__ms2base_shmem_header->qpid)          );
  fprintf(stderr, "DUMP  counter      : %d\n", (int) (__ms2base_shmem_header->counter)      );
  fprintf(stderr, "DUMP  sender       : %d\n", (int) (__ms2base_shmem_header->sender)       );
  fprintf(stderr, "DUMP  receiver     : %d\n", (int) (__ms2base_shmem_header->receiver)     );
  fprintf(stderr, "DUMP  tot_shm_size : %d\n", (int) (__ms2base_shmem_header->tot_shm_size)  );
  fprintf(stderr, "DUMP  max_msg_size : %d\n", (int) (__ms2base_shmem_header->max_msg_size)  );
  fprintf(stderr, "DUMP  msg_size     : %d\n", (int) (__ms2base_shmem_header->msg_size)      );
	  
}

// Returns a memory size which exactly fits a page
size_t __ms2base_shmem_pages(size_t memsize)
{
  long int page = sysconf(_SC_PAGE_SIZE);
  if(memsize % page == 0)
    return memsize;
  return (memsize / page + 1) * page;
}

int __ms2base_shmem_deadprocesses(void)
{
  int res = 0;
  if(kill(__ms2base_shmem_header->mpid, 0)) {
    ERR("%s", "the master process died unexpectedly");
    res += 1;
  }
  if(kill(__ms2base_shmem_header->spid, 0)) {
    ERR("%s", "the slave process died unexpectedly");
    res += 1;
  }
  if(kill(__ms2base_shmem_header->qpid, 0)) {
    ERR("%s", "the quantum process died unexpectedly");
    res += 1;
  }
  return res!=0?1:0;
}

// Resize the shared memory in a way that the message can be at least msg_size
// Assumes a locked memory
int __ms2base_shmem_resize(size_t msg_size)
{
  int newsize;
  if(__ms2base_shmem_header->max_msg_size >= msg_size)
    return 0;
  
  // Get enough place for both the payload and the header
  newsize = __ms2base_shmem_pages(sizeof(ms2base_shmem_t) + msg_size);
  MSG("Resizing the shared memory to %dB", newsize);

  assert(newsize > __ms2base_shmem_totsize);

  if(ftruncate(__ms2base_shmem_fd, newsize) == -1) {
    ERR("unable to get enough shared memory  (%dB): %s", 
	newsize,
	strerror(errno));
    return 1;
  }

  __ms2base_shmem_totsize = newsize;
  if((__ms2base_shmem_header = (ms2base_shmem_t *) mmap(NULL, __ms2base_shmem_totsize, 
							PROT_READ | PROT_WRITE, 
							MAP_SHARED, __ms2base_shmem_fd, 0)) == MAP_FAILED) {
    int ign;
    ERR("unable to re-map the shared memory: %s", strerror(errno));
    return 1;
  }
  
  // Re-set some variables
  __ms2base_shmem_header-> tot_shm_size = __ms2base_shmem_totsize;
  __ms2base_shmem_header-> max_msg_size = __ms2base_shmem_totsize - sizeof(ms2base_shmem_t);
  //__ms2base_shmem_print_struct();
  return 0;
}

// sync the mapped memory with the shared one
// Assumes a locked memory
int __ms2base_shmem_adjust(void)
{
  int newsize;
  if(__ms2base_shmem_header-> tot_shm_size == __ms2base_shmem_totsize)
    return 0;
  
  // Get enough place for both the payload and the header
  MSG("Resizing the mapping to %dB", __ms2base_shmem_header-> tot_shm_size);

  __ms2base_shmem_totsize = __ms2base_shmem_header-> tot_shm_size;
  if((__ms2base_shmem_header = (ms2base_shmem_t *) mmap(NULL, __ms2base_shmem_totsize, 
							PROT_READ | PROT_WRITE, 
							MAP_SHARED, __ms2base_shmem_fd, 0)) == MAP_FAILED) {
    int ign;
    ERR("unable to re-map the shared memory: %s", strerror(errno));
    return 1;
  }
  
  // Re-set some variables
  __ms2base_shmem_header-> tot_shm_size = __ms2base_shmem_totsize;
  __ms2base_shmem_header-> max_msg_size = __ms2base_shmem_totsize - sizeof(ms2base_shmem_t);
  return 0;
}


int __ms2base_shmem_send_message(int recp, void *data, size_t size, int counter)
{
  //timewait cond happily provided by the manpages
  struct timeval now;
  struct timespec timeout;
  int retcode = 0;

  pthread_mutex_lock(&__ms2base_shmem_header->mutex);
  // MSG("Message to %d: %dB (%d %d)", recp, size, __ms2base_shmem_header->sender,__ms2base_shmem_header->receiver);
  // wait for the send/receive buffer to empty
  while((__ms2base_shmem_header->sender != -1) || (__ms2base_shmem_header->receiver != -1)) {
    // Get the "now" 
    gettimeofday(&now, NULL);
    timeout.tv_sec = now.tv_sec + TIMEOUT;
    timeout.tv_nsec = now.tv_usec * 1000;
    // wait
    //MSG("%s","timeout?0");
    retcode = pthread_cond_timedwait(&__ms2base_shmem_header->cond,
				     &__ms2base_shmem_header->mutex,
				     &timeout);
    //MSG("%s","timeout?1");
    // Ensure that all processes are still alive
    if(retcode == ETIMEDOUT) 
      if(__ms2base_shmem_deadprocesses()) {
	pthread_mutex_unlock(&__ms2base_shmem_header->mutex);
	return 1;
      }    
    //MSG("%s","timeout?2");
  }
  //MSG("%s","Ready to go!");

  // Check if there's enough space in the buffer, if not, extend
  if(__ms2base_shmem_resize(size)) {
    pthread_mutex_unlock(&__ms2base_shmem_header->mutex);
    return 1;
  }

  // Copy the data and set the structures
  memcpy(__ms2base_shmem_header + 1, data, size);
  __ms2base_shmem_header->msg_size = size;
  __ms2base_shmem_header->sender = myrole;
  __ms2base_shmem_header->receiver = recp;
  __ms2base_shmem_header->counter = counter;
  
  // Relinquish the lock
  pthread_cond_broadcast(&__ms2base_shmem_header->cond);
  pthread_mutex_unlock(&__ms2base_shmem_header->mutex);
  return 0;
}

int __ms2base_shmem_recv_message(int sender, void *data, int counter)
{
  //timewait cond happily provided by the manpages
  struct timeval now;
  struct timespec timeout;
  int retcode = 0;
  MSG("Message from %d", sender);
  // ++++++++++ MUTEX LOCK ++++++++++
  pthread_mutex_lock(&__ms2base_shmem_header->mutex);
    
  // wait until I'm the correct recipient or there's both a timeout and the death of a process
  while((__ms2base_shmem_header->sender != sender) || (__ms2base_shmem_header->receiver != myrole)) {
    // Get the "now" 
    gettimeofday(&now, NULL);
    timeout.tv_sec = now.tv_sec + TIMEOUT;
    timeout.tv_nsec = now.tv_usec * 1000;
    // wait
    retcode = pthread_cond_timedwait(&__ms2base_shmem_header->cond,
				     &__ms2base_shmem_header->mutex,
				     &timeout);
    // Ensure that all processes are still alive
    if(retcode == ETIMEDOUT) 
      if(__ms2base_shmem_deadprocesses()) {
	// ---------- MUTEX UN-LOCK ----------
	pthread_mutex_unlock(&__ms2base_shmem_header->mutex);
	return 1;
      }    
  }
  MSG("retcode = %d  shared->sender = %d shared->receiver = %d\n",
      retcode, __ms2base_shmem_header->sender, __ms2base_shmem_header->receiver);

  // Check that the counter is correct
  if(counter != __ms2base_shmem_header->counter) {
    ERR("counter mismatch on %s process in a message from the %s code", roles[myrole], roles[sender]);
    // ---------- MUTEX UN-LOCK ----------
    pthread_mutex_unlock(&__ms2base_shmem_header->mutex);
    return 1;
  }

  // Check that the memory is in sync with the shared one
  if(__ms2base_shmem_adjust()) {
    pthread_mutex_unlock(&__ms2base_shmem_header->mutex);
    return 1;
  }

  // Get the data
  memcpy(data, __ms2base_shmem_header + 1, __ms2base_shmem_header->msg_size);
  __ms2base_shmem_header->msg_size = 0;
  __ms2base_shmem_header->sender   = -1;
  __ms2base_shmem_header->receiver = -1;
  __ms2base_shmem_header->counter  = -1;

  // Relinquish the lock
  pthread_cond_broadcast(&__ms2base_shmem_header->cond);
  // ---------- MUTEX UN-LOCK ----------
  pthread_mutex_unlock(&__ms2base_shmem_header->mutex);
  return 0;
}

int __ms2base_shmem_master_wait_peers(void)
{
  WARN("%s", "waiting for peersZ");

  while((__ms2base_shmem_header->spid == 0) || (__ms2base_shmem_header->qpid == 0)) {
    //MSG("%s","A");
    //__ms2base_shmem_print_struct();
    //fprintf(stderr, "--------------------\n");
    pthread_cond_wait(&__ms2base_shmem_header->cond,
		      &__ms2base_shmem_header->mutex);
    //MSG("%s","B");
    //__ms2base_shmem_print_struct();
  }
  
  MSG("%s", "hooked with slave and qe processes");
  // -1 --> there are multiple slave/qe processes
  if(__ms2base_shmem_header->spid == -1) {
    ERR("%s", "mismatch with the slave process");
    return 1;
  }
  if(__ms2base_shmem_header->qpid == -1) {
    ERR("%s", "mismatch with the quantum process");
    return 1;
  }
  // are the processes still alive?
  if(kill(__ms2base_shmem_header->spid, 0)) {
    ERR("%s", "slave process died unexpectedly");
    return 1;
  }
  if(kill(__ms2base_shmem_header->qpid, 0)) {
    ERR("%s", "qm process died unexpectedly");
    return 1;
  }
  return 0;
}

int __ms2base_shmem_memory_init(void)
{
  pthread_mutexattr_t mutexattr;
  pthread_condattr_t condattr;
  
  if(__ms2base_shmem_fd != -1) {
    ERR("%s", "unable to initialize the module: not correctly finalized!");
    return 1;
  }
  
  // Regardless what the situation is, try to unlink any pre-existing handler
  if(!shm_unlink(__ms2base_shmem_name))
    WARN("unlinked a pre-existing '%s' shm handler", __ms2base_shmem_name);


  __ms2base_shmem_fd = shm_open(__ms2base_shmem_name, 
				     O_RDWR | O_CREAT | O_TRUNC, S_IRWXU);
  if(__ms2base_shmem_fd == -1) {
    ERR("unable to open the shared memory handler '%s': %s", __ms2base_shmem_name, strerror(errno));
    return 1;
  }
  
  MSG("'%s' shm handler opened",  __ms2base_shmem_name);

  // Allocate enough space for the shmem structure and message: payload starts as 0
  __ms2base_shmem_totsize = __ms2base_shmem_pages(sizeof(ms2base_shmem_t));
  if(ftruncate(__ms2base_shmem_fd, __ms2base_shmem_totsize) == -1) {
    ERR("unable to get enough shared memory: %s", strerror(errno));
    close(__ms2base_shmem_fd);
    unlink(__ms2base_shmem_name);
    return 1;
  }

  // Map the shared memory file to memory
  if((__ms2base_shmem_header = (ms2base_shmem_t *) mmap(NULL, __ms2base_shmem_totsize, 
							PROT_READ | PROT_WRITE, 
							MAP_SHARED, __ms2base_shmem_fd, 0)) == MAP_FAILED) {
    int ign;
    ERR("unable to map the shared memory: %s", strerror(errno));
    ign = ftruncate(__ms2base_shmem_fd, 0);
    close(__ms2base_shmem_fd);
    unlink(__ms2base_shmem_name);
    return 1;
  }

  // Initialize the mutex
  pthread_mutexattr_init(&mutexattr);
  pthread_mutexattr_setpshared(&mutexattr, PTHREAD_PROCESS_SHARED);
  pthread_mutex_init(&__ms2base_shmem_header->mutex, 
		     &mutexattr);

  //Create the cond object
  pthread_condattr_init(&condattr);
  pthread_condattr_setpshared(&condattr, PTHREAD_PROCESS_SHARED);
  pthread_cond_init(&__ms2base_shmem_header->cond, &condattr);
  // Initialize the other structures
  __ms2base_shmem_header-> mpid           = getpid();
  __ms2base_shmem_header-> spid           = 0;
  __ms2base_shmem_header-> qpid           = 0;
  __ms2base_shmem_header-> counter        = -1;
  __ms2base_shmem_header-> sender         = -1;
  __ms2base_shmem_header-> receiver       = -1;
  __ms2base_shmem_header-> tot_shm_size = __ms2base_shmem_totsize;
  __ms2base_shmem_header-> max_msg_size   = __ms2base_shmem_totsize - sizeof(ms2base_shmem_t);
  __ms2base_shmem_header-> msg_size  = -1;
  // the message starts exactly at the end of this struct

  // This signals a 1 only if a peer dies while I'm waiting
  if(__ms2base_shmem_master_wait_peers()) {
    int ign = ftruncate(__ms2base_shmem_fd, 0);
    close(__ms2base_shmem_fd);
    unlink(__ms2base_shmem_name);
    return 1;
  }

  // ---------- MUTEX UN-LOCK ----------
  pthread_mutex_unlock(&__ms2base_shmem_header->mutex);

  return 0;
}

// role can be 0 for slave 1 for qm
int __ms2base_shmem_hook_to_mem(int role)
{
  if(__ms2base_shmem_fd != -1) {
    ERR("%s", "unable to init the module (not finalized) !");
    return 1;
  }

  __ms2base_shmem_totsize = __ms2base_shmem_pages(sizeof(ms2base_shmem_t));

  // Open the handler if it exists already
  __ms2base_shmem_fd = shm_open(__ms2base_shmem_name, O_RDWR, 0700);
  if(__ms2base_shmem_fd == -1) {
    ERR("unable to open '%s': %s", __ms2base_shmem_name, strerror(errno));
    return 1;
  }
  MSG("%s opened", __ms2base_shmem_name);

  // Map the memory
  if((__ms2base_shmem_header = (ms2base_shmem_t *) mmap(NULL, __ms2base_shmem_totsize, 
							PROT_READ | PROT_WRITE,
							MAP_SHARED, __ms2base_shmem_fd, 0)) == MAP_FAILED) {
    ERR("unable to map the memory: %s", strerror(errno));
    close(__ms2base_shmem_fd);
  }
  MSG("%s", "memory mapped");

  // Check if the master exists. This is also a check for the shared memory
  if(kill(__ms2base_shmem_header->mpid, 0)) {
    ERR("the master (pid: %d) is not running", __ms2base_shmem_header->mpid);
    munmap(__ms2base_shmem_header, __ms2base_shmem_totsize);
    close(__ms2base_shmem_fd);
    return 1;
  }
  MSG("%s", "master process still alive");

  // Set the pid for the slave and qm

  // ++++++++++ MUTEX LOCK ++++++++++
  pthread_mutex_lock(&__ms2base_shmem_header->mutex);

  // Save the last seen size
  __ms2base_shmem_totsize = __ms2base_shmem_header-> tot_shm_size;
  switch(role) {
  case 0:
    MSG("%s", "setting the pid");
    // Check if some other process hooked with the master, if so, we
    // are in trouble and should let the master know
    if(__ms2base_shmem_header->spid != 0)
      __ms2base_shmem_header->spid = -1;
    else 
      __ms2base_shmem_header->spid = getpid();
    pthread_cond_broadcast(&__ms2base_shmem_header->cond);
    MSG("done (%d)", __ms2base_shmem_header->spid);
    break;
  case 1:
    // Check if some other process hooked with the master, if so, we
    // are in trouble and should let the master know
    if(__ms2base_shmem_header->qpid != 0)
      __ms2base_shmem_header->qpid = -1;
    else
      __ms2base_shmem_header->qpid = getpid();
    pthread_cond_broadcast(&__ms2base_shmem_header->cond);
    MSG("done (%d)", __ms2base_shmem_header->qpid);
    break;
  }
  // ---------- MUTEX UN-LOCK ----------
  pthread_mutex_unlock(&__ms2base_shmem_header->mutex);
  
  MSG("%s", "Initialization terminated!");
  return 0;
}


int __ms2base_shmem_mangle_args(int argc, char *argv[])
{
  void *tmp;
  if(argc !=1) {
    ERR("The 'shmem' plugin expects only one argument (%d received)!\n", argc);
    return 1;
  }

  if(strlen(argv[0]) >= MAXLEN) {
    ERR("%s", "Shared memory handler too long!\n");
    return 1;    
  }
  
  strncpy(__ms2base_shmem_name, argv[0], MAXLEN);

  return 0;
}

/* 
   INITIALIZATION FUNCTIONS
*/
int ms2base_shmem_master_init(int argc, char *argv[])
{
  myrole = 0;
  if(__ms2base_shmem_mangle_args(argc, argv))
    return 1;
  
  if(__ms2base_shmem_memory_init())
    return 1;
  return 0;
}

int ms2base_shmem_slave_init(int argc, char *argv[])
{
  myrole = 1;
  if(__ms2base_shmem_mangle_args(argc, argv))
    return 1;

  if(__ms2base_shmem_hook_to_mem(0))
    return 1;
  
  return 0;
}

int ms2base_shmem_qm_init(int argc, char *argv[])
{
  myrole = 2;
  if(__ms2base_shmem_mangle_args(argc, argv))
    return 1;

  if(__ms2base_shmem_hook_to_mem(1))
    return 1;

  return 0;
}

/* 
   TRANSMISSION FUNCTIONS
*/
int ms2base_shmem_master_to_slave(void *data, size_t size)  { static int counter = 0; return __ms2base_shmem_send_message(1, data, size, counter++);}
int ms2base_shmem_master_to_qm(void *data, size_t size)     { static int counter = 0; return __ms2base_shmem_send_message(2, data, size, counter++);}
int ms2base_shmem_slave_to_master(void *data, size_t size)  { static int counter = 0; return __ms2base_shmem_send_message(0, data, size, counter++);}
int ms2base_shmem_qm_to_master(void *data, size_t size)     { static int counter = 0; return __ms2base_shmem_send_message(0, data, size, counter++);}

int ms2base_shmem_slave_from_master(void *data)             { static int counter = 0; return __ms2base_shmem_recv_message(0, data, counter++);}
int ms2base_shmem_qm_from_master(void *data) 		    { static int counter = 0; return __ms2base_shmem_recv_message(0, data, counter++);}
int ms2base_shmem_master_from_slave(void *data) 	    { static int counter = 0; return __ms2base_shmem_recv_message(1, data, counter++);}
int ms2base_shmem_master_from_qm(void *data)                { static int counter = 0; return __ms2base_shmem_recv_message(2, data, counter++);}

/* 
   FINALIZATION FUNCTIONS
*/

void __ms2base_shmem_finalize(void)
{
  int res;
  
  __ms2base_shmem_name[0] = 0;

  if(__ms2base_shmem_header != NULL) {
    munmap(__ms2base_shmem_header, __ms2base_shmem_totsize);
    __ms2base_shmem_header = NULL;
  }
  __ms2base_shmem_totsize = -1;

  if(__ms2base_shmem_fd != -1) {
    res = ftruncate(__ms2base_shmem_fd, 0);
    close(__ms2base_shmem_fd);
    __ms2base_shmem_fd = -1;
  }
}

int ms2base_shmem_master_finalize(void)
{
  __ms2base_shmem_finalize();
  shm_unlink(__ms2base_shmem_name);
  return 0;
}

int ms2base_shmem_slave_finalize(void)
{
  shm_unlink(__ms2base_shmem_name);
  return 0;
}

int ms2base_shmem_qm_finalize(void)
{
  shm_unlink(__ms2base_shmem_name);
  return 0;
}
