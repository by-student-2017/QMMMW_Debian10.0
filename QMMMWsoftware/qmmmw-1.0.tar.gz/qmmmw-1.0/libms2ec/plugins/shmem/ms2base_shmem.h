//!
//! Copyright (C) 2011-2015 QMMMW group
//! This file is distributed under the terms of the
//! GNU General Public License version 3 (GNU-GPLv3).
//!
#ifndef MS2BASE_SHMEM_H
#define MS2BASE_SHMEM_H


int ms2base_shmem_master_init(int argc, char ** argv);
int ms2base_shmem_slave_init(int argc, char ** argv);
int ms2base_shmem_qm_init(int argc, char ** argv);    

int ms2base_shmem_master_to_slave(void *data, size_t size);
int ms2base_shmem_slave_from_master(void *data);
int ms2base_shmem_master_to_qm(void *data, size_t size);
int ms2base_shmem_qm_from_master(void *data);
int ms2base_shmem_slave_to_master(void *data, size_t size);
int ms2base_shmem_master_from_slave(void *data);
int ms2base_shmem_qm_to_master(void *data, size_t size);
int ms2base_shmem_master_from_qm(void *data);

int ms2base_shmem_master_finalize(void);
int ms2base_shmem_slave_finalize(void);
int ms2base_shmem_qm_finalize(void);    

#endif
