//!
//! Copyright (C) 2011-2015 QMMMW group
//! This file is distributed under the terms of the
//! GNU General Public License version 3 (GNU-GPLv3).
//!
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>
#include <unistd.h>
#include <assert.h>
#include "ms2base_file.h"

// Maximum size of a string
#define MAXLEN 1000

// Basenames for the files used to exchange the data
#define MASTER2SLAVE "m2s.dat"
#define MASTER2QM "m2q.dat"
#define QM2MASTER "q2m.dat"
#define SLAVE2MASTER "s2m.dat"
// Temporary files to write the messages
#define MASTERTMP "mtmp.dat"
#define SLAVETMP  "stmp.dat"
#define QMTMP     "qtmp.dat"

// Base directory
char *__ms2file_dirname = NULL;

// Check for files every CHECKINT microseconds
#define CHECKINT 100000

/** 
    Wait until a specific file appears.

    Check every CHECKINT microseconds
*/
FILE *wait_file(char *name)
{
  FILE *f;
  int start = 1;
  while(1) {
    f = fopen(name, "r");
    if(f)
      // FIXE Perhaps there should be other checks (e.g. access permissions)...
      return f;
    if(start) { 
      start = 0;
      fprintf(stderr, __FILE__":%d waiting for %s\n", __LINE__, name);
    }
    usleep(CHECKINT);
  }
}

/** 
    Wait until a specific file disappears.

    Check every CHECKINT microseconds
*/
void wait_nofile(char *name)
{
  FILE *f;
  int start = 1;
  while(1) {
    f = fopen(name, "r");
    if(f != NULL)
      fclose(f);
    else
      return;
    if(start) {
      fprintf(stderr, __FILE__":%d waiting for %s to disappear\n", __LINE__, name);
      start = 0;
    }

    usleep(CHECKINT);
  }
}

int __ms2base_file_send_message(char *filename, void *data, size_t size, int counter)
{
  char pwd[1024];
  int error = 0;
  char err[1024];
  char *tmppath;
  FILE *f;
  
  // Save the starting directory
  if(getcwd(pwd, 1024) == NULL) {
    perror("Unable to get the current working directory!");
    return 1;
  }

  // Change to the new one
  if(chdir(__ms2file_dirname)) {
    snprintf(err, 1024, "unable to change to '%s' to write a file: ", __ms2file_dirname);
    perror(err);
    return 1;
  }
  
  // Wait until the specific file disappears
  wait_nofile(filename);

  // Dump the output in a temporary location
  tmppath = tempnam(NULL, NULL);
  f = fopen(tmppath, "w");
  if(f == NULL) {
    error = 1;
    snprintf(err, 1024, "unable to create '%s': ", tmppath);
    perror(err);
  } else {
    if(fwrite(&size, sizeof(size_t), 1, f) != 1) { 
      // Write the size of the message first
      error = 1;
      perror("unable to write the size of the message:");
    } else if(fwrite(&counter, sizeof(int), 1, f) != 1) {
      // And then counter
      error = 1;
      perror("unable to write the counter:");
    } else if(fwrite(data, size, 1, f) != 1) {
      // And then the content
      error = 1;
      perror("unable to write the message:");
    }
    fclose(f);    
  }
  // Rename the location
  if(rename(tmppath, filename)) {
    error = 1;
    snprintf(err, 1024, "unable to create '%s': ", filename, __ms2file_dirname);
    perror(err);
  }
  free(tmppath);

  // Revert to the old directory, regardless if there was an error
  if(chdir(pwd)) {
    snprintf(err, 1024, "unable to revert to '%s': ", pwd);
    perror(err);
    return 1;
  }

  return error;
} 

int __ms2base_file_recv_message(char *filename, void *data, int counter)
{
  char pwd[1024];
  int error = 0;
  char err[1024];
  FILE *f;
  size_t size;
  int mycounter;
  
  // Save the starting directory
  if(getcwd(pwd, 1024) == NULL) {
    perror("Unable to get the current working directory!");
    return 1;
  }

  // Change to the new one
  if(chdir(__ms2file_dirname)) {
    snprintf(err, 1024, "unable to change to '%s' to write a file: ", __ms2file_dirname);
    perror(err);
    return 1;
  }

  // Wait until the specific file appears. This call might fail without report...
  f = wait_file(filename);
  if(fread(&size, sizeof(size_t), 1, f) != 1) { 
    // Read the size of the message first
    error = 1;
    perror("unable to read the size of the message:");
  } if(fread(&mycounter, sizeof(int), 1, f) != 1) {
    // Read the counter
    error = 1;
    perror("unable to read the counter:");
  } else if(counter != mycounter) {
    error = 1;
    fprintf(stderr, "counters differs (%d vs %d): message mismatch!\n", counter, mycounter);
  } else if(fread(data, size, 1, f) != 1) {
    // And then the content
    error = 1;
    perror("unable to read the message:");
  }
  fclose(f);    
  unlink(filename);

  // Revert to the old directory, regardless if there was an error
  if(chdir(pwd)) {
    char *err;
    snprintf(err, 1024, "unable to revert to '%s': ", pwd);
    perror(err);
    return 1;
  }

  return error;
} 

/**
   Remove all relevant files in the directory
*/
int  __ms2base_file_clean_dir(void)
{
  char pwd[1024];
  char err[1024];
  
  // Save the starting directory
  if(getcwd(pwd, 1024) == NULL) {
    perror("Unable to get the current working directory!");
    return 1;
  }

  // Change to the new one
  if(chdir(__ms2file_dirname)) {
    asprintf(&err, "unable to change to '%s' to write a file: ", __ms2file_dirname);
    perror(err);
    return 1;
  }

  unlink("m2s.dat");
  unlink("m2q.dat");
  unlink("q2m.dat");
  unlink("s2m.dat");

  // Revert to the old directory, regardless if there was an error
  if(chdir(pwd)) {
    snprintf(err, 1024, "unable to revert to '%s': ", pwd);
    perror(err);
    return 1;
  }
  
  return 0;
}

int __ms2base_file_mangle_args(int argc, char *argv[])
{
  void *tmp;
  if(argc !=1) {
    fprintf(stderr, "Wrong number of arguments for the 'file' plugin: only a dirname is expected!\n");
    return 1;
  }

  if(strlen(argv[0]) >= MAXLEN) {
    fprintf(stderr, "Directory name too long!\n");
    return 1;    
  }
  
  tmp = calloc(MAXLEN, sizeof(char));
  __ms2file_dirname = (char *) tmp;
  if(__ms2file_dirname == NULL) {
    perror("Unable to copy the directory name: ");
    return 1;    
  }

  strncpy(__ms2file_dirname, argv[0], MAXLEN);

  return 0;
}

/* 
   INITIALIZATION FUNCTIONS
*/
int ms2base_file_master_init(int argc, char *argv[])
{
  if(__ms2base_file_mangle_args(argc, argv))
    return 1;
  __ms2base_file_clean_dir();
  
  return 0;
}

int ms2base_file_slave_init(int argc, char *argv[])
{
  if(__ms2base_file_mangle_args(argc, argv))
    return 1;

  return 0;
}

int ms2base_file_qm_init(int argc, char *argv[])
{
  if(__ms2base_file_mangle_args(argc, argv))
    return 1;

  return 0;
}

/* 
   TRANSMISSION FUNCTIONS
*/
int ms2base_file_master_to_slave(void *data, size_t size)  { static int counter = 0; return __ms2base_file_send_message(MASTER2SLAVE, data, size, counter++); }
int ms2base_file_master_to_qm(void *data, size_t size)     { static int counter = 0; return __ms2base_file_send_message(MASTER2QM   , data, size, counter++); }
int ms2base_file_slave_to_master(void *data, size_t size)  { static int counter = 0; return __ms2base_file_send_message(SLAVE2MASTER, data, size, counter++); }
int ms2base_file_qm_to_master(void *data, size_t size)     { static int counter = 0; return __ms2base_file_send_message(QM2MASTER   , data, size, counter++); }
int ms2base_file_slave_from_master(void *data)             { static int counter = 0; return __ms2base_file_recv_message(MASTER2SLAVE, data, counter++); }
int ms2base_file_qm_from_master(void *data) 		   { static int counter = 0; return __ms2base_file_recv_message(MASTER2QM   , data, counter++); }
int ms2base_file_master_from_slave(void *data) 	           { static int counter = 0; return __ms2base_file_recv_message(SLAVE2MASTER, data, counter++); }
int ms2base_file_master_from_qm(void *data)                { static int counter = 0; return __ms2base_file_recv_message(QM2MASTER   , data, counter++); } 

/* 
   FINALIZATION FUNCTIONS
*/
int ms2base_file_master_finalize(void)
{
  free(__ms2file_dirname);
  return 0;
}

int ms2base_file_slave_finalize(void)
{
  free(__ms2file_dirname);
  return 0;
}

int ms2base_file_qm_finalize(void)
{
  free(__ms2file_dirname);
  return 0;
}
