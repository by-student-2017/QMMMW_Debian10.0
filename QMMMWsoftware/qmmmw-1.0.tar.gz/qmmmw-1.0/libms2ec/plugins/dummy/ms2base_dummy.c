//!
//! Copyright (C) 2011-2015 QMMMW group
//! This file is distributed under the terms of the
//! GNU General Public License version 3 (GNU-GPLv3).
//!
#include "ms2base_dummy.h"
#include <stdio.h>

int ms2base_dummy_master_init(int argc, char *argv[])
{
  int i;
  for(i=0;i<argc;i++)
    fprintf(stderr, "DUMMY arg %d -> %s\n", i, argv[i]);
  exit(0);
  return 0;
}

int ms2base_dummy_slave_init(int argc, char *argv[])
{
  int i;
  for(i=0;i<argc;i++)
    fprintf(stderr, "DUMMY arg %d -> %s\n", i, argv[i]);
  exit(0);
  return 0;
}

int ms2base_dummy_qm_init(int argc, char *argv[])
{
  return 0;
}


int ms2base_dummy_master_pass_data(void *data, size_t size)
{
  return 0;
}

int ms2base_dummy_slave_receive_data(void *data)
{
  return 0;
}

int ms2base_dummy_qm_receive_data(void *data)
{
  return 0;
}

int ms2base_dummy_master_receive_results(void *sdata, void *qdata)
{
  return 0;
}


int ms2base_dummy_slave_send_results(void *data, size_t size)
{
  return 0;
}

int ms2base_dummy_qm_send_results(void *data, size_t size)
{
  return 0;
}


int ms2base_dummy_master_finalize(void)
{
  return 0;
}

int ms2base_dummy_slave_finalize(void)
{
  return 0;
}

int ms2base_dummy_qm_finalize(void)
{
  return 0;
}
