//!
//! Copyright (C) 2011-2015 QMMMW group
//! This file is distributed under the terms of the
//! GNU General Public License version 3 (GNU-GPLv3).
//!
#ifndef MS2BASE_DUMMY_H
#define MS2BASE_DUMMY_H
#include <stdlib.h>


    int ms2base_dummy_master_init(int argc, char ** argv);
    int ms2base_dummy_slave_init(int argc, char ** argv);
    int ms2base_dummy_qm_init(int argc, char ** argv);    

    int ms2base_dummy_master_pass_data(void *data, size_t size);
    int ms2base_dummy_slave_receive_data(void *data);
    int ms2base_dummy_qm_receive_data(void *data);    

    int ms2base_dummy_slave_send_results(void *data, size_t size);
    int ms2base_dummy_qm_send_results(void *data, size_t size);
    int ms2base_dummy_master_receive_results(void *slave_data, void *qm_data);

    int ms2base_dummy_master_finalize(void);
    int ms2base_dummy_slave_finalize(void);
    int ms2base_dummy_qm_finalize(void);    

#endif
