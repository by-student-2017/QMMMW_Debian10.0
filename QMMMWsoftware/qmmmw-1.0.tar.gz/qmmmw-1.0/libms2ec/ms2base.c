//!
//! Copyright (C) 2011-2015 QMMMW group
//! This file is distributed under the terms of the
//! GNU General Public License version 3 (GNU-GPLv3).
//!
#include "ms2base.h"
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <dlfcn.h>

  typedef struct {
    void *libhandle;

    int (*master_init)(int, char **);
    int (*slave_init)(int, char **);
    int (*qm_init)(int, char **);

        
    int (*master_to_slave)(void *, size_t size);
    int (*slave_from_master)(void *);

    int (*master_to_qm)(void *, size_t size);
    int (*qm_from_master)(void *);

    int (*slave_to_master)(void *, size_t size);
    int (*master_from_slave)(void *);

    int (*qm_to_master)(void *, size_t size);
    int (*master_from_qm)(void *);
    

    int (*master_finalize)(void);
    int (*slave_finalize)(void);
    int (*qm_finalize)(void);    
  } ms2base_transport;

// The current module employed
ms2base_transport *current_module = NULL;

// Clean the content of the ms2base_transport structure without deallocating it
void __ms2base_clean_module(void)
{
  dlclose(current_module->libhandle);
  current_module->libhandle = NULL;

  current_module->master_init = NULL;
  current_module->slave_init = NULL;
  current_module->qm_init = NULL;
    
  current_module->master_to_slave = NULL;
  current_module->slave_from_master = NULL;

  current_module->master_to_qm = NULL;
  current_module->qm_from_master = NULL;

  current_module->slave_to_master = NULL;
  current_module->master_from_slave = NULL;

  current_module->qm_to_master = NULL;
  current_module->master_from_qm = NULL;

  current_module->master_finalize = NULL;
  current_module->slave_finalize = NULL;
  current_module->qm_finalize = NULL;
}

#define GET_SYMBOL(NAME)                                                        \
  snprintf(call_name, 60, "ms2base_%s_" # NAME, modulename);                    \
  current_module->NAME = dlsym(lib, call_name);                                 \
  if(!current_module->NAME) {                                                   \
    char *error = dlerror();                                                    \
    fprintf(stderr, "Unable to get the symbol for '" # NAME"': %s\n", error);   \
    return 1;                                                                   \
  }                                                                             \

/** 
    Search for a module with a name libms2base_<something>.so
    
    The size of "something" is limited to 20 chars

    The library is then searched for calls in the form:

    ms2base_<something>_call_names

    type is 0 for the master, 1 for the slave and 2 for qm
*/
int __ms2base_search_module(char *modulename)
{
  char library_name[31];
  char call_name[60];
  void *lib;

  if(strlen(modulename) > 20) {
    fprintf(stderr, "Module name '%s' is too long (max 20 chars. allowed)\n", modulename);
    return 1;
  }

  snprintf(library_name, 31, "libms2base_%s.so", modulename);
  lib = dlopen(library_name, RTLD_NOW | RTLD_GLOBAL);
  if(!lib) {
    fprintf(stderr, "%s", dlerror());
    return 1;
  }

  // Get the structure where pointers will be saved
  if(current_module) 
    __ms2base_clean_module();
  else {
    current_module = (ms2base_transport *) calloc(1, sizeof(ms2base_transport));
    if(!current_module) {
      fprintf(stderr, "Error initializing the module: allocation error\n");    
      return 1;
    }
  }
  // Save the handle
  current_module->libhandle = lib;

  // Get all handles: initialization
  GET_SYMBOL(master_init);
  GET_SYMBOL(slave_init);
  GET_SYMBOL(qm_init);

  GET_SYMBOL(master_to_slave);
  GET_SYMBOL(slave_from_master);

  GET_SYMBOL(master_to_qm);
  GET_SYMBOL(qm_from_master);

  GET_SYMBOL(slave_to_master);
  GET_SYMBOL(master_from_slave);

  GET_SYMBOL(qm_to_master);
  GET_SYMBOL(master_from_qm);

  GET_SYMBOL(master_finalize);
  GET_SYMBOL(slave_finalize);
  GET_SYMBOL(qm_finalize);
  
  return 0;
}
#undef GET_SYMBOL

#define INIT_FUNCTION(NAME)                                        \
  int ms2base_##NAME(char *module_name, int argc, char *argv[])    \
  {                                                                \ 
    if(__ms2base_search_module(module_name)) {                     \
      return 1;                                                    \
    }                                                              \
    return (current_module->NAME)(argc, argv);                     \
  }                                                                \

#define TO_FUNCTION(NAME)                        \
  int ms2base_##NAME(void *data, size_t size)    \
  {                                              \
    return (current_module->NAME)(data, size);   \
  }                                              \

#define FROM_FUNCTION(NAME)                      \
  int ms2base_##NAME(void *data)                 \
  {                                              \
    return (current_module->NAME)(data);         \
  }                                              \

#define FINALIZE_FUNCTION(NAME)                  \
  int ms2base_##NAME(void)                       \
  {                                              \
    return (current_module->NAME)();             \
  }                                              \


// Initialization
INIT_FUNCTION(master_init)
INIT_FUNCTION(slave_init)
INIT_FUNCTION(qm_init)
#undef INIT_FUNCTION

TO_FUNCTION(master_to_slave)
TO_FUNCTION(slave_to_master)
TO_FUNCTION(master_to_qm)
TO_FUNCTION(qm_to_master)
#undef TO_FUNCTION

FROM_FUNCTION(slave_from_master)
FROM_FUNCTION(master_from_slave)
FROM_FUNCTION(qm_from_master)
FROM_FUNCTION(master_from_qm)
#undef FROM_FUNCTION

// Finalization
FINALIZE_FUNCTION(master_finalize);
FINALIZE_FUNCTION(slave_finalize);
FINALIZE_FUNCTION(qm_finalize);
#undef FINALIZE_FUNCTION

//Shortcuts
void ms2base_master_to_peers(void *data, size_t size, 
			     int *res_s, int *res_q)
{
  *res_s = ms2base_master_to_slave(data, size);
  *res_q = ms2base_master_to_qm(data, size);
}

void ms2base_master_from_peers(void *data,
			       int *res_s, int *res_q)
{
  *res_s = ms2base_master_from_slave(data);
  *res_q = ms2base_master_from_qm(data);
}
