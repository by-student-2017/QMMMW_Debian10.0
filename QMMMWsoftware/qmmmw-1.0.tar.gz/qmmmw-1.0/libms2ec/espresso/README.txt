This directory contains the files required for the integration of
Quantum ESPRESSo and the MS2 project.

The content of the file ecfunctions.f90 has been entirely contributed
by C.Ma and S.Piccinin, with minor changes by me for the sake of
integration.
