//!
//! Copyright (C) 2011-2015 QMMMW group
//! This file is distributed under the terms of the
//! GNU General Public License version 3 (GNU-GPLv3).
//!
#ifndef MS2EC_CALLS_H
#define MS2EC_CALLS_H

#ifdef __cplusplus
extern "C" {
#endif 

  /** initialize the master LAMMPS
      argc is the number of arguments following the "master" label
      argv is an array of arguments (the ones following "master")
           it is *NOT* guaranteed that the memory will remain accessible after 
	   the initialize call is terminated, therefore a module should make a 
	   local copy of the arguments, if needed
      natoms is the total number of atoms
      types is a natoms long array selecting the atoms in the QE subsystem
      charges and Z are self-explanatory
      celldata is a 9 cell array which packs the lo/hi and tilt data about the cell
  */
  int ms2ec_master_initialize(int argc, char *argv[], 
			      int natoms, int *types,
			      double *charges,
			      int *atom_Z, const double *celldata);

  /** initialize the slave LAMMPS
      argc is the number of arguments following the "master" label
      argv is an array of arguments (the ones following "master")
           it is *NOT* guaranteed that the memory will remain accessible after 
	   the initialize call is terminated, therefore a module should make a 
	   local copy of the arguments, if needed
      natoms is the number of atoms in the QM subsystem
  */
  int ms2ec_slave_initialize(int argc, char *argv[], 
			   int natoms);
 
  /** initialize the "fake-qe" LAMMPS (for testing only)
      argc is the number of arguments following the "master" label
      argv is an array of arguments (the ones following "master")
           it is *NOT* guaranteed that the memory will remain accessible after 
	   the initialize call is terminated, therefore a module should make a 
	   local copy of the arguments, if needed
      qatoms is the number of atoms in the QM subsystem

      The remaining parameters are INPUT ones (they are required by the QM simulation):

      totatoms       the total number of atoms in the system
      mask           the mask with the selected atoms in the QM subsystem
      allcharges     the charge of all atoms

      This call is actually fully functional and could be integrated
      with QM code, the next one is however used to avoid the pain of
      building an array of strings in Fortran from Quantum ESPRESSO
  */
  int ms2ec_qm_initialize(int argc, char *argv[], 
			  int qatoms, 
			  int *totatoms, int **mask, double **allcharges, double **atomic_radii, double **celldata);

  /** Same as above, but performing the argument splitting manually.

      It works exactly as the ms2_qm_initialize call above, with the
      only exception it passes a single string with all arguments.

      The strings are splitted in a very straightforward way, with the
      C strtok function. As for the 'common' initialization routines,
      args is not guaranteed to be persistent.
  */
  int ms2ec_qm_initialize_simplified(char *args, int qatoms,
				     int *totatoms, int **mask, double **allcharges, double **atomic_radii, double **celldata);


  /*************************************************************************************************/

  /** Send the positions to the slave and qe processes  */
  int ms2ec_master_send_positions(double *pos);
  
  /** Receive the positions from the master process */
  int ms2ec_slave_recv_positions(double *pos);
  
  /** Receive the positions from the master process */
  int ms2ec_qm_recv_positions(double *pos);
  
  /** Save the forces */
  int ms2ec_slave_send_forces(double *forces);
  
  /** Save the forces */
  int ms2ec_qm_send_forces(double *forces);
  
  /** Retrieve the forces  */
  int ms2ec_master_recv_forces(double *forces);


  int ms2ec_master_finalize(void);
  int ms2ec_slave_finalize(void);
  int ms2ec_qm_finalize(void);
  
#ifdef __cplusplus
}
#endif 

#endif
