//!
//! Copyright (C) 2011-2015 QMMMW group
//! This file is distributed under the terms of the
//! GNU General Public License version 3 (GNU-GPLv3).
//!
#ifndef MS2BASE_H
#define MS2BASE_H
#include <stdlib.h>
/** 
    This module acts as an interface to the communication moudules: it
    loads a specific module, gets all required symbols from it and
    makes them available for ms2ec calls.

    A transport module should just provide the calls below to be
    eligible for MS2 integration.
*/

/** 
    Initialization functions

    Called once at the start of each subprogram. 

    The argv memory is *not* supposed to be persistent: the receiver
    should make a copy of it, if required.  

*/
int ms2base_master_init(char *module_name,
			int argc, char *argv[]);
int ms2base_slave_init(char *module_name,
		       int argc, char *argv[]);
int ms2base_qm_init(char *module_name,
		    int argc, char *argv[]);

/** 

    Send functions

    The data array might be a reference of the original data in the
    programs.
*/
int ms2base_master_to_slave(void *data, size_t size);
int ms2base_master_to_qm(void *data, size_t size);
int ms2base_slave_to_master(void *data, size_t size);
int ms2base_qm_to_master(void *data, size_t size);

/** 
    Receive functions.

    The size of the data received should be known by the transport
    module by analyzying the traffic (i.e. the transport can write the
    size of the message as the first 4 bytes in the code).

    The data pointer should be already allocated by the caller..

*/
int ms2base_master_from_slave(void *data);
int ms2base_master_from_qm(void *data);
int ms2base_slave_from_master(void *data);
int ms2base_qm_from_master(void *data);

/** 

    Shortcuts to common combinations of the previous functions.

    The slave function is executed first in the master.

*/
void ms2base_master_to_peers(void *data, size_t size, int *res_s, int *res_q);
void ms2base_master_from_peers(void *data, int *res_s, int *res_q);

/* 
   Last (possibly unused) step: finalization

   May be called at most once by each process.
*/
int ms2base_master_finalize(void);
int ms2base_slave_finalize(void);
int ms2base_qm_finalize(void);

#endif
