//!
//! Copyright (C) 2011-2015 QMMMW group
//! This file is distributed under the terms of the
//! GNU General Public License version 3 (GNU-GPLv3).
//!
#include "fix_ms2ec.h"
#include "stdlib.h"
#include "error.h"
#include "atom.h"
#include "mpi.h"
#include "universe.h"
#include "domain.h"
#include <string.h>
#include <math.h>
#include <assert.h>
#include <ms2ec.h>

using namespace LAMMPS_NS;
using namespace FixConst;

#define MS2ECMSG(...) fprintf(screen, "MS2EC Module: " __VA_ARGS__)

#define MS2ECMSG1(...) {if (!me) fprintf(screen, "MS2EC Module: " __VA_ARGS__);}

#define ROLE_MASTER 0
#define ROLE_SLAVE  1

#define MAXINDEX 351

// FIXME: put this sh**t in an external static class, or parse a text file to get the data
const int FixMS2EC::Z[MAXINDEX] = {1, 1, 1, 2, 2, 3, 3, 4, 5, 5, 6, 6, 6, 7, 7, 8, 8, 8, 9,
                                   10, 10, 10, 11, 12, 12, 12, 13, 14, 14, 14, 15, 16, 16, 16,
                                   16, 17, 17, 18, 18, 18, 19, 19, 19, 20, 20, 20, 20, 20, 20,
                                   21, 22, 22, 22, 22, 22, 23, 23, 24, 24, 24, 24, 25, 26, 26,
                                   26, 26, 27, 28, 28, 28, 28, 28, 29, 29, 30, 30, 30, 30, 30,
                                   31, 31, 32, 32, 32, 32, 32, 33, 34, 34, 34, 34, 34, 34, 35,
                                   35, 36, 36, 36, 36, 36, 36, 37, 37, 38, 38, 38, 38, 39, 40,
                                   40, 40, 40, 40, 41, 42, 42, 42, 42, 42, 42, 42, 43, 43, 43,
                                   44, 44, 44, 44, 44, 44, 44, 45, 46, 46, 46, 46, 46, 46, 47,
                                   47, 48, 48, 48, 48, 48, 48, 48, 48, 49, 49, 50, 50, 50, 50,
                                   50, 50, 50, 50, 50, 50, 51, 51, 52, 52, 52, 52, 52, 52, 52,
                                   52, 53, 54, 54, 54, 54, 54, 54, 54, 54, 54, 55, 56, 56, 56,
                                   56, 56, 56, 56, 57, 57, 58, 58, 58, 58, 59, 60, 60, 60, 60,
                                   60, 60, 60, 61, 61, 62, 62, 62, 62, 62, 62, 62, 63, 63, 64,
                                   64, 64, 64, 64, 64, 64, 65, 66, 66, 66, 66, 66, 66, 66, 67,
                                   68, 68, 68, 68, 68, 68, 69, 70, 70, 70, 70, 70, 70, 70, 71,
                                   71, 72, 72, 72, 72, 72, 72, 73, 73, 74, 74, 74, 74, 74, 75,
                                   75, 76, 76, 76, 76, 76, 76, 76, 77, 77, 78, 78, 78, 78, 78,
                                   78, 79, 80, 80, 80, 80, 80, 80, 80, 81, 81, 82, 82, 82, 82,
                                   83, 84, 84, 85, 85, 86, 86, 86, 87, 88, 88, 88, 88, 89, 90,
                                   90, 91, 92, 92, 92, 92, 92, 93, 93, 94, 94, 94, 94, 94, 94,
                                   95, 95, 96, 96, 96, 96, 96, 96, 97, 97, 98, 98, 98, 98, 99,
                                   100, 101, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110,
                                   111, 112, 113, 114, 115};

const char FixMS2EC::EL[MAXINDEX][4] = {"H", "H", "H", "He", "He", "Li", "Li", "Be", "B", "B", 
                                        "C", "C", "C", "N", "N", "O", "O", "O", "F", "Ne", "Ne",
                                        "Ne", "Na", "Mg", "Mg", "Mg", "Al", "Si", "Si", "Si",
                                        "P", "S", "S", "S", "S", "Cl", "Cl", "Ar", "Ar", "Ar",
                                        "K", "K", "K", "Ca", "Ca", "Ca", "Ca", "Ca", "Ca", "Sc",
                                        "Ti", "Ti", "Ti", "Ti", "Ti", "V", "V", "Cr", "Cr", "Cr",
                                        "Cr", "Mn", "Fe", "Fe", "Fe", "Fe", "Co", "Ni", "Ni",
                                        "Ni", "Ni", "Ni", "Cu", "Cu", "Zn", "Zn", "Zn", "Zn", "Zn",
                                        "Ga", "Ga", "Ge", "Ge", "Ge", "Ge", "Ge", "As", "Se",
                                        "Se", "Se", "Se", "Se", "Se", "Br", "Br", "Kr", "Kr",
                                        "Kr", "Kr", "Kr", "Kr", "Rb", "Rb", "Sr", "Sr", "Sr",
                                        "Sr", "Y", "Zr", "Zr", "Zr", "Zr", "Zr", "Nb", "Mo", "Mo",
                                        "Mo", "Mo", "Mo", "Mo", "Mo", "Tc", "Tc", "Tc", "Ru", "Ru",
                                        "Ru", "Ru", "Ru", "Ru", "Ru", "Rh", "Pd", "Pd", "Pd", "Pd",
                                        "Pd", "Pd", "Ag", "Ag", "Cd", "Cd", "Cd", "Cd", "Cd", "Cd",
                                        "Cd", "Cd", "In", "In", "Sn", "Sn", "Sn", "Sn", "Sn", "Sn",
                                        "Sn", "Sn", "Sn", "Sn", "Sb", "Sb", "Te", "Te", "Te", "Te",
                                        "Te", "Te", "Te", "Te", "I", "Xe", "Xe", "Xe", "Xe", "Xe",
                                        "Xe", "Xe", "Xe", "Xe", "Cs", "Ba", "Ba", "Ba", "Ba", "Ba",
                                        "Ba", "Ba", "La", "La", "Ce", "Ce", "Ce", "Ce", "Pr", "Nd",
                                        "Nd", "Nd", "Nd", "Nd", "Nd", "Nd", "Pm", "Pm", "Sm", "Sm",
                                        "Sm", "Sm", "Sm", "Sm", "Sm", "Eu", "Eu", "Gd", "Gd", "Gd",
                                        "Gd", "Gd", "Gd", "Gd", "Tb", "Dy", "Dy", "Dy", "Dy", "Dy",
                                        "Dy", "Dy", "Ho", "Er", "Er", "Er", "Er", "Er", "Er", "Tm",
                                        "Yb", "Yb", "Yb", "Yb", "Yb", "Yb", "Yb", "Lu", "Lu", "Hf",
                                        "Hf", "Hf", "Hf", "Hf", "Hf", "Ta", "Ta", "W", "W", "W", "W",
                                        "W", "Re", "Re", "Os", "Os", "Os", "Os", "Os", "Os", "Os",
                                        "Ir", "Ir", "Pt", "Pt", "Pt", "Pt", "Pt", "Pt", "Au", "Hg",
                                        "Hg", "Hg", "Hg", "Hg", "Hg", "Hg", "Tl", "Tl", "Pb", "Pb",
                                        "Pb", "Pb", "Bi", "Po", "Po", "At", "At", "Rn", "Rn", "Rn",
                                        "Fr", "Ra", "Ra", "Ra", "Ra", "Ac", "Th", "Th", "Pa", "U",
                                        "U", "U", "U", "U", "Np", "Np", "Pu", "Pu", "Pu", "Pu", "Pu",
                                        "Pu", "Am", "Am", "Cm", "Cm", "Cm", "Cm", "Cm", "Cm", "Bk",
                                        "Bk", "Cf", "Cf", "Cf", "Cf", "Es", "Fm", "Md", "Md", "No",
                                        "Lr", "Rf", "Db", "Sg", "Bh", "Hs", "Mt", "Ds", "Rg", "Cn",
                                        "Uut", "Uuq", "Uup"};

const int FixMS2EC::A[MAXINDEX] = {1, 2, 3, 3, 4, 6, 7, 9, 10, 11, 12, 13, 14, 14, 15, 16, 17, 18,
                                   19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34,
                                   36, 35, 37, 36, 38, 40, 39, 40, 41, 40, 42, 43, 44, 46, 48, 45,
                                   46, 47, 48, 49, 50, 50, 51, 50, 52, 53, 54, 55, 54, 56, 57, 58,
                                   59, 58, 60, 61, 62, 64, 63, 65, 64, 66, 67, 68, 70, 69, 71, 70,
                                   72, 73, 74, 76, 75, 74, 76, 77, 78, 80, 82, 79, 81, 78, 80, 82,
                                   83, 84, 86, 85, 87, 84, 86, 87, 88, 89, 90, 91, 92, 94, 96, 93,
                                   92, 94, 95, 96, 97, 98, 100, 97, 98, 99, 96, 98, 99, 100, 101,
                                   102, 104, 103, 102, 104, 105, 106, 108, 110, 107, 109, 106, 108,
                                   110, 111, 112, 113, 114, 116, 113, 115, 112, 114, 115, 116, 117,
                                   118, 119, 120, 122, 124, 121, 123, 120, 122, 123, 124, 125, 126,
                                   128, 130, 127, 124, 126, 128, 129, 130, 131, 132, 134, 136, 133,
                                   130, 132, 134, 135, 136, 137, 138, 138, 139, 136, 138, 140, 142,
                                   141, 142, 143, 144, 145, 146, 148, 150, 145, 147, 144, 147, 148,
                                   149, 150, 152, 154, 151, 153, 152, 154, 155, 156, 157, 158, 160,
                                   159, 156, 158, 160, 161, 162, 163, 164, 165, 162, 164, 166, 167,
                                   168, 170, 169, 168, 170, 171, 172, 173, 174, 176, 175, 176, 174,
                                   176, 177, 178, 179, 180, 180, 181, 180, 182, 183, 184, 186, 185,
                                   187, 184, 186, 187, 188, 189, 190, 192, 191, 193, 190, 192, 194,
                                   195, 196, 198, 197, 196, 198, 199, 200, 201, 202, 204, 203, 205,
                                   204, 206, 207, 208, 209, 209, 210, 210, 211, 211, 220, 222, 223,
                                   223, 224, 226, 228, 227, 230, 232, 231, 233, 234, 235, 236, 238,
                                   236, 237, 238, 239, 240, 241, 242, 244, 241, 243, 243, 244, 245,
                                   246, 247, 248, 247, 249, 249, 250, 251, 252, 252, 257, 258, 260,
                                   259, 262, 265, 268, 271, 272, 270, 276, 281, 280, 285, 284, 289,
                                   288};

const double FixMS2EC::MASS[MAXINDEX] = {1.00782503207, 2.0141017778, 3.0160492777, 3.0160293191, 4.00260325415, 6.015122795, 7.01600455, 9.0121822,
                                         10.0129370, 11.0093054, 12.0000000, 13.0033548378, 14.003241989, 14.0030740048, 15.0001088982, 15.99491461956,
                                         16.99913170, 17.9991610, 18.99840322, 19.9924401754, 20.99384668, 21.991385114, 22.9897692809, 23.985041700,
                                         24.98583692, 25.982592929, 26.98153863, 27.9769265325, 28.976494700, 29.97377017, 30.97376163, 31.97207100,
                                         32.97145876, 33.96786690, 35.96708076, 34.96885268, 36.96590259, 35.967545106, 37.9627324, 39.9623831225,
                                         38.96370668, 39.96399848, 40.96182576, 39.96259098, 41.95861801, 42.9587666, 43.9554818, 45.9536926,
                                         47.952534, 44.9559119, 45.9526316, 46.9517631, 47.9479463, 48.9478700, 49.9447912, 49.9471585,
                                         50.9439595, 49.9460442, 51.9405075, 52.9406494, 53.9388804, 54.9380451, 53.9396105, 55.9349375,
                                         56.9353940, 57.9332756, 58.9331950, 57.9353429, 59.9307864, 60.9310560, 61.9283451, 63.9279660,
                                         62.9295975, 64.9277895, 63.9291422, 65.9260334, 66.9271273, 67.9248442, 69.9253193, 68.9255736,
                                         70.9247013, 69.9242474, 71.9220758, 72.9234589, 73.9211778, 75.9214026, 74.9215965, 73.9224764,
                                         75.9192136, 76.9199140, 77.9173091, 79.9165213, 81.9166994, 78.9183371, 80.9162906, 77.9203648,
                                         79.9163790, 81.9134836, 82.914136, 83.911507, 85.91061073, 84.911789738, 86.909180527, 83.913425,
                                         85.9092602, 86.9088771, 87.9056121, 88.9058483, 89.9047044, 90.9056458, 91.9050408, 93.9063152,
                                         95.9082734, 92.9063781, 91.906811, 93.9050883, 94.9058421, 95.9046795, 96.9060215, 97.9054082,
                                         99.907477, 96.906365, 97.907216, 98.9062547, 95.907598, 97.905287, 98.9059393, 99.9042195,
                                         100.9055821, 101.9043493, 103.905433, 102.905504, 101.905609, 103.904036, 104.905085, 105.903486,
                                         107.903892, 109.905153, 106.905097, 108.904752, 105.906459, 107.904184, 109.9030021, 110.9041781,
                                         111.9027578, 112.9044017, 113.9033585, 115.904756, 112.904058, 114.903878, 111.904818, 113.902779,
                                         114.903342, 115.901741, 116.902952, 117.901603, 118.903308, 119.9021947, 121.9034390, 123.9052739,
                                         120.9038157, 122.9042140, 119.904020, 121.9030439, 122.9042700, 123.9028179, 124.9044307, 125.9033117,
                                         127.9044631, 129.9062244, 126.904473, 123.9058930, 125.904274, 127.9035313, 128.9047794, 129.9035080,
                                         130.9050824, 131.9041535, 133.9053945, 135.907219, 132.905451933, 129.9063208, 131.9050613, 133.9045084,
                                         134.9056886, 135.9045759, 136.9058274, 137.9052472, 137.907112, 138.9063533, 135.907172, 137.905991,
                                         139.9054387, 141.909244, 140.9076528, 141.9077233, 142.9098143, 143.9100873, 144.9125736, 145.9131169,
                                         147.916893, 149.920891, 144.912749, 146.9151385, 143.911999, 146.9148979, 147.9148227, 148.9171847,
                                         149.9172755, 151.9197324, 153.9222093, 150.9198502, 152.9212303, 151.9197910, 153.9208656, 154.9226220,
                                         155.9221227, 156.9239601, 157.9241039, 159.9270541, 158.9253468, 155.924283, 157.924409, 159.9251975,
                                         160.9269334, 161.9267984, 162.9287312, 163.9291748, 164.9303221, 161.928778, 163.929200, 165.9302931,
                                         166.9320482, 167.9323702, 169.9354643, 168.9342133, 167.933897, 169.9347618, 170.9363258, 171.9363815,
                                         172.9382108, 173.9388621, 175.9425717, 174.9407718, 175.9426863, 173.940046, 175.9414086, 176.9432207,
                                         177.9436988, 178.9458161, 179.9465500, 179.9474648, 180.9479958, 179.946704, 181.9482042, 182.9502230,
                                         183.9509312, 185.9543641, 184.9529550, 186.9557531, 183.9524891, 185.9538382, 186.9557505, 187.9558382,
                                         188.9581475, 189.9584470, 191.9614807, 190.9605940, 192.9629264, 189.959932, 191.9610380, 193.9626803,
                                         194.9647911, 195.9649515, 197.967893, 196.9665687, 195.965833, 197.9667690, 198.9682799, 199.9683260,
                                         200.9703023, 201.9706430, 203.9734939, 202.9723442, 204.9744275, 203.9730436, 205.9744653, 206.9758969,
                                         207.9766521, 208.9803987, 208.9824304, 209.9828737, 209.987148, 210.9874963, 210.990601, 220.0113940,
                                         222.0175777, 223.0197359, 223.0185022, 224.0202118, 226.0254098, 228.0310703, 227.0277521, 230.0331338,
                                         232.0380553, 231.0358840, 233.0396352, 234.0409521, 235.0439299, 236.0455680, 238.0507882, 236.046570,
                                         237.0481734, 238.0495599, 239.0521634, 240.0538135, 241.0568515, 242.0587426, 244.064204, 241.0568291,
                                         243.0613811, 243.0613891, 244.0627526, 245.0654912, 246.0672237, 247.070354, 248.072349, 247.070307,
                                         249.0749867, 249.0748535, 250.0764061, 251.079587, 252.081626, 252.082980, 257.095105, 258.098431,
                                         260.10365, 259.10103, 262.10963, 265.11670, 268.12545, 271.13347, 272.13803, 270.13465,
                                         276.15116, 281.16206, 280.16447, 285.17411, 284.17808, 289.18728, 288.19249};

/** 
    This function matches the element which has the least absolute difference between the masses.

    if error != NULL, it is filled with the difference between the
    mass provided and the best match.

    THIS FUNCTION RELIES ON THE CORRECT ORDER OF THE DATA TABLES IN
    ORDER TO SKIP ISOTOPES FROM THE MATCH

*/
int FixMS2EC::match_element(double mass, int search_isotopes, double *delta)
{
  int i;
  int bestcandidate;
  double diff, mindiff;
  int ATOMTYPES = 351;
  int lastz;
  mindiff =  1e6;
  bestcandidate = -1;
  lastz = -1;
  for(i=0;i<ATOMTYPES;i++) {
    if(!search_isotopes && lastz == Z[i])
      continue;
    diff = fabs(MASS[i] - mass);
    if(diff < mindiff) {
      mindiff = diff;
      bestcandidate = i;
    }
    lastz = Z[i];
  }
  assert(bestcandidate != -1);
  if(delta != NULL)
    *delta = mindiff;
  return bestcandidate;
}

/**
   This function returns an array of integer with the guessed Z of each atom
*/
int *FixMS2EC::match_atom_elements()
{
  double *masses;
  int *tmp = NULL;
  int *elements = NULL;
  double delta;
  static char loginfo[200];
  int i;

  tmp = (int *) calloc(atom->ntypes + 1, sizeof(int));
  if(tmp == NULL) {
    char emsg[150];
    snprintf(emsg, 150, "MS2EC: unable to allocate memory in %s:%d\n",__FILE__, __LINE__);
    error->all(FLERR,emsg);
  }

  elements = (int *) calloc(atom->natoms, sizeof(int));
  if(elements == NULL) {
    char emsg[150];
    snprintf(emsg, 150, "MS2EC: unable to allocate memory in %s:%d\n",__FILE__, __LINE__);
    error->all(FLERR,emsg);
  }

  // For each atom type find the mass and then the corresponding element. Skip isotopes
  double maxdelta = 0.0;
  for(i=1;i<=atom->ntypes;i++) {
    double delta;
    tmp[i] = match_element(atom->mass[i], 0, &delta);
    snprintf(loginfo, 200, "fix_ms2ec: type %2d (mass: %8g) matches a %2s with: Z = %-3d A = %-3d (error = %-8.2g -> %-.2g%%)\n", 
             i, atom->mass[i], EL[tmp[i]], Z[tmp[i]], A[tmp[i]], 
             delta, delta/atom->mass[i] * 100.0);
    if(screen) fprintf(screen, "%s", loginfo);
    if(logfile) fprintf(logfile, "%s", loginfo);
  }

  for(i=0;i<atom->natoms;i++)
    elements[i] = Z[tmp[atom->type[i]]];
  free(tmp);
  return elements;
}

FixMS2EC::FixMS2EC(class LAMMPS *lmp, int argc, char **argv):
  Fix(lmp,argc,argv)
{
  int errcode;
  int *types;
  double *charges;
  int *elements;
  
  // Initialize the temporary storage locations
  tmpdouble = (double *) calloc(atom->natoms * 3, sizeof(double));
  if(tmpdouble == NULL)
    error->all(FLERR,"MS2EC: unable to allocate space for temporary variables (1)");

  // It wouldn't probably be difficult to use them (i gave it already a
  // look), but we don't need this feature
  if (universe->existflag != 0)
    error->all(FLERR,"MS2EC doesn't support partitioning");

  // Shortcuts for the same universe variable
  me = universe->me;

  // There's no reason to apply the MS2EC fix to just a subsystem. At least for now
  // (btw, it would screw up our code...)
  if(strncasecmp("all", argv[1] , 4) != 0)
    error->all(FLERR,"The MS2EC fix should be applied to all atoms in the simulation");

  setup_done = 0;

  // beside the normal fixed "fix" arguments, we need at least:
  // the file where the expression for the selection can be found
  // a module name
  // if more parameters are found, they are passed to the module initialization routine
  if(argc < 5)
    error->all(FLERR,"Invalid number of parameters for the MS2EC fix");

  // Find out the role of this process
  role = -1;
  if(!strcasecmp(argv[3], "master")) {
    MS2ECMSG1("master role\n");
    role = ROLE_MASTER;
    if(argc < 6)
      error->all(FLERR,"Invalid number of parameters for the MS2EC fix");
  }
  if(!strcasecmp(argv[3], "slave")) {
    MS2ECMSG1("slave role\n");
    role = ROLE_SLAVE;
    if(argc < 5)
      error->all(FLERR,"Invalid number of parameters for the MS2EC fix");
  }

  // The string doesn't match a role
  if(role == -1)
    error->all(FLERR,"Invalid MS2EC role specified (can be either master|slave)");

  // Initialize the various processes
  if(!me) 
    switch(role) {
    case ROLE_MASTER: 
      // FIXME! ERROR CHECKS!!!!
      // Gather the atom types and charges
      types = get_atom_something(atom->type);
      charges = get_atom_something(atom->q);
      elements = match_atom_elements();

      // This array will pack all details about the cell
      double celldata[9];
      memcpy(celldata    , domain->boxlo, sizeof(double) * 3);
      memcpy(celldata + 3, domain->boxhi, sizeof(double) * 3);
      celldata[6] = domain->xy;
      celldata[7] = domain->xz;
      celldata[8] = domain->yz;

      errcode =  ms2ec_master_initialize(argc - 4, argv + 4,
                                         atom->natoms, types, charges, elements, celldata);
      delete [] types;
      delete [] charges;
      delete [] elements;
      break;
    case ROLE_SLAVE:
      errcode = ms2ec_slave_initialize(argc - 4, argv + 4, 
                                     atom->natoms);

      check_charges();
      break;
    }
  MPI_Bcast(&errcode, 1, MPI_INT, 0, world);
  if(errcode)
    error->all(FLERR,"Unable to initialize the MS2EC support");  

}

int FixMS2EC::setmask()
{
  int mask = 0;
  mask = PRE_FORCE | POST_FORCE | INITIAL_INTEGRATE;
  return mask;
}

void FixMS2EC::init()
{
  MS2ECMSG1("init\n");

  // Since the spatial sorting can be turned on and off between the
  // simulation, It is way better to keep the check in init, where it
  // is performed more often
  if(atom->sortfreq != 0)
    error->all(FLERR,"The MS2EC fix and sorting are incompatible: turn spatial sorting off ('atom_modify sort 0 0.0')");

  pre_force(0);
}

// Barrier/MPI test not required
void FixMS2EC::setup(int vflag)
{
  MS2ECMSG1("setup\n");
  post_force(vflag);
}

// Barrier/MPI test not required
void FixMS2EC::initial_integrate(int vflag)
{
    switch(setup_done) {
    case 0:
      return;
    default:
      MS2ECMSG1("integration right after the setup\n");
      post_force(vflag);
      setup_done = 0;
      return;
    }
}

void FixMS2EC::pre_force(int vflag)
{
  int errcode;
  MS2ECMSG1("pre force\n");

  mergepositions();

  if(!me)
    switch(role) {
    case ROLE_MASTER:
      errcode = ms2ec_master_send_positions(tmpdouble);
      break;
    case ROLE_SLAVE:
      errcode = ms2ec_slave_recv_positions(tmpdouble);
      break;
    }
  MPI_Bcast(&errcode, 1, MPI_INT, 0, world);
  if(errcode)
    error->all(FLERR,"MS2EC was unable to perform the pre_force step!");

  if(role == ROLE_SLAVE)
    scatterpositions();

}

// Errors TODO
void FixMS2EC::post_force(int vflag)
{
  int errcode;
  int i;
  MS2ECMSG1("post force\n");

  mergeforces();

  if(!me)
    switch(role) {
    case ROLE_MASTER:
      errcode = ms2ec_master_recv_forces(tmpdouble);
      break;
    case ROLE_SLAVE:
      //! Send the forces to LAMMPS_master
      errcode = ms2ec_slave_send_forces(tmpdouble);
      break;
    }
  MPI_Bcast(&errcode, 1, MPI_INT, 0, world);
  if(errcode)
    error->all(FLERR,"MS2EC was unable to perform the post_force step!");

  scatterforces();

}

void FixMS2EC::mergepositions()
{
  int i, index;
  int elements = 3 * atom->natoms;
  double *copy = new double[elements];
  
  // Clear the array
  memset(copy, 0, sizeof(double) * 3 * atom->natoms);
  // Write the data
  for(i=0; i<atom->nlocal; i++) {
    index = 3 * (atom->tag[i] - 1);
    copy[index + 0] = atom->x[i][0];
    copy[index + 1] = atom->x[i][1];
    copy[index + 2] = atom->x[i][2];
  }
  MPI_Reduce(copy, tmpdouble, 3 * atom->natoms, MPI_DOUBLE, MPI_SUM, 0, world);
  delete [] copy;
}

void FixMS2EC::mergeforces()
{
  int i, index;
  int elements = 3 * atom->natoms;
  double *copy = new double[elements];
  
  // Clear the array
  memset(copy, 0, sizeof(double) * 3 * atom->natoms);
  // Write the data
  for(i=0; i<atom->nlocal; i++) {
    index = 3 * (atom->tag[i] - 1);
    copy[index + 0] = atom->f[i][0];
    copy[index + 1] = atom->f[i][1];
    copy[index + 2] = atom->f[i][2];
  }
  MPI_Reduce(copy, tmpdouble, 3 * atom->natoms, MPI_DOUBLE, MPI_SUM, 0, world);
  delete [] copy;
}

// NOTE: the nlocal/tag thing allows MPI operations

//! Get a double quantity from the atom section (e.g. atom->q, or atom->m, ecc)
double *FixMS2EC::get_atom_something(double *source)
{
  int i, index;
  int natoms = atom->natoms;
  double *copy = NULL;
  double *tmpdouble = NULL;

  copy = (double *) calloc(atom->natoms, sizeof(double));
  if(copy == NULL) {
    char emsg[150];
    snprintf(emsg, 150, "MS2EC: unable to allocate memory in %s:%d\n",__FILE__, __LINE__);
    error->all(FLERR,emsg);
  }

  tmpdouble = (double *) calloc(atom->natoms, sizeof(double));
  if(tmpdouble == NULL) {
    char emsg[150];
    snprintf(emsg, 150, "MS2EC: unable to allocate memory in %s:%d\n",__FILE__, __LINE__);
    error->all(FLERR,emsg);
  }

  // Clear the array
  memset(copy, 0, sizeof(int) * atom->natoms);
  // Write the data
  for(i=0; i<atom->nlocal; i++) {
    index = atom->tag[i] - 1;
    copy[index] = source[i];
    // DEBUG
    //fprintf(stderr, "%d: tag: %d value: %g\n ", i, atom->tag[i], source[atom->tag[i] - 1]);
  }
  MPI_Reduce(copy, tmpdouble, atom->natoms, MPI_DOUBLE, MPI_SUM, 0, world);
  free(copy);
  return tmpdouble;
}

int *FixMS2EC::get_atom_something(int *source)
{
  int i, index;
  int *copy = NULL;
  int *tmpint = NULL;
  
  copy = (int *) calloc(atom->natoms, sizeof(int));
  if(copy == NULL) {
    char emsg[150];
    snprintf(emsg, 150, "MS2EC: unable to allocate memory in %s:%d\n",__FILE__, __LINE__);
    error->all(FLERR,emsg);
  }

  tmpint = (int *) calloc(atom->natoms, sizeof(int));
  if(tmpint == NULL) {
    char emsg[150];
    snprintf(emsg, 150, "MS2EC: unable to allocate memory in %s:%d\n",__FILE__, __LINE__);
    error->all(FLERR,emsg);
  }
  
  // Clear the array
  memset(copy, 0, sizeof(int) * atom->natoms);
  // Write the data
  for(i=0; i<atom->nlocal; i++) {
    index = atom->tag[i] - 1;
    copy[index] = source[i];
  }
  MPI_Reduce(copy, tmpint, atom->natoms, MPI_INT, MPI_SUM, 0, world);
  free(copy);
  return tmpint;
}

//! Get a type-quantity for each atom (performs a double-lookup)
double *FixMS2EC::get_type_something(double *source)
{
  int i, index;
  int natoms = atom->natoms;
  double *copy = NULL;
  double *tmpdouble = NULL;

  copy = (double *) calloc(atom->natoms, sizeof(double));
  if(copy == NULL) {
    char emsg[150];
    snprintf(emsg, 150, "MS2EC: unable to allocate memory in %s:%d\n",__FILE__, __LINE__);
    error->all(FLERR,emsg);
  }

  tmpdouble = (double *) calloc(atom->natoms, sizeof(double));
  if(tmpdouble == NULL) {
    char emsg[150];
    snprintf(emsg, 150, "MS2EC: unable to allocate memory in %s:%d\n",__FILE__, __LINE__);
    error->all(FLERR,emsg);
  }

  // Clear the array
  memset(copy, 0, sizeof(int) * atom->natoms);
  // Write the data
  for(i=0; i<atom->nlocal; i++) {
    int atype;
    index = atom->tag[i] - 1;
    atype = atom->type[i];
    copy[index] = source[atype];
    
  }
  MPI_Reduce(copy, tmpdouble, atom->natoms, MPI_DOUBLE, MPI_SUM, 0, world);
  free(copy);
  return tmpdouble;
}


// On the slave, all charges should be == 0 The test is here
// because I do want to make the whole simulation fail, not just
// the slave process (otherwise the master could remain stuck
// and consume wall time on a cluster)
//
// On the master, this role is performed by the libms2ec library
void FixMS2EC::check_charges()
{
  int i, index;
  int natoms = atom->natoms;

  for(i=0; i<atom->nlocal; i++) {
    // index = atom->tag[i] - 1;
    // fprintf(stderr, "I: %d  TAG: %d  CHARGE: %g\n", i, atom->tag[i], atom->q[i]);
    if(atom->q[i] != 0.0) {
      char emsg[100];
      snprintf(emsg, 100, "The secondary process should have all charges set to 0 (charge %d = %g)!", 
	       atom->tag[i], atom->q[i]);
      error->all(FLERR,emsg);
    }
  }
}

void FixMS2EC::scatterpositions()
{
  int i, index;
  // Distribute to each processor
  MPI_Bcast(tmpdouble, 3 * atom->natoms, MPI_DOUBLE, 0, world);
  // Copy the local values to the positions vector
  for(i=0; i<atom->nlocal; i++) {
    index = 3 * (atom->tag[i] - 1);
    atom->x[i][0] = tmpdouble[index + 0];
    atom->x[i][1] = tmpdouble[index + 1];
    atom->x[i][2] = tmpdouble[index + 2];
  }
}

void FixMS2EC::scatterforces()
{
  int i, index;
  // Distribute to each processor
  MPI_Bcast(tmpdouble, 3 * atom->natoms, MPI_DOUBLE, 0, world);
  // Copy the local values to the positions vector
  for(i=0; i<atom->nlocal; i++) {
    index = 3 * (atom->tag[i] - 1);
    atom->f[i][0] = tmpdouble[index + 0];
    atom->f[i][1] = tmpdouble[index + 1];
    atom->f[i][2] = tmpdouble[index + 2];
  }
}


FixMS2EC::~FixMS2EC()
{
  int errcode;
  // Free the temporary storage
  free(tmpdouble);
  // Final cleanup, if required by the module
  if(!me)
    switch(role) {
    case ROLE_MASTER: 
      errcode = ms2ec_master_finalize();
      break;
    case ROLE_SLAVE:
      errcode = ms2ec_slave_finalize();
      break;
    }
  MPI_Bcast(&errcode, 1, MPI_INT, 0, world);
  if(errcode)
    error->all(FLERR,"MS2EC was unable to finalize the plugin!");

}
