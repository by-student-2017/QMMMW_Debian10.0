//!
//! Copyright (C) 2011-2015 QMMMW group
//! This file is distributed under the terms of the
//! GNU General Public License version 3 (GNU-GPLv3).
//!
#ifdef FIX_CLASS
FixStyle(ms2ec, FixMS2EC)
#else
#ifndef FIX_MS2EC_H
#define FIX_MS2EC_H

#include "fix.h"

namespace LAMMPS_NS {


  class FixMS2EC : public Fix {
  public:
    FixMS2EC(class LAMMPS *, int, char **);
    ~FixMS2EC();
    void init();
    void pre_force(int);
    void post_force(int);
    int setmask();
    void setup(int);
    void initial_integrate(int);
  private:
    //! The role in the MS2EC system
    int role;
    //! True only after a setup step
    int setup_done;
    // Shortcuts for the corresponding variables in universe.h
    int me;
    //! Temporary storages for the packing/unpacking operations
    double *tmpdouble;

    //! Find the elements by matching the masses
    int *match_atom_elements();
    //! Ensure that the charges are all 0 on the slave, and 0 for QM atoms on the master
    void check_charges();
    //! Used to pack the positions on the master node
    void mergepositions();
    //! Used to unpack the positions to all nodes (slave/fakeqm only)
    void scatterpositions();    
    //! Match an element using a mass
    int match_element(double mass, int search_isotopes, double *delta);    
    //! Spread/gather the forces among processors. Used to make MPI work
    void mergeforces();
    void scatterforces();
    //! Get a per-atom atom->x quantity
    double *get_atom_something(double *x);
    int *get_atom_something(int *x);
    //! Get a per-type atom->x quantity
    double *get_type_something(double *x);
     


#define MAXINDEX 351
    // FIXME: put this sh**t in an external static class, or parse a text file to get the data
    static const char EL[MAXINDEX][4];    
    static const int A[MAXINDEX];
    static const int Z[MAXINDEX];
    static const double MASS[MAXINDEX];
#undef MAXINDEX
  };
}


#endif
#endif
