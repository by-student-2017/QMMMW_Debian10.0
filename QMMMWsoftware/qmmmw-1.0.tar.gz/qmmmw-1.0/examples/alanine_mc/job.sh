source $QMMMW_DIR/bin/ms2.env

cd master
$LAMMPS_DIR/src/lmp_ms2 < alanine.in > alanine.out &

sleep 5

cd ../slave
$LAMMPS_DIR/src/lmp_ms2 < alanine_reduced.in > alanine_reduced.out &

sleep 5

cd ../qe
$ESPRESSO_DIR/bin/pw.x < alanine_qm.in > alanine_qm.out
